---
type: Case Study
title: "XB-1: Mach cutoff, and 115 days to re-legalising supersonic flight"
description: "Boom demonstrated a sonic boom that never reaches the ground — which dissolved the regulatory argument rather than winning it."
tags: [aerospace, regulation, hardware, policy]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

# The flight

XB-1 — which started life as "Baby Boom" — became the first independently developed jet to break the
sound barrier, more than a decade after the company was founded in 2014. Scholl relives it from
about a year before the talk, in the Mojave Desert.[^ss26-scholl]

Firsts claimed for the aircraft: first privately developed supersonic jet, where this had
previously been the work of governments and militaries with enormous budgets; first supersonic jet
made in America; first human-piloted aircraft landed solely on augmented reality with no natural
view of the runway; and the first supersonic air-to-air live stream, filmed on an iPhone and
streamed via Starlink.

The team was **50 people**.

# Mach cutoff — the part that was not in the plan

XB-1 broke the sound barrier on two flights, going through it **six times**. Each time there was no
audible sonic boom at the ground.

They demonstrated a long-discussed principle called **Mach cutoff**: break the sound barrier at
sufficiently high altitude and at the right speed for the current weather, and the boom refracts —
Scholl's description is that it makes a U-turn in the sky — and never touches the ground.

His argument for why this mattered more than the speed record: it set aside the question that had
plagued every supersonic proposal, namely *how quiet is quiet enough.* With no boom at all, there
is nothing to argue about.

# The regulatory cascade

| Interval | Event |
|---|---|
| ~24 hours from breaking the sound barrier | invited to the West Wing |
| 115 days | an executive order making supersonic flight legal again in the US |
| after the EO | a bill in the House and Senate to make legalisation permanent |
| — | passed the House unanimously |
| the week before the talk | out of Senate Commerce Committee, again unanimously |

His framing: supersonic flight is not red or blue, it is red, white and blue.

# Why the regulatory approach worked

Boom engaged the FAA from the beginning — explaining what they were doing and why, inviting them to
see anything at any time, and showing plans before finalising them. The result: an approvals
process that can take months even for an R&D aircraft completed in **90 minutes**, and the
first-ever permit for civil supersonic flight granted before the aircraft had flown at all. See
[/concepts/regulatory-strategy-for-startups.md](/concepts/regulatory-strategy-for-startups.md).

# The independent confirmation

[Michael Kratsios](/sources/michael-kratsios.md), speaking three weeks later, names supersonic
flight as his favourite example of technological stagnation and of a "born in captivity"
technology, and identifies the precise fix as a noise limit rather than a speed limit — the change
that had just happened.[^ss26-kratsios]

# See also

- [/concepts/born-free-vs-born-in-captivity.md](/concepts/born-free-vs-born-in-captivity.md)
- [/concepts/optimize-for-the-worst-day-and-the-best-day.md](/concepts/optimize-for-the-worst-day-and-the-best-day.md)

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
