---
type: Case Study
title: "Waymo: 18 months to the demo, 15 years to the product"
description: "The concrete timeline behind the claim that a working demo is 1% of the work — and the exponential re-acceleration afterwards."
tags: [autonomous-vehicles, reliability, scaling, timelines]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

# The demo

The project started in 2009. Before building the system the team set two deliberately ambitious
goals: drive 100,000 miles in autonomous mode, and drive ten routes of 100 miles each — chosen to
cover a wide variety of Bay Area conditions — from beginning to end with no human
intervention.[^ss26-dolgov]

A team of about a dozen engineers accomplished both in roughly **18 months**. Dolgov stresses the
context: this was well before ConvNets, transformers or VLMs. And by demo standards autonomous
driving was solved in 2010 — day and night, traffic, pedestrians, cyclists, traffic lights,
construction zones, freeways, surface streets. In his words, they were "capability complete" and
felt on top of the world.

# The product

Then the brutal reality: there is a massive difference between driving ten routes once and running
a scalable service with nobody behind the wheel.

- **~10 more years** to begin providing a service.
- **5 more years** to scale to half a million trips per week.
- Total: the demo took 18 months, the product took about **15 years**.

# The re-acceleration

The point of the timeline is not that physical AI is slow — it is that the curve is exponential once
the nines are in place:

| Milestone | Time taken |
|---|---|
| First 100 million fully autonomous miles | ~15 years |
| Next 100 million miles | ~7 months |
| First rider-only operation → four cities | ~8 years |
| Four additional cities | launched in a single day |

# Current scale and safety, as stated

Roughly 500,000 trips per week and over 4 million fully autonomous miles per week across 15 US
cities; more than 20 million fully autonomous trips and over 200 million miles to date. The
published safety analysis covering over 220 million miles reports about **17x fewer
serious-injury-causing crashes** than human drivers in the areas of operation — which Dolgov
translates as preventing a serious injury roughly every **8 days**, against a global road-death
every 26 seconds.

⚠️ The auto-transcript renders the weekly trip figure as "500 trips per week"; this is reconciled
against his own later "half a million trips per week." See
[transcription caveats](/sources/index.md#transcription-caveats).

[Chelsea Finn](/sources/chelsea-finn.md) cites the quarter-million weekly rides figure as the
existence proof that a learned system can be trusted in the physical world.[^ss26-finn]

# See also

- [/concepts/ladder-of-nines.md](/concepts/ladder-of-nines.md)

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
