---
type: Case Study
title: "Eigen reviews: continuous performance review as a graph problem"
description: "One question every four to six weeks, weighted PageRank-style across the company, with dropout to detect voting cliques."
tags: [performance-review, internal-software, hr, graph-algorithms]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The problem

Hodak's critique of the conventional annual 360 review: you send out many forms, gather feedback
around each employee, set up meetings with HR and managers, and run the cycle. In his experience it
is a very disruptive process that does not tend to surface issues you did not already know
about — because you knew the thing was there and had not acted on it, since firing people is hard
and people drag their feet. And it happens once a year, or twice if you split the company into
cohorts.[^ss26-hodak]

His deeper framing is that market feedback on whether you are good at hiring eventually arrives —
the company works or it does not — but that is a very long feedback loop with a very poorly behaved
loss function. So it is management's job to **design synthetic gradients** that tell you earlier
and along the way whether recruiting is going well and needs correction.

# The mechanism

- **Cadence:** every four to six weeks — not that often — people around the company get pinged
  through the internal software.
- **The question:** there is a form, but only one question really matters — *knowing how this person
  turned out, would you vote again today for their hire?* It is deliberately the same question used
  in the initial applicant voting. See
  [/concepts/distributed-hiring-funnel.md](/concepts/distributed-hiring-funnel.md).
- **The weighting:** construct a graph over the company from all the feedback. The basic intuition
  is that your vote should be weighted more highly if everybody else has rated you highly — which
  Hodak notes is close to the original PageRank idea of **eigenvector centrality**. Not literally
  eigenvector centrality, but similar enough that they call the technique **eigen reviews**.
- **The clique detector:** apply dropout. Run a thousand iterations, each randomly removing some
  percentage of the edges, and look at the distribution of resulting scores. Additional peaks are a
  clue that there may be voting cliques needing investigation. Asked directly about collusion and
  targeted downvoting, this Markov-chain-Monte-Carlo dropout is his answer — plus the point that it
  is one of several signals, not the only one.

# What it buys

Judgment distributed across the company, updating more or less continuously with about a month's
lag, far better insight into what is actually happening — and it eliminates the traumatic annual
HR-driven review process entirely.

Hodak says he has used it for six or seven years and has become convinced it is more or less the
right way to do performance reviews. He also offers to share a document of specific implementation
tricks with anyone who emails him — though he notes he wants to understand how they plan to deploy
it first.

# The caveat he states himself

The point of the talk is not that you should use this specifically, though he thinks you should
consider it. The point is [/concepts/iteration-velocity-as-the-master-variable.md](/concepts/iteration-velocity-as-the-master-variable.md).

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
