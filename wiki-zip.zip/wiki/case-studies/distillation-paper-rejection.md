---
type: Case Study
title: "The distillation paper that was rejected"
description: "Reviewed as 'unlikely to have significant impact'; it now underlies the fast production models."
tags: [research, publishing, rejection, distillation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# What happened

In 2014 Dean, Geoffrey Hinton and Oriol Vinyals wrote a paper on distillation — using a large
teacher model to train a much smaller, cheaper, more efficient student model. It was rejected at
NeurIPS.[^ss26-dean]

The reviewer comment he recalls: *unlikely to have significant impact.*

# Dean's own reading of the rejection

He does not fault the programme committee, and his explanation is specific and generous: a paper
typically gets three reviews, and in this case a reviewer looked at it from a particular vantage
point. When they wrote it, the authors knew it was important because they *desperately wanted*
cheaper highly capable models derived from larger ones, in order to serve speech and vision to more
people in many domains. A reviewer thinking about whether something is a fundamental advance,
rather than about large-scale AI services, might reasonably not have that experience.

# What they did about it

Posted it to arXiv. People read it, people used it, and it became a technique used across the
industry. Dean notes it is part of why the fast, small Gemini models are so capable relative to
their size and speed — some of the best in their class on benchmarks — being derived from the larger
models.

His distilled lesson, offered with the obvious pun acknowledged in the room: it gets rejected every
so often, that's fine, and you keep going.

# Why this is filed as a case study rather than an anecdote

It is a clean instance of the distinction drawn in
[/concepts/rejection-as-signal-vs-noise.md](/concepts/rejection-as-signal-vs-noise.md): the
rejection carried information about the reviewer's vantage point, not about the work. Compare
Legora's YC rejection, which carried genuine information about a gap the founders then closed.

# See also

- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
