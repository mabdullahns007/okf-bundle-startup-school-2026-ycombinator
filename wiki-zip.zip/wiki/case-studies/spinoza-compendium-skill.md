---
type: Case Study
title: "The compendium skill: 1,500 pages overnight"
description: "Five days before the keynote, an agent read three biographies and returned a chronology, the disagreements, sourced quotes, and ranked stage moments."
tags: [skills, research, agents, personal-agi]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

# What happened

Five days before Startup School, Tan decided his keynote needed Spinoza. His agent acquired three
of the best biographies of the man — by Nadler, Goldstein and Stewart — roughly **1,500 pages**, read
all three overnight, and produced:[^ss26-tan]

1. A **synthesis**.
2. A **dated chronology** of Spinoza's life.
3. **Every place the three biographers disagree with each other.**
4. The best **verbatim quotes with chapter citations**.
5. And, because it knows what he needs: the **ten most tellable moments of his life, ranked, with
   delivery notes.**

He names the specific beats that came out of that run and opened the talk: the knife attack that
tore his cloak, the thousand-guilder bribe, the desk shipped by canal barge. His claim: every beat
of the opening came out of that overnight run, and 1,500 pages became a stage-ready story he could
edit.

# Why it is a "skill" and not a prompt

Tan calls it a **compendium skill** — a reusable markdown procedure he uses daily, which he
describes as a mega version of deep research, and deeper than what packaged AI products will give
you. The distinction matters: the artifact is not the Spinoza research, it is the *procedure* that
produced it, which is why the second use costs nothing. See
[/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md) and his rule against
one-off work.

Note items 3 and 4 in the output list. Recording where sources disagree, and citing quotes to
chapter, are exactly the hygiene requirements he sets out in
[/concepts/knowledge-base-hygiene.md](/concepts/knowledge-base-hygiene.md) — the skill encodes the
epistemics, not just the summarisation.

# The self-referential point

Tan draws attention to it deliberately: the spine of the talk the audience was watching was
produced by the machine the talk was describing. Which is also the honest form of the claim — the
agent did the reading and the ranking; the argument, the selection and the delivery were his.

# The counterexample he pairs it with

The same architecture pointed at something that matters more: a friend whose son has a rare form of
epilepsy built a repository of 80,000 markdown files — every specialist visit, paper, seizure log
and drug interaction, indexed and cross-linked — so that when a new doctor has an idea he knows in
minutes whether it has already been tried. Tan's summary: a father, a laptop and a library.

# See also

- [/concepts/personal-agi.md](/concepts/personal-agi.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
