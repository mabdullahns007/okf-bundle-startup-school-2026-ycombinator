---
type: Case Study
title: "The eleven-day runtime rewrite"
description: "A JavaScript runtime rewritten from Zig to Rust by one dynamic workflow, running eleven days, now in production."
tags: [agents, orchestration, engineering, verification]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The setup

Claude Code is built on Bun, an open-source JavaScript runtime and a faster alternative to Node.js.
Bun was written in Zig, a low-level systems language in which you manage memory manually — so it is
easy to run into memory leaks and other memory-management issues.[^ss26-cherny]

The prior state of the art was narrower: the Bun team had been having Claude *fuzz* the codebase to
simulate and trigger memory leaks, finding many of them, roughly a case at a time.

# The attempt

Cherny describes a team member throwing the same test problem at each new model generation until
one could simply rewrite it. Starting with one model generation it became possible.

The preconditions that made it verifiable, which are the real content of the story: Bun is very
well tested, and there is a large test suite in Bun *and* a large test suite in Node.js — so it is
easy to know whether you did the right thing. See
[/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md).

# The run

- **One prompt**, as a dynamic workflow.
- **Not one-shot** — Cherny is explicit that there was steering. His point is that previous models
  could not do it *even with* steering.
- **Ran for 11 days.**
- Rewrote the entire codebase from Zig to Rust — over 100,000 lines, in a domain he describes as
  genuinely complicated.
- **It works, and it is in production** — it is what Claude Code runs on.

His estimate of the human equivalent: definitely over a year.

# Why the task shape matters

This is the case [Jeff Dean](/sources/jeff-dean.md) predicts independently: translating software
between languages is the task where models excel, because the existing implementation plus its
tests constitutes a perfect specification.[^ss26-dean] See
[/concepts/specification-as-the-new-source.md](/concepts/specification-as-the-new-source.md).

The generalisable lesson is not "agents can rewrite codebases." It is that this codebase was
*rewritable* because it had a machine-checkable definition of correctness.

# See also

- [/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md)
- [/case-studies/electron-to-swift-two-week-run.md](/case-studies/electron-to-swift-two-week-run.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
