---
type: Case Study
title: "The napkin math that produced the TPU"
description: "Three minutes of speech recognition per user per day would have required doubling Google's server fleet."
tags: [hardware, estimation, systems, google]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The calculation

Around 2013 the deep-learning speech models Google was training were producing very good quality
results — halving the error rate, which Dean characterises as the equivalent of twenty years of
progress in speech recognition achieved in a few months of adjusting the model, scaling it up a
little, and getting better data. They were also computationally expensive compared with the old
system.[^ss26-dean]

So he ran the arithmetic on success rather than on the current load: if every Google user talked to
their phone and used speech recognition for **just three minutes a day**, the system would require
roughly **doubling the entire server fleet** — which would have been extremely expensive.

The worry driving it is worth noting: if speech worked a lot better, people would use it a lot
more. The forecast was of *adoption*, not of compute.

# The consequence

They needed a better solution than running on CPUs, and built the TPU: a chip very specialised for
low-precision dense linear algebra, which is at the heart of nearly all modern machine learning.

His framing of the trade: build a specialised chip for low-precision dense linear algebra that can
do nothing else, and it turns out to be extremely useful for ML inference even though it cannot run
Chrome or Word.

**The result, two years later:** 30 to 80 times more energy-efficient than the CPUs and GPUs of the
day, and 20 to 30 times lower latency.

# The design judgment inside it

Asked whether it was luck that the TPU suited transformers, which were invented later, Dean says no
— they deliberately built a *general-purpose linear algebra machine*, because ML algorithms were
still evolving and you did not want to over-specialise. Specialise just enough to get the dramatic
performance benefits: very large multiplier units, high-speed memory, high-speed interconnect, and
in later generations the ability to bring many chips efficiently to bear on one problem.

# The earlier instance of the same method

Around 2001 Dean and Sanjay Ghemawat did the arithmetic and realised the whole Google search index
would fit in the aggregate RAM of the machines they had. They shipped a RAM-resident search version
into production within days — which is what made Google search fast.

# See also

- [/concepts/napkin-math.md](/concepts/napkin-math.md)
- [/concepts/energy-and-data-movement.md](/concepts/energy-and-data-movement.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
