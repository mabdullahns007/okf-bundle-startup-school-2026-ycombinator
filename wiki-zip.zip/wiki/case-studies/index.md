# Case Studies

Worked examples with concrete numbers, kept separate from the concept pages so the figures stay
auditable against their sources.

* [The eleven-day runtime rewrite](bun-zig-to-rust-rewrite.md) - A JavaScript runtime rewritten from Zig to Rust by one dynamic workflow, running eleven days, now in production.
* [The distillation paper that was rejected](distillation-paper-rejection.md) - Reviewed as 'unlikely to have significant impact'; it now underlies the fast production models.
* [Eigen reviews: continuous performance review as a graph problem](eigen-reviews-at-science.md) - One question every four to six weeks, weighted PageRank-style across the company, with dropout to detect voting cliques.
* [The two-week run that was still running](electron-to-swift-two-week-run.md) - Rewrite the Electron app in Swift; run the old one in a VM, screenshot, compare pixel by pixel, don't stop until done.
* [Legora: $1M to $100M ARR in about 18 months](legora-zero-to-100m.md) - The numbers behind Legora's run, the six-month sales freeze that preceded it, and the internal inconsistencies in the reported headcount.
* [The Sega contract NVIDIA could not fulfil](sega-dreamcast-contract.md) - Huang told Sega the technology did not work, advised them to hire someone else, and asked to be paid anyway.
* [The compendium skill: 1,500 pages overnight](spinoza-compendium-skill.md) - Five days before the keynote, an agent read three biographies and returned a chronology, the disagreements, sourced quotes, and ranked stage moments.
* [The napkin math that produced the TPU](tpu-napkin-math.md) - Three minutes of speech recognition per user per day would have required doubling Google's server fleet.
* [Waymo: 18 months to the demo, 15 years to the product](waymo-demo-to-product-timeline.md) - The concrete timeline behind the claim that a working demo is 1% of the work — and the exponential re-acceleration afterwards.
* [XB-1: Mach cutoff, and 115 days to re-legalising supersonic flight](xb1-mach-cutoff.md) - Boom demonstrated a sonic boom that never reaches the ground — which dissolved the regulatory argument rather than winning it.
