---
type: Case Study
title: "The Sega contract NVIDIA could not fulfil"
description: "Huang told Sega the technology did not work, advised them to hire someone else, and asked to be paid anyway."
tags: [nvidia, founder-psychology, fundraising, trust]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The situation

The project that revealed NVIDIA's founding algorithm was wrong was a partnership with Sega, which
had contracted the company to build the game console after Saturn — which turned out to be
Dreamcast. NVIDIA did not build Dreamcast.[^ss26-huang]

Huang went to Japan and told Sega's CEO that the roughly **$12 million contract** could not be
fulfilled because the technology did not work, and explained why. He advised them to choose someone
else to do it. And then he said he unfortunately still needed the money.

His retelling of the reply, which he says he can only imagine: so what you are telling me is that
what I contracted you to do, you cannot do — but you would like all the money on the contract. His
answer: you got it, that's exactly right. He adds that he was polite and humble about it.

# Why it worked

Huang's own reading, delivered to a room containing many investors: you do not invest in companies,
you invest in people. What Sega's CEO recognised was a person and a company he had trusted in the
first place and believed in, and would love to see make it to the next day. And if he had not given
them the money, they would have been out of business.

**$5 million** kept NVIDIA alive and bought Huang enough time to discover what to do.
(He states the contract as ~$12M and the amount that kept them alive as $5M; the talk does not
explain the difference — possibly a partial payment. Recorded as stated.)

# The postscript

Sega sold its stake the moment NVIDIA went public, reportedly for about $15 million. NVIDIA's IPO
valuation in 1999 was **$300 million** — which Huang notes was real money in 1999. Asked about the
present figure he says it is more than a trillion dollars; his interviewer frames the arc as zero
to five trillion over 34 years.

# What it illustrates

The immediately preceding event is the more famous one: realising in 1995 that both the algorithm
*and* the team's knowledge of the right approach were wrong, buying three textbooks from Fry's with
a couple of hundred dollars in his pocket, and handing them to the engineers. See
[/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md)
and [/concepts/accelerating-algorithm-domains.md](/concepts/accelerating-algorithm-domains.md).

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
