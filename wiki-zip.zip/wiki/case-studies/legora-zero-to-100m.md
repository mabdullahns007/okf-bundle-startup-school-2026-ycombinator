---
type: Case Study
title: "Legora: $1M to $100M ARR in about 18 months"
description: "The numbers behind Legora's run, the six-month sales freeze that preceded it, and the internal inconsistencies in the reported headcount."
tags: [legal-ai, growth, go-to-market, europe, metrics]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The figures as stated

From Junestrand's talk and Q&A:[^ss26-junestrand]

| Item | Figure |
|---|---|
| Market penetration claimed | over 3% of all the world's lawyers are active users |
| General availability | October 2024 |
| ARR run | $1M → $100M, described as reaching $100M in April, about 18 months |
| ARR at the time of the product manifesto | ~$1.3M (October 2024) |
| ARR referenced later in Q&A | ~$150M |
| Starting team | three engineers in Sweden |
| Headcount stated in the talk | over 750 people |
| Countries | ~50 |
| Benchmark investment | $9.51M |
| Cash after Benchmark + Redpoint | ~$35M, with ~10 people |
| Sales freeze | six months |
| Top salesperson | 23 years old, no sales background, >$10M sold |
| Founder-led interviewing | every non-engineering hire to ~500 people |

# The sequence

2020: a lawyer, a physicist, an engineer and a psychologist start an earlier company (rendered
"Judelica" in the auto-transcript) exploring Google BERT models against the observation that law
students spend internships summarising cases. Junestrand meets two eventual co-founders at a
volleyball game in the Swedish archipelago, sees a GPT-3.5-era demo explaining a stock option
agreement, and drops out of his master's.

May 2023: rejected by YC. Accepted two months later under a new name with a different platform.
During YC: $0 → $1M ARR, with Junestrand doing sales calls from 1am to 10am San Francisco time to
reach European customers, using a ring light clipped to his laptop.

Then the round, then the freeze, then the manifesto, then the run. See
[/concepts/deliberate-sales-freeze.md](/concepts/deliberate-sales-freeze.md) and
[/concepts/product-manifesto.md](/concepts/product-manifesto.md).

# ⚠️ Recorded inconsistencies

Two figures do not reconcile cleanly and are preserved rather than smoothed:

1. **Headcount.** The talk states "over 750 people" and "when you're 750 people." The Q&A then
   describes going "from 200 people to 1,300 people" in about one year, in a comparison with his
   CFO's previous company. It is unclear whether 1,300 is Legora's current headcount, a forward
   projection, or a figure belonging to the comparison company. Treat headcount as *750+, possibly
   toward 1,300*.
2. **ARR.** $100M is given for April; ~$150M appears later when contrasting the job of running
   sales at $1M versus $150M. These are consistent with continued growth between April and the
   July event, but the talk does not say so explicitly.

# What Junestrand himself says mattered

Notably, not these numbers. See [/concepts/love-the-hustle.md](/concepts/love-the-hustle.md).

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
