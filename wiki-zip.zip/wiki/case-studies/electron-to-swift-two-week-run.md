---
type: Case Study
title: "The two-week run that was still running"
description: "Rewrite the Electron app in Swift; run the old one in a VM, screenshot, compare pixel by pixel, don't stop until done."
tags: [agents, verification, orchestration, engineering]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# The prompt

Cherny wanted to know what the Claude desktop app — built in Electron, and by then fast and
reliable — would feel like as a native application. His method was a Claude session running in
Slack, and the setup is the interesting part because it was assembled by
conversation:[^ss26-cherny]

1. He asked whether it had access to a macOS runner on GitHub. It said no. He hooked one up, so it
   could start a Mac virtual machine.
2. He created an empty repository for the Swift rewrite and asked whether it could access it. It
   said no. He granted access.
3. Then the actual instruction: rewrite the Electron app in Swift; run the Electron app in the Mac
   VM; screenshot it; compare it pixel by pixel with the Swift version; **don't stop until you're
   done.**

# The run

Asked how long it took, his answer was that **it is still running** — a little over two weeks at
the time of the talk. He estimated thousands to tens of thousands of agents spawned, and said he
would have to ask the agent for the exact number.

One detail he reports with evident amusement: Claude also decided to live-blog it, creating an
internal Slack channel and posting screenshots of its progress every few minutes.

# What Cherny draws from it

His framing is explicitly about the *absence* of cleverness. You do not need the fancy scaffolding
— no `/goal`, no `/loop`. These help, but really all you need is to give the model the task and a
way to verify the output of its work so it does not get stuck, and it will just go. See
[/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md).

Note the shape of the verifier: not a test suite, as in
[/case-studies/bun-zig-to-rust-rewrite.md](/case-studies/bun-zig-to-rust-rewrite.md), but a
*perceptual* oracle — the old application itself, running, screenshotted, compared. The general
requirement is a checkable definition of done, not a particular technology for checking.

# The audience check

Cherny asked whether anyone in the room had gotten a model to run a task for more than two weeks,
and separately whether anyone had spawned more than a thousand agents. A few hands for the first;
none reported for the second.

# See also

- [/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md)
- [/concepts/product-overhang-and-unhobbling.md](/concepts/product-overhang-and-unhobbling.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
