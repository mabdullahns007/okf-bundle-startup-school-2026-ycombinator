---
okf_version: "0.2"
---

# Startup School 2026 — Knowledge Base

An [Open Knowledge Format](https://github.com/GoogleCloudPlatform/knowledge-catalog/blob/main/okf/SPEC.md)
v0.2 bundle covering all 15 talks from Y Combinator's **Startup School 2026** (the AI Startup School),
held in San Francisco around 26 July 2026 for roughly 6,000–7,000 attendees.

Built with the [LLM wiki pattern](../karpathy-llm-wiki.md): the talks are the raw sources, this bundle
is the LLM-owned synthesis layer, and [CLAUDE.md](../CLAUDE.md) is the schema. Every page here is
paraphrase and synthesis with per-claim footnotes back to the source talk — no transcript text is
stored in this repository.

**Trust status:** every content page is `status: draft` with no `verified` entry, which places the
whole bundle at OKF's *unverified* tier. Figures are attributed to the speaker who stated them, not
asserted as fact.

## Start here

* [Log](log.md) — what was ingested, what contradicts what, and what to do next.
* [Sources](sources/index.md) — one hub page per talk, and the
  [ASR caveats](sources/index.md#transcription-caveats) that apply to every page.
* [Concepts](concepts/index.md) — 113 synthesized pages across 10 themes. The bulk of the value.
* [Case studies](case-studies/index.md) — 10 worked examples with concrete numbers.
* [People](people/index.md) — 15 speakers plus one referenced absentee.
* [Organizations](organizations/index.md) — 15 companies and institutions.

## What the event was actually about

Reading across all fifteen talks, four arguments recur strongly enough to count as the event's
thesis, and one talk dissents from each:

**1. Conviction against consensus is the founding act.** Altman, Wang, Huang and Junestrand each
arrive at it independently — build on a belief the field thinks is wrong, and expect to be dismissed
for years. See [conviction against consensus](concepts/conviction-against-consensus.md). Altman
supplies the guard rail: if *nobody* shares the belief, that is itself information.

**2. The bottleneck has moved from capability to diffusion and context.** The models can already do
more than any product lets them; what is scarce is the harness, the owned context, and the
willingness to attempt something harder. See
[diffusion is the bottleneck](concepts/diffusion-is-the-bottleneck.md),
[product overhang and un-hobbling](concepts/product-overhang-and-unhobbling.md),
[personal AGI](concepts/personal-agi.md) and
[context engineering](concepts/context-engineering.md).

**3. Evals and metrics, not models, are the durable asset.** Dolgov states it most strongly — the
model is table stakes — and Dean, Wang and Junestrand converge on it from three different scales. See
[evals as the durable asset](concepts/evals-as-the-durable-asset.md). Cherny is the useful
dissenter: evals saturate within one to three model generations, so the *capability* to rebuild them
is the moat, not any file.

**4. Iteration velocity is set by unglamorous infrastructure.** Hodak's purchasing systems, Scholl's
machine shop, Steinberger's enjoyment, Cherny's ablations. See
[iteration velocity as the master variable](concepts/iteration-velocity-as-the-master-variable.md).

## The most useful disagreements

Where speakers genuinely conflict, both positions are kept rather than resolved. These are the
places where reading two talks together is worth more than reading either:

| Question | Positions |
|---|---|
| Launch early, or analyse first? | [Collison](sources/patrick-collison.md) waited two years with production users from month two; [Scholl](sources/blake-scholl.md) could not iterate at all and searched the design space analytically. See [lean startup in the AI era](concepts/lean-startup-in-the-ai-era.md). |
| Accumulate context, or delete it? | [Tan](sources/garry-tan.md) says build a library that compounds; [Cherny](sources/boris-cherny.md) says delete your `CLAUDE.md` every six months. Reconciled on the [ablation page](concepts/ablation-driven-harness-design.md): delete scaffolding, keep facts. |
| Will AI concentrate or distribute power? | [Altman](sources/sam-altman.md) treats concentration as the named failure mode; [Collison](sources/patrick-collison.md) dissents from data. See [concentration of power](concepts/concentration-of-power.md). |
| Does domain expertise matter? | [Junestrand](sources/max-junestrand.md), [Huang](sources/jensen-huang.md) and [Scholl](sources/blake-scholl.md) say no; [Hodak](sources/max-hodak.md) argues judgment is an oral tradition you must apprentice into. See [willingness to learn over domain expertise](concepts/willingness-to-learn-over-domain-expertise.md). |
| Read the code, or not? | [Steinberger](concepts/code-review-as-risk-management.md) replaces reading with calibrated risk judgment; [Cherny](concepts/verification-loops-over-specification.md) replaces it with a machine-checkable verifier. |

## The one talk with no AI in it

[Susan Kare](sources/susan-kare.md)'s account of designing the original Macintosh's font and icons
inside 16x16 one-bit bitmaps, with an editor that had no drawing tools and no undo. Its arguments
about [constraints](concepts/constraints-enable-creativity.md) and
[sparse metaphor](concepts/sparse-metaphor-over-literal-detail.md) transfer directly to token
budgets and harness design — which is why several of its pages are cross-linked from the robotics
and agent sections.
