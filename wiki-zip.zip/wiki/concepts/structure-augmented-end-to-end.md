---
type: Concept
title: "Structure that channels scale, not structure that fights it"
description: "A refinement of the bitter lesson: hand-built structure loses when it constrains the solution space and wins when it only helps you scale."
tags: [architecture, bitter-lesson, physical-ai, evaluation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

# The reframing

Dolgov accepts the bitter lesson — general methods leveraging massive compute and data beat
handcrafted human knowledge — and says Waymo has lived it through every wave. His refinement is
about *structure*: structure that fights scale always loses, and structure that channels scale
always wins. The test question is whether the structure limits your solution space or helps you
scale without loss of generality.[^ss26-dolgov]

# The Go thought experiment

Imagine a robot playing physical Go, with a camera watching the board and an actuator moving
stones. You could train pixels-to-actuation end-to-end from videos of humans playing — an
interesting research exercise, but not the way to build the world's best Go robot, because a
19x19 board is a simple intermediate representation that *completely* captures the state of the
game. Using it constrains nothing and helps enormously.[^ss26-dolgov]

No such clean representation exists for any non-trivial physical task — which, he notes, is
precisely why learned representations and end-to-end systems are needed. But real structure does
exist: laws of physics, rules of the road, objects that behave predictably.

# What Waymo buys with it

Their "structure-augmented end-to-end" augments learned embeddings with materialised structured
representations, yielding three things a black box cannot:

1. **Inference-time validation.** Because the model is not sensors-in/actuation-out, a real-time
   correctness and safety validation layer can run on the vehicle.
2. **Training and evaluation efficiency.** You can mix and match — some training and evaluation
   in the compact structured space, some in the full sensor-to-actuation space — instead of
   being forced end-to-end for everything.
3. **Verifiable feedback signals** for metrics, loss functions and reinforcement-learning
   recipes. The same structure also carries into simulation. See
   [/concepts/closed-loop-simulation.md](/concepts/closed-loop-simulation.md).

His summary: bet on a system that is maximally learned and minimally constrained, and use
structure intentionally to improve scaling laws in both training and evaluation.

# A dissent on the bitter lesson generally

[Garry Tan](/sources/garry-tan.md) answers the "just wait for the next model" version of the
bitter lesson differently: each release moves the differentiator further toward context, because
a smarter reader extracts more from the same library.[^ss26-tan]

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
