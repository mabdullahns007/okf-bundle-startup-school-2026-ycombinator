---
type: Concept
title: "Ablation-driven harness design"
description: "Delete the system prompt every model generation, then add lines back one at a time only where the model repeatedly stumbles."
tags: [agents, harness-design, evals, prompting]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# The method

Cherny describes the Claude Code harness as always changing: each new model prompts deletion of
much of the system prompt, changes to the tool set, and changes to the tool prompts, because a
behaviour correction written for one model may not transfer at all to the next. For Opus 5 they
removed over 80% of the system prompt, since the model already did what the prompt had been
correcting for.[^ss26-cherny]

The technique is borrowed from research: an *ablation* is an eval where you delete things to
measure their impact. Delete everything, then use the product, then add a line back only when
you see the model stumble on the same thing repeatedly — because the model reads that
instruction on every single call.[^ss26-cherny]

Two knobs he mentions for doing this deliberately: a flag to set an arbitrary system prompt,
and an undocumented "simple mode" environment variable that strips all system prompts including
the tools'. His finding is that the model is slightly *more* intelligent with no prompts — and
that some prompts nonetheless exist so the product behaves as a person would want.

# The generalisation

Cherny extends it to users of agent tools: every six months delete your `CLAUDE.md`, your
skills and your hooks and see what happens. And to builders: 100% yes, be comfortable pressing
delete.[^ss26-cherny]

# Tension worth noting

This is in real tension with [/concepts/personal-context-as-a-compounding-asset.md](/concepts/personal-context-as-a-compounding-asset.md),
which argues for accumulating an owned context library. The reconciliation is that the two
target different things: *corrective scaffolding* decays with each model generation, while
*facts about your life and your customers* do not.

# See also

- [/concepts/product-overhang-and-unhobbling.md](/concepts/product-overhang-and-unhobbling.md)
- [/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
