---
type: Concept
title: "Skill files as employees, resolvers as org charts"
description: "A page of English with one job. If a smart intern could follow it, an agent can run it."
tags: [skills, agents, org-design, markdown]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# What a skill actually is

Tan is insistent on demystifying this. His real (lightly redacted) example: when a meeting
recording lands, transcribe it with speaker labels, extract the commitments made and who made
them and by when, cross-check every person named against the library and link their pages, file
the summary here and the full transcript there, and if anything contradicts something already
believed, *flag it — do not overwrite it*.[^ss26-tan]

That is the whole thing: a page of English. His test — if a smart intern could follow it, an agent
can run it.

# The org-design frame

- A **skill file is an employee**: one capability, one job, written down clearly enough that
  someone new could execute it.
- A **resolver is an org chart**: a task comes in and it decides which file handles it.

Which means, in his framing, that before you incorporate anything — before a co-founder, a logo
or a deck — you can already be running an organisation of one plus your agents, with headcount
being whatever you decide.

# Markdown is code

His most-contested claim, which he says he has taken flak for and believes more than ever: if you
can write clear instructions in English you are a programmer, and the compiler is a language
model. His evidence is who is doing it at YC — media staff, event staff and finance people who
have never opened a terminal, one of whom compiled about a hundred Excel workbooks into a single
app. "She is not a programmer. She is a manager of agents now."

# The discipline that makes it compound

Never do one-off work. At the end of every task, ask the agent to *skillify* what it did. His
in-house formulation: if you have to ask for something twice, you failed.

# Corroboration

[Jeff Dean](/sources/jeff-dean.md) uses the same primitive for expert engineering procedure — see
[/concepts/skills-as-encoded-method.md](/concepts/skills-as-encoded-method.md) — and
[Alexandr Wang](/sources/alexandr-wang.md) confirms the mechanics are just skills, markdown files
and cron jobs.[^ss26-wang]

# See also

- [/concepts/own-your-skill-files.md](/concepts/own-your-skill-files.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
