---
type: Concept
title: "Regulatory strategy: engage early or launch anyway"
description: "There is no one-size answer; it depends on whether an entrenched incumbent is using the regulator against you."
tags: [regulation, strategy, policy, safety]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

# Scholl's framework

Asked whether to engage regulators before deploying or deploy and legitimise after, Scholl says
it is contextual, and contrasts two cases.[^ss26-scholl]

**Launch anyway.** Uber essentially ignored regulators, built the service, and built a fan base
it could use against regulators trying to shut it down. Scholl thinks befriending them first
would not have worked, because there was an *active opponent*: the incumbent taxi industry using
regulators to block competition. He generalises that this is the usual pattern in regulation — not
a well-meaning person protecting the public but a lazy entrenched interest running to a regulator
to shut down a competitor — and calls that deeply unethical while noting it happens constantly.

**Engage early.** That was never going to work in aviation, and Boom had no entrenched enemy —
Boeing thought them cute and unlikely to succeed, so they flew under the radar. Building a
safety-critical product, they went to the FAA at the start, explained what they were doing and
why it mattered, asked for help and feedback, invited them to see anything at any time, and
showed plans before finalising them. Result: an approvals process that can stretch for months
even for an R&D aircraft took **90 minutes**, and they received the first-ever permit for civil
supersonic flight before the aircraft had flown at all. His framing of why: *Boom plus FAA versus
the problem, not Boom versus FAA.*

And his broader claim: people say building in a regulated industry is a bad idea, but you can
change the regulations — by building the thing and communicating why it is fine. See
[/case-studies/xb1-mach-cutoff.md](/case-studies/xb1-mach-cutoff.md).

# The view from the other side of the table

[Michael Kratsios](/sources/michael-kratsios.md) describes the same terrain as
[/concepts/born-free-vs-born-in-captivity.md](/concepts/born-free-vs-born-in-captivity.md), and
independently names supersonic flight as his favourite example — with the fix being a noise
limit rather than a speed limit.[^ss26-kratsios]

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
