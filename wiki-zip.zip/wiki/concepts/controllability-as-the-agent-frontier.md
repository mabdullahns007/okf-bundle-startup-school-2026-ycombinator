---
type: Concept
title: "Controllability as the agent frontier"
description: "Agents need not be perfectly accurate; they need fine-grained steering — change one word in a plan and have everything regenerate around it."
tags: [agents, control, human-in-the-loop, tooling]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The claim

Jensen Huang argues the single biggest breakthrough still needed for agents at every level is
controllability. His reasoning: coarse recursive self-improvement already works, but the
available control surfaces — RAG, conditional inputs, whole prompts — are too coarse relative
to output.[^ss26-huang]

What he wants instead is fine-grained collaboration: change one word in a plan file and have
that word make a *specific* difference, not a complete one, while everything else regenerates
around it. His examples are deliberately drawn from design work — one pixel, one triangle, one
component in a CAD file, one layer, one via, one connection.[^ss26-huang]

# Why this reframes the accuracy debate

His explicit position is that agents do not need to be 100% accurate to be used: 80% plus
human help, or 99% plus human help, is fine — *provided the help can be applied precisely.*
That moves the research target from raw quality to the steering interface.

# See also

- [/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md)
- [/concepts/latent-vs-deterministic-computation.md](/concepts/latent-vs-deterministic-computation.md)
- [/concepts/self-maintaining-codebases.md](/concepts/self-maintaining-codebases.md)

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
