---
type: Concept
title: "Decision support vs direct action"
description: "Every profitable ML deployment so far kept a human in the decision; that is what made imperfection tolerable."
tags: [physical-ai, reliability, product, ml-history]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

# The observation

Chelsea Finn reads the history of ML in production — product recommendations and ad ranking, then
deep learning applied to the same, then ChatGPT as the first genuinely general-purpose model in
wide use, then coding agents — and notices something all of them share: the customer makes the
decision based on the model's recommendation. So a mistake is usually recognisable and
recoverable, which relieves the pressure to be perfect and is why imperfect systems were still
enormously useful and profitable.[^ss26-finn]

Physical AI breaks that. It makes decisions that affect the physical world directly, and it is
*far more useful when fully autonomous* — so it must make far fewer mistakes than any ML system
deployed to date.

# The existence proof

Her cited grounds for optimism is Waymo passing a quarter of a million weekly autonomous rides,
which she takes as evidence that a machine-learning-based system can operate trustworthily and
autonomously in the physical world. See [/organizations/waymo.md](/organizations/waymo.md) and
[/concepts/four-gaps-of-physical-ai.md](/concepts/four-gaps-of-physical-ai.md).

# The design consequence

This is why her talk's first half is about long-term autonomy rather than capability: the target
is not a robot that can make espresso, but one that makes espresso reliably enough that nobody
babysits it. See [/concepts/robot-rl-with-human-interventions.md](/concepts/robot-rl-with-human-interventions.md).

[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
