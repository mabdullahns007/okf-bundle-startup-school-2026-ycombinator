---
type: Concept
title: "Schlep blindness, revisited"
description: "Nobody starts a company to set up payroll — but the tedium at the surface can hide the most interesting business underneath."
tags: [strategy, product, motivation, yc-lore]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
---

# The original idea

Paul Graham's term, and Stripe its canonical example: founders avoid ideas that involve tedious,
unglamorous work, which leaves those ideas unexploited. See [/people/paul-graham.md](/people/paul-graham.md).

# Collison's own account

Asked what intellectual rewards he gave up, he grants the premise: in any company there is a bunch
of stuff that is not rewarding or interesting in itself — nobody starts a company so they can set
up payroll — and building business financial services produces more arcane and extensive versions
of that.[^ss26-collison]

# But the frame inverts at the whole-company level

His answer is that in the *totality* of Stripe he finds it extremely interesting, because they work
with the world's most interesting and innovative companies through the entirety of their journey —
from incorporation through to being Shopify or OpenAI — hearing their feedback and requests. Every
business is an applied theory about how part of the world works. So the business as a whole turned
out to be the opposite of the schlep-blindness instinct.

The interviewer's framing of why this is interesting: Collison had academic interests in physics
and is plainly a deep intellectual, which makes his choice of an apparently tedious domain a real
test of the idea.

# The generalisable claim

Schleps are surface features. The question worth asking is not whether the work looks tedious from
outside but whether the domain will keep teaching you something — which is the same question as
[/concepts/what-if-you-succeed.md](/concepts/what-if-you-succeed.md).

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
