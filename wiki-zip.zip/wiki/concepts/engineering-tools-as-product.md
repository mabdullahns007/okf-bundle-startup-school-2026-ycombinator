---
type: Concept
title: "Engineering tools as the actual product"
description: "Spreadsheet engineering is code treated as a second-class citizen; move it into software and the iteration loop collapses."
tags: [engineering-tools, hardware, simulation, iteration-velocity]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The diagnosis

Great software is modular; great aircraft are the opposite. Scholl's example: add a row of
passenger seats and the fuselage gets heavier, the engines must get more powerful, the wings must
be redesigned — everything changes. Classically that meant a large team of specialists each
working in their own spreadsheet, handing analysis results to one another, until eventually
someone declared the design good enough and it was time to build.[^ss26-scholl]

His indictment: spreadsheet engineering *is* code, being treated as a second-class citizen with
no automated integration, no automated testing, no continuous integration.

# What they built instead

- **Makeboom** — define an aircraft in a configuration file, run a script, and get a whole-vehicle
  simulation in minutes: range, fuel burn, passenger capacity, trade-offs.
- **Bladerunner** — change a turbine blade design in real time and see the structural and
  aerodynamic consequences, reducing to real time what previously took dozens of engineers many
  months.

# The second-order use

The tools were not only for evaluating design ideas but for *searching the space* of conceivably
buildable supersonic aircraft to decide which one to build — because you cannot reach
product-market fit on a supersonic jet by building it and seeing if anyone likes it. See
[/concepts/lean-startup-in-the-ai-era.md](/concepts/lean-startup-in-the-ai-era.md).

Scholl notes AI is dropping the cost of software development, so many more custom engineering
tools are now affordable than would have been before.

# The parallel

[Max Hodak](/sources/max-hodak.md) built the equivalent for company operations rather than
physics. See [/concepts/internal-software-as-competitive-advantage.md](/concepts/internal-software-as-competitive-advantage.md).

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
