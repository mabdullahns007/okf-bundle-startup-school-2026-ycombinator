---
type: Concept
title: "Optimise for the worst day and the best day"
description: "Boom got to seven days of cash and was told to shut down. Believing the thing mattered is what made refusing possible."
tags: [resilience, founder-psychology, mission]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The claim

Scholl's framing: as a founder you really have to optimise for two days — the worst day and the best
day. There is no such thing as a startup without tough days.[^ss26-scholl]

**The worst day.** On the way to breaking the sound barrier, Boom nearly failed several times.
There was a moment when they were down to **seven days of cash** and the board told him to shut
the company down. He told them no — that they would get through this, they just had not found the
way yet. And they did.

**The best day.** Watching the team pull the aircraft out of the hangar, watching the pilot push
the throttles forward, and seeing that they had broken the sound barrier.

His conclusion, and the reason he frames it as a design constraint rather than a virtue: he was
able to keep going because he believed what they were creating was important and wanted it to exist
in the world. Which is why you have to build things that matter — *not just to yourself but to the
world* — because that is what carries you through the inevitable ups and downs.

# The same mechanism, described differently

[Jensen Huang](/sources/jensen-huang.md)'s version is temporal rather than motivational: you do not
have to overcome life in one day, only this morning. See
[/concepts/how-hard-can-it-be.md](/concepts/how-hard-can-it-be.md).

[Max Junestrand](/sources/max-junestrand.md)'s is about where the meaning actually lives — not in
the big moments but in the windowless room and the 2am Slack channel. See
[/concepts/love-the-hustle.md](/concepts/love-the-hustle.md).

# See also

- [/case-studies/xb1-mach-cutoff.md](/case-studies/xb1-mach-cutoff.md)
- [/case-studies/sega-dreamcast-contract.md](/case-studies/sega-dreamcast-contract.md)

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
