---
type: Concept
title: "Preemption and Little Tech"
description: "A patchwork of state AI rules is survivable for a company with an army of lawyers and fatal for a two-person startup."
tags: [policy, regulation, startups, lobbying]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

# The argument

Asked how a two-person company has a fighting chance when the five biggest tech companies
dominate policy conversations, Kratsios pointed to consultation mechanisms — requests for
information and comment that let anyone submit views — and then to his substantive
example.[^ss26-kratsios]

Federal preemption of state AI law. The thesis: allow a patchwork and you get one set of AI rules
in California, another in Maryland, another in Texas. The big companies can deal with that — they
can hire an army of lawyers and be fine. For a startup it simply does not work. So one national
standard, so that anyone wanting to build an AI company knows the single set of rules, is the
pro-startup position — and he says the president made it a priority in the speech accompanying
the strategy's release.

He also notes this is not unique to tech: large-player influence occurs in energy, healthcare and
everything else.

# The organising response

The interviewer described the counterweight from the industry side: YC and a handful of other
companies helped spin up a **Little Tech Association** trade group, on the observation that in
Washington almost every position paper or speech reads as having big-tech influence behind it. He
also credited continuity across administrations in the big-tech antitrust cases, and the
president's own use of the phrase "Little Tech."

# The asymmetry that makes this hard

Because executive orders are revocable and laws are not, preemption specifically needs Congress.
See [/concepts/regulating-a-moving-frontier.md](/concepts/regulating-a-moving-frontier.md).

# See also

- [/concepts/concentration-of-power.md](/concepts/concentration-of-power.md)

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
