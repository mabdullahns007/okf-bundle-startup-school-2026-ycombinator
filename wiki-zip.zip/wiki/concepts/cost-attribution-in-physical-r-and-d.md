---
type: Concept
title: "Cost attribution in physical R&D"
description: "Buy in bulk and nobody knows what an experiment costs — so experiments feel free, because they cost media and media comes from the fridge."
tags: [operations, deep-tech, burn, internal-software]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The problem

Controlling total burn turns out not to be the real problem — you can always compute runway. The
harder problem is *attribution*. Anything touching the real world buys in bulk — Hodak lists
gases from argon to silane to nitrogen, resins, media — and parts them out across many
experiments. Attribution breaks, so nobody knows what an experiment costs. His formulation of the
resulting belief: therefore experiments are free; they do not cost dollars, they cost media, and
media comes from the fridge.[^ss26-hodak]

You also cannot price what you make. Estimating it requires spreadsheets full of genuine
opinions — how much rent to include, how much tool depreciation, what future volume you assume —
and that same analysis is what tells you your real spend and runway.

# The fix, and the number it produced

Science built extensive internal software (Helix) in which essentially every action is a button
and every lab step is a database record, so costs correlate through from purchasing to
manufacturing. The result for one wafer iteration on a given protocol: **$40,000**.[^ss26-hodak]

# Why that number matters

His arithmetic: a $20M Series A meant to last four years, with roughly half of burn as headcount
(~20 people, ~$3M/year), plus 20,000 square feet at about $4 per square foot per month adding
$750K–1M a year, leaves roughly $3M a year for research. That goes far faster than founders
expect — especially with a team that just watched you raise more money than they have ever seen
and assumes the power supplies are free.

His conclusion: this infrastructure determines success or failure in many companies.

# See also

- [/concepts/procurement-and-budgeting-as-infrastructure.md](/concepts/procurement-and-budgeting-as-infrastructure.md)
- [/concepts/internal-software-as-competitive-advantage.md](/concepts/internal-software-as-competitive-advantage.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
