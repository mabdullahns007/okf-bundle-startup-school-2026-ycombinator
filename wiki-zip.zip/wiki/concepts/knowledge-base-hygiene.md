---
type: Concept
title: "Knowledge-base hygiene"
description: "A brain nobody curates is a garbage dump with great search; provenance, contradiction checks and pruning are the primitive."
tags: [knowledge-management, provenance, memory, reliability]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

# The caveat Tan volunteers

Before his how-to section, Tan states the failure mode plainly: a brain nobody curates is a
garbage dump with great search. Retrieval will surface a stale fact with total confidence, and a
bad skill file encodes a bad process forever.[^ss26-tan]

So the primitive is not memory but **memory plus hygiene**, with three named components:

1. **Provenance on every fact** — where did this come from.
2. **Contradiction checks** — when new information collides with old, surface the collision.
3. **A librarian whose actual job is pruning.**

His summary: treat the brain like production infrastructure and it compounds; treat it like a
dumping ground and you get a very confident agent that is wrong in ways nobody can trace.

Note that his own example skill file encodes rule 2 directly: *if anything contradicts something
we already believe, flag it — don't overwrite it.* See
[/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md).

# Why this page exists in this wiki

This is the design constraint the bundle you are reading is built to satisfy — per-claim
footnotes back to source records, an append-only [/log.md](/log.md), explicit contradiction
notes where speakers disagree or misspeak, and `status: draft` until a human verifies. The
[/index.md](/index.md) is the librarian.

# See also

- [/concepts/library-and-librarian.md](/concepts/library-and-librarian.md)
- [/concepts/personal-context-as-a-compounding-asset.md](/concepts/personal-context-as-a-compounding-asset.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
