---
type: Concept
title: "The 1% rule for picking an AI problem"
description: "Test the current general model on your domain: 0-1% success is a good sign; 20% means the capability is already emerging."
tags: [strategy, problem-selection, moats, evals]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
---

# The heuristic

Jeff Dean's screening test for founders worried about being obsoleted by the next model
release: run the best general model on your domain now. If it fails essentially completely —
succeeding 0% or 1% of the time — that is a good sign. If it half-works at around 20%, that is
*not* a good sign, because the capability is already present in nascent form and more data or
scale will likely finish it.[^ss26-dean]

He pairs this with an explicit time question: is the thing you are building durable, or will
frontier models get good at it in six months, twelve months, or three years — and weigh that as
you choose.

# The two structural advantages he names

1. **Data the general model cannot see.** His memorable framing: Google has organising the
   world's information fairly well covered; organising *your own* personal information is open.
   A product with visibility into private data has a real advantage.[^ss26-dean]
2. **Narrow models that are cheap but highly accurate.** On the AlphaFold pattern — a very
   specific, highly successful protein-structure model that is not general at all. He names
   materials science and chip design as domains where the shape may repeat.

# The counterweight

Dean is careful to caution that general models keep getting better across a broader range, and
his first selection criterion is not defensibility but whether you actually want to build the
thing. [Patrick Collison](/sources/patrick-collison.md) argues the incumbent-fear version of
this worry has a checkered historical record — see
[/concepts/will-the-labs-eat-my-startup.md](/concepts/will-the-labs-eat-my-startup.md).

# See also

- [/concepts/product-overhang-and-unhobbling.md](/concepts/product-overhang-and-unhobbling.md)
- [/concepts/build-one-step-ahead-of-the-models.md](/concepts/build-one-step-ahead-of-the-models.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
