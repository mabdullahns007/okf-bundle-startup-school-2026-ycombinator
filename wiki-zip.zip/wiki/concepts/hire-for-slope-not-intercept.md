---
type: Concept
title: "Hire for slope, not y-intercept"
description: "Legora's unlearned pattern: a prestigious resume is a high starting point, but without an upward trajectory it fails in an exponentially scaling company."
tags: [hiring, talent, culture]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# The pattern they had to unlearn

Junestrand names optimising for fancy logos on resumes as a hiring mistake they made early, and
gives it a name: **y-intercept**. Someone's skill curve may start very high, but if it does not
have a good upward trajectory they will have a really hard time in a company scaling
exponentially.[^ss26-junestrand]

What they looked for instead: people like themselves who wanted to work insanely hard, with very
high growth potential — and they doubled down on that profile repeatedly.

# The evidence he offers

At the time of the talk, Legora's top salesperson was 23 years old, had no sales background, came
straight out of university, and had sold over $10 million of the product.

# The founder-led filter behind it

He personally interviewed every non-engineering candidate up to around 500 people, and every
director and above thereafter — and claims the cultural foundation now self-selects. See
[/concepts/culture-against-local-norms.md](/concepts/culture-against-local-norms.md).

# The convergent view from a very different industry

[Blake Scholl](/sources/blake-scholl.md) arrives at the same profile from aerospace, where the
experienced talent pool comes from cultures he considers bad: value early-career people who are
young, ambitious, smart, hands-on and *not yet destroyed* by legacy incumbents — and promote from
within at senior levels, because people grown up in your own culture are much better.[^ss26-scholl]

# The tension with experience

Both are arguing against credentials, not against knowledge — see Scholl's hard rule about calling
someone who has done it before in
[/concepts/hiring-for-evidence-of-exceptional-ability.md](/concepts/hiring-for-evidence-of-exceptional-ability.md).

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
