---
type: Concept
title: "Product overhang and un-hobbling"
description: "At every model generation the model can already do things no product lets it express; products routinely get in the way."
tags: [agents, product, harness-design, elicitation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# The pair of ideas

**Product overhang** is the gap between what today's model can already do and what any
shipped product lets it do. **Hobbling** is the product actively getting in the way. Boris
Cherny presents them as two faces of the same thing, and as the main commercial opportunity
available to a startup.[^ss26-cherny]

# The founding example

The original Claude Code was this move. Contemporary coding products offered single- and
multi-line autocomplete and read-only chat, while Sonnet 3.5 could already write whole files.
The product decision was to remove the scaffolding and give the model the simplest possible
harness so it could write a file, then a feature.[^ss26-cherny]

# How to find overhang

Cherny gives two methods: keep throwing the newest model at a business problem a previous
model failed, because a new one may simply do it; and experiment playfully without a
commercial target — an internal example was discovering that a model given OpenCV can draw
recognisable portraits and landscapes, a capability nobody trained.[^ss26-cherny]

[Jeff Dean](/sources/jeff-dean.md) offers the complementary screening heuristic from the
outside — see [/concepts/the-one-percent-rule.md](/concepts/the-one-percent-rule.md) — and
[Alexandr Wang](/sources/alexandr-wang.md) makes the same argument at the level of the whole
economy in [/concepts/diffusion-is-the-bottleneck.md](/concepts/diffusion-is-the-bottleneck.md).

# See also

- [/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md)
- [/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
