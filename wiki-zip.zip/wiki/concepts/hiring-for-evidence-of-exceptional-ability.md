---
type: Concept
title: "Hiring for evidence of exceptional ability"
description: "Concrete evidence that separates a person from their high school class — ideally winning at legible competitive games."
tags: [hiring, talent, evaluation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# Hodak's criterion

Asked what counts as evidence of exceptional ability, Hodak's answer is anything concrete you can
put your finger on that separates that person from their high school class. His stated ideal:
**winning at legible competitive games** — being a chess grandmaster, winning Design-Build-Fly or
Formula SAE. He notes several Silicon Valley deep-tech companies are essentially built out of
Formula SAE winners who spent college building things and racing them. His reasoning: it is tough
to know you are exceptional without some competitive feedback.[^ss26-hodak]

His other observation: it is uncommon for someone to reach their mid-twenties without *something*
in their background they sought out and did — while conceding the criterion is very open-ended.

On evaluating engineers he says they never really used LeetCode, and increasingly do not evaluate
programming directly but *thinking*: give a domain, see how it is decomposed, check whether the
problem structure is understood clearly. His remark on why software attracts the smart: the
feedback loop is addictively fast — an idea can be built in hours, where a biological idea takes
months to test.

# Scholl's version, plus the one hard rule

[Blake Scholl](/sources/blake-scholl.md) asks for side projects and the most impressive thing you
have built, with pictures, and notes he will hire people with no work experience if they have done
something extraordinary — pointing out that the best people find ways to do things at abnormally
young ages, so the notion that you must be a junior in college to get an internship is
nonsense.[^ss26-scholl]

His one experience rule at Boom: it is fine for a young engineer to do something they have never
done, just as it is fine to do something *nobody* has ever done. But if someone in the world has
done it before, you must find them, call them, and hear their advice — you need not take it.

# The AI-resistant homework problem

Hodak's requirement for take-homes now: tasks that do not saturate, have a very high ceiling, and
score to two or three numbers you can plot, so beating the frontier is visually obvious and it does
not matter which models were used. His example of the genre is GPU-kernel optimisation with a
model's own performance as the bar. See
[/concepts/distributed-hiring-funnel.md](/concepts/distributed-hiring-funnel.md).

# What to look for in colleagues

[Jeff Dean](/sources/jeff-dean.md) adds the other half: skills the team needs, but also people you
delight being around — low ego, team players, complementary skills — because working in a small team
where others know things you do not is how you both add tools to your tool belt.[^ss26-dean]

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
