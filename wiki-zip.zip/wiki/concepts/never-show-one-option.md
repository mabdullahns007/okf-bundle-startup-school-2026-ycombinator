---
type: Concept
title: "Never show one option"
description: "Hertzfeld's advice on showing work to Jobs: show a few, so he can be involved, reject something, and still pick something."
tags: [design, feedback, management, decision-making]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Susan Kare"
    last_modified: 2026-08-14
---

# The advice

From Andy Hertzfeld, on how to show work to Steve Jobs, and recorded in Kare's closing collection:
do not show him one thing, because he will say he does not like it — which may force you to go and
do it again and be better. But if you show a few things, he can be involved, say that something is
terrible, and still pick something.[^ss26-kare]

# Why it generalises

It is a claim about what a reviewer's role becomes under each format. A single option makes the
reviewer a judge, whose only available contributions are approval or rejection. Several options
make them a participant, whose contribution is a choice — and a choice carries information about
preferences that a rejection does not.

Note that Kare's own presentation of her work follows the pattern. Her Swatch alarm-clock sequence
is a spread of options — a clock made noisier, then more literal, then louder, then simpler, then a
travel clock, then one she judged too self-referential (why would you want a clock on a clock) —
and her stated point about the spread is that this is so *not* an exact science.

# The companion practice

She also brought bitmap sketches drawn on graph paper to her Apple interview without being told
what to make — a pond with a boot, some pieces of paper, a fragment of an alphabet. Some of those
apparently random things ended up slightly influencing what shipped in the software.

# See also

- [/concepts/show-dont-tell-make-it-visual.md](/concepts/show-dont-tell-make-it-visual.md)
- [/concepts/how-to-commission-creative-work.md](/concepts/how-to-commission-creative-work.md)

[^ss26-kare]: Susan Kare, [Susan Kare: Designing Icons & Graphics For the Original Mac](/sources/susan-kare.md), Startup School 2026.
