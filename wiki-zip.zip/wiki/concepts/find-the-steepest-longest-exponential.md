---
type: Concept
title: "Find the steepest, longest exponential"
description: "Wang's message to his younger self: identify the curve with the steepest slope that will run longest, and accept a boring starting point."
tags: [strategy, timing, technology-waves]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

# The advice

Alexandr Wang's second piece of advice to his 18-year-old self: identify the exponential in the
world with both the steepest curve and the longest runway. Decades ago that was Moore's law,
which he says was clearly the right thing to invest in at the time. Right now he thinks it is AI
progress — and he expects there will be more such curves later.[^ss26-wang]

His important qualifier: it is fine if the curve's starting point is boring or does not even seem
interesting. When he started Scale the state of the art was cat detectors in YouTube videos, and
it was hard to tell a story in which that was the most important technology of the era — but it
was on an unbelievable exponential.

# The complementary observation

[Sam Altman](/sources/sam-altman.md)'s version is about *when* rather than what: startups cluster
when the technology landscape moves quickly, costs fall and cycle times shorten, and incumbents
lose their advantage. His examples are the late-1990s internet boom, the Facebook app platform,
and the iPhone App Store — and he argues all those conditions hold now.[^ss26-altman]

Altman adds the epistemic half, attributing it to Paul Graham: the world does not know how to
intuit exponentials, which is how it missed deep learning. So there are new exponentials forming
now, and being grateful the world does not yet understand them is a superpower.

# See also

- [/concepts/ten-x-waves.md](/concepts/ten-x-waves.md)
- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
