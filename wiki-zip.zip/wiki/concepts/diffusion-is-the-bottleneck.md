---
type: Concept
title: "Diffusion, not capability, is the bottleneck"
description: "If models stopped improving today there would still be decades of economic upheaval left in deploying what already exists."
tags: [strategy, adoption, economics]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
---

# The claim

Wang's central strategic assertion: the bottleneck is not the progress of the models, it is
diffusing them through the rest of the world and helping the world adapt. If capability froze
today there would still be decades of total upheaval in the economy and in how the world
operates — which is what makes this, in his phrase, a once-in-a-civilization opportunity to hold
a vision and impose it.[^ss26-wang]

He pairs it with a builder's obligation: the world is barely ready for the technology, so
builders have a responsibility to help enterprises and governments adapt, and to work out
biosecurity and cybersecurity.

# The product-level version

[Boris Cherny](/sources/boris-cherny.md)'s product overhang is the same claim at the level of a
single application: today's models can already do things no product lets them do, and startups
are not capturing it.[^ss26-cherny] See
[/concepts/product-overhang-and-unhobbling.md](/concepts/product-overhang-and-unhobbling.md).

# The measured version

[Patrick Collison](/sources/patrick-collison.md) supplies the demand-side evidence: buyers are
now spring-loaded because the risk of the status quo reads as high, which is why enterprises sign
with companies in their first ninety days.[^ss26-collison] See
[/concepts/business-formation-data-2026.md](/concepts/business-formation-data-2026.md).

# Why this reframes the "are we hitting a wall" debate

Wang's position is that the debate is close to irrelevant to a builder: powerful models are
inevitable, the civilisational trend is what matters, and arguing about timing will look
short-sighted in retrospect.

# See also

- [/concepts/rising-ambition-ceiling.md](/concepts/rising-ambition-ceiling.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
