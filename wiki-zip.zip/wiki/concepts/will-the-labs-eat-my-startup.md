---
type: Concept
title: "Will the labs eat my startup?"
description: "Collison separates two fears — that the labs will expand into you, and that raw capability will obviate you — and rates them differently."
tags: [strategy, competition, moats, incumbents]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

# The separation

Collison's most useful move is to split the question in two: will rapidly improving AI capability
do this, or will the labs *specifically* do it?[^ss26-collison]

# On the labs specifically

He argues the track record of "what if the big company does this" is checkered. Twenty years ago at
Auctomatic the question was always what if Google does it — and Google seemed omnipotent, with an
immense number of talented people and essentially infinite capital and servers. But human
organisations are complicated, and it is very hard to aggressively prosecute a hundred priorities
while managing the interference among them. Google has done incredibly well in a bunch of specific
places, and it is not the case that Google has done all the things, even where it materially could
have. His verdict: that fear has generally been overstated.

# On capability itself

He grants this one more readily. Even if the labs are not especially ambitious about expanding
scope, longer context or agentic capability will obviate some verticals or tasks — hard to say
which, contingent on your forecast of model capability, but certainly in some cases, and in some
domains it has already happened.

# The practical screen

[Jeff Dean](/sources/jeff-dean.md) supplies the test that operationalises Collison's second
category: check what the current general model does in your domain, and treat partial success as
the warning sign.[^ss26-dean] See
[/concepts/the-one-percent-rule.md](/concepts/the-one-percent-rule.md).

[Sam Altman](/sources/sam-altman.md) — running one of the labs in question — argues startups become
*more* important as capability grows, because they are the mechanism by which the technology's
power is distributed rather than concentrated.[^ss26-altman] See
[/concepts/concentration-of-power.md](/concepts/concentration-of-power.md).

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
