---
type: Concept
title: "Work on what you love, not what you know"
description: "Knowledge is changeable; passion is not — and Scholl calls 'work on what you know' the worst advice he received."
tags: [career, motivation, founder-psychology]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The anti-advice

Asked for the worst advice he ever received, Scholl names his mother's well-meaning question:
shouldn't you work on something you know something about?[^ss26-scholl]

His evidence that it is wrong is his own first company. His resume said e-commerce (early Amazon)
and mobile (one of the very first mobile app companies), so he built mobile e-commerce. He knew
*how* to do it — and had no idea what mobile e-commerce should *be*, did not care about what they
were building, cranked out high-quality apps, had no product vision and was not having a good time.

His formulation: knowledge is changeable, particularly in a world where everyone has a personalised
AI tutor, and anybody with passion and dedication can learn new knowledge and new skills. What you
cannot easily change is what you love — so there has never been more reason to work on what you
love.

# The hiring corollary

It is the same claim he makes about people: you can teach skills and knowledge, and any kind of
engineering can be learned, but the one thing he has never been able to teach anyone is to *care*
when they did not. So look for people who care — in partners, professionally and personally.

# The convergent versions

[Jeff Dean](/sources/jeff-dean.md)'s first selection criterion is not defensibility but whether you
are excited enough to want to build it, because if you wake up not wanting to do it you are already
behind — and his closing test is whether, in the best possible outcome, the world would be
meaningfully better or would merely shrug.[^ss26-dean]

[Jensen Huang](/sources/jensen-huang.md) grounds it differently: he could not know what he was
capable of except by picking something that mattered to him and giving it everything, so as to find
his limits — which is also Scholl's stated reason for attempting Boom.[^ss26-huang]

# See also

- [/concepts/what-if-you-succeed.md](/concepts/what-if-you-succeed.md)
- [/concepts/optimize-for-the-worst-day-and-the-best-day.md](/concepts/optimize-for-the-worst-day-and-the-best-day.md)

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
