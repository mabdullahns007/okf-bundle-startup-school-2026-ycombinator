---
type: Concept
title: "Latent space vs deterministic space"
description: "Taste and judgment belong in the model; arithmetic and scheduling belong in code. Confusing the two causes every agent failure."
tags: [agents, architecture, reliability, design]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The distinction

Tan calls this the most important question to ask when designing an agent system — where is the
computation happening — and says there are exactly two answers, and that confusing them causes
every agent failure he has seen.[^ss26-tan]

**Latent space.** Taste, judgment, and reading what a human actually wants from a vague request.
That lives in the model, and you steer it with a markdown file.

**Deterministic space.** The arithmetic, the SQL query, the combinatorial constraint solve. That
lives in code and a database, called *by* the markdown files.

# His scaling illustration

Seating five people around a table is easy: do it in latent space. Generating custom schedules
for 6,000 people in an arena — which is what the conference the audience was sitting in
required — means your latent-space agent needs to write code and keep state in a SQL database.
His line: your experience at this conference had to be markdown files calling code in exactly
this way, and you could not do it without the code.

His diagnosis of why: the model fails where we fail, and the fix is to make the model compute the
way humans compute — offloading to a deterministic instrument when the task is deterministic.

# The adjacent argument

[Jensen Huang](/sources/jensen-huang.md)'s controllability argument is the same boundary seen from
the human side: the coarse control surfaces are prompts and RAG, and what is wanted is precise
intervention in a structured artifact — a plan file, a CAD layer — with regeneration around
it.[^ss26-huang] See
[/concepts/controllability-as-the-agent-frontier.md](/concepts/controllability-as-the-agent-frontier.md).

# See also

- [/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
