---
type: Concept
title: "How federated tech policy actually works"
description: "There is no technology department, so tech policy is convened across agencies and escalates only when they cannot agree."
tags: [policy, government, process]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

# The surprising fact

Kratsios's answer to what would surprise this audience: technology-policy decisions are
extraordinarily federated. There is not one or two people in the White House who decide
something. He calls the absence of a technology department a blessing of the US system — there is
a health agency and a defence department, but tech issues are spread across many agencies, each
with different equities: national security, commercial, and core research.[^ss26-kratsios]

So making good policy means the White House convenes all of them. His worked example is drones:
to allow commercial drone operations you need the FAA's rules to be right *and* the people who
oversee nuclear weapons to be satisfied that drones will not fly over nuclear sites.

# The structure

Four policy councils sort things out — national security, domestic (health, immigration),
economic (tax and related), and science and technology, each with a lead running processes on its
topics. Kratsios's own portfolio covers AI, quantum, civil nuclear energy, biotech and space,
with one or two people per area; his space team of about three coordinates NASA and defence
satellite equities.

Escalation: agencies work a problem at the bottom of the pyramid; if they agree, policy is done
and gets executed. If someone objects — his example is a defence official insisting drone rules
near military sites must be far more stringent — it kicks up a level, then higher, and ultimately
to the president. Part of the job is *limiting* what reaches him, so his limited time goes to
national priorities.

# A typical day

Three buckets: stakeholder meetings; the blocking and tackling of pushing agencies toward a
decision the president has directed; and public communication and listening.

# See also

- [/concepts/preemption-and-little-tech.md](/concepts/preemption-and-little-tech.md)
- [/concepts/regulating-a-moving-frontier.md](/concepts/regulating-a-moving-frontier.md)

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
