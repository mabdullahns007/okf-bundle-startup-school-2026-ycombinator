---
type: Concept
title: "Metadata prompting for heterogeneous data"
description: "Tell the model the quality of the data it is looking at, and low-quality data starts helping instead of hurting."
tags: [robotics, data, prompting, training]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

# The recipe

To train one generalist policy, Physical Intelligence used everything available: diverse robot
demonstrations including deliberately low-quality ones, policy rollout data from RL attempts,
videos of humans, and web data. Finn says the key unlock for absorbing data that heterogeneous
was not capacity alone but *prompting the model with all the context it needs to predict
actions*:[^ss26-finn]

- a high-level instruction of what to do,
- a **subtask** instruction for the next immediate thing,
- **metadata** indicating data quality, episode length and similar,
- optionally a generated **sub-goal image** of what things should look like a few seconds ahead.

At deployment a high-level policy predicts the next subtask and a world model generates the
sub-goal images.

# The ablation that makes the point

Finn calls this the most interesting experiment. Without metadata prompting, going from 80% to
100% of the data — the last tranche being low-quality — makes performance *decrease*, which is
unsurprising. With metadata prompting, the same addition makes performance *increase*. Being told
that data is low-quality lets the model extract value from it rather than being degraded by
it.[^ss26-finn]

The companion ablation: removing the most diverse subset of data sharply degrades held-out task
performance, while removing a random 20% barely does — so diversity, not volume, drives
generalisation.

# See also

- [/concepts/compositional-generalization.md](/concepts/compositional-generalization.md)
- [/concepts/robot-rl-with-human-interventions.md](/concepts/robot-rl-with-human-interventions.md)

[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
