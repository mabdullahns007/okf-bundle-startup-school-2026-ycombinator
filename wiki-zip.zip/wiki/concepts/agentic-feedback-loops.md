---
type: Concept
title: "Agentic feedback loops"
description: "Companies are large feedback loops with humans on the edges; agents can now operate and optimise those edges."
tags: [agents, operations, business-model, automation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# The model of a company

Wang's framing: most companies are large-scale feedback loops with humans operating each edge. They
get customers, figure out how to make those customers happier, happier customers spend more,
spending funds hiring more people who get more customers and make them happier. That, in some
sense, is the feedback loop of every startup or business — and within it are many micro feedback
loops.[^ss26-wang]

His claim about where the alpha is: developing agentic systems that can operate and optimise those
loops, spending a thousand or a million times more on tokens to drive an outcome in a continuous
loop.

# The condition

He is specific that this only works with the right eval or metric for the agents to optimise. Given
that, he reports internal cases at Meta where the right agentic loop let a swarm of agents
accomplish more than a team of a hundred engineers — "very very handily actually, very very
easily."

That condition is the same one [Dmitri Dolgov](/sources/dmitri-dolgov.md) puts at the centre of his
talk. See [/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md).

# The mechanics are mundane

Asked what this looks like concretely, Wang confirms: figure out the metric, then skills, markdown
files and cron jobs. His aside — it is always funny how mundane everything is once you really dig
into it. His advice on where *not* to look for this: ignore LinkedIn.

[Boris Cherny](/sources/boris-cherny.md)'s loops and routines are a working instance of exactly
this shape. See [/concepts/self-maintaining-codebases.md](/concepts/self-maintaining-codebases.md).

# See also

- [/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
