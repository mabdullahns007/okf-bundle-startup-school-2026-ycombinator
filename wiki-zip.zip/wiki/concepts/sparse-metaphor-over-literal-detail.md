---
type: Concept
title: "Sparse metaphor over literal detail"
description: "A detailed face looks like somebody else; a simple one lets everyone project themselves onto it."
tags: [design, metaphor, iconography, interfaces]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Susan Kare"
    last_modified: 2026-08-14
---

# The principle

Kare's design bias: a salient detail or two, and do not lard it with extra stuff. She grounds it in
two illustrations from Scott McCloud's *Understanding Comics* — a book about comics she says has
many good insights about user interface, published a decade after the Mac.[^ss26-kare]

The two ideas she takes from it: when a face has a lot of detail it looks like somebody *else*, and
when you make it really simple everyone can project themselves onto it; and more generally, the
less detail you have, the more universal something is.

Her example: a simple drawing of a pencil can stand for writing better than a chrome pen with a
reflection — which is very fancy, and a very particular kind of pen not everybody writes with. Her
comparison is street signs: there is no technical reason the silhouetted children at a school
crossing could not have plaid lunchboxes, shoelaces or be singing, but it would be distracting and
cost the instant recognition you are aiming for.

# The corollary from her own mistakes

Do not depict a *particular product design*. Her print icon showed ImageWriter paper with sprocket
holes for the pin feed, and she says it would have had a much longer lifespan if she had stopped
and made it simpler — as with the 3.5-inch floppy for save, which obviously did not age well. Better
to use a metaphor, with just enough detail.

She also notes the one abstract mark she felt slightly bad about — the Command key glyph — because
abstract things can be harder to remember than something whose metaphor reinforces the concept.
Years later she found the same symbol on Swedish signage marking places of interest, derived from a
castle whose four turrets read as that shape from above, and enjoyed learning it looked like
something after all.

# The transferable form

The claim is about *durability*: representations that name a category outlive representations that
depict an instance. That is as true of an abstraction in a codebase or a schema in a knowledge base
as it is of a 16x16 icon.

# See also

- [/concepts/constraints-enable-creativity.md](/concepts/constraints-enable-creativity.md)

[^ss26-kare]: Susan Kare, [Susan Kare: Designing Icons & Graphics For the Original Mac](/sources/susan-kare.md), Startup School 2026.
