---
type: Concept
title: "Scenes as the source of startups"
description: "Startups do not come out of nowhere; they crystallise out of a moment and a community, and that community is your first recruiting market."
tags: [hiring, founding, community, recruiting]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

# The claim

Hodak argues the best companies come from what might be characterised as **scenes**: a moment that
enables a new company to be born, with a bunch of things coming together to create a unique
nucleation. And once the moment has passed — because some company executed on it, or simply because
time moved — it is tough to get back.[^ss26-hodak]

# The recruiting consequence

The best hiring comes from within your own network — people you have worked with and know are good.
The extended version is to hire from the network that *produced* the startup: there is usually an
extended community the thing came out of, and that community should be the target of your initial
recruiting marketing, because those people already speak your language.

His crucial qualifier: there are never enough of them to fill an entire company, so you must hire
from the general public — which is what forces a defined process. See
[/concepts/distributed-hiring-funnel.md](/concepts/distributed-hiring-funnel.md).

# The oral-tradition point

Hodak adds that startup cultures are rarely rediscovered from first principles: usually they are
passed down, because a founding team worked at another company that worked at another company, and
inherited it — or, in cases of genuine market dislocation, a team appears from nowhere and often
gets its culture from its investors. See
[/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md)
for the dissent this creates with other speakers.

# The matching problem

[Sam Altman](/sources/sam-altman.md) describes the same phenomenon as the limiting factor on how
many good startups YC could fund five or ten years ago: talented people who could not find their
tribe — which is what made "move to the Bay Area" such durable advice.[^ss26-altman] See
[/concepts/loose-network-compounding.md](/concepts/loose-network-compounding.md).

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
