---
type: Concept
title: "Napkin math as a design method"
description: "Back-of-the-envelope calculation used not to estimate but to discover that a different architecture is required."
tags: [systems, estimation, hardware, design-method]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The method

Jeff Dean is known for it, and the two worked examples he gives are both cases where the
arithmetic did not refine a plan — it forced a new one. See
[/case-studies/tpu-napkin-math.md](/case-studies/tpu-napkin-math.md) for the speech-recognition
calculation that produced the TPU, and the earlier realisation that Google's search index would
fit in the aggregate RAM of its machines.[^ss26-dean]

# The prompt he gives founders

Identify the bottleneck in whatever you are thinking about, then ask whether a *different* way
of thinking about the solution gets you one or two orders of magnitude. His emphasis is on not
being anchored on how the problem is solved today: squint at it and ask how you would solve it
from first principles, and you can arrive at ideas other people are not considering.[^ss26-dean]

# The extreme version: question the assumption

His thought experiment about unreliable transistors is napkin math pointed at a sixty-year
industry premise. Chip fabrication has worked to make transistors that essentially never flip a
bit; at the macro scale, by contrast, we routinely build reliable distributed storage out of
unreliable disks with replication and Reed–Solomon coding. So: what would a system built from
transistors with twenty errors per day rather than one per million years look like? Very
different design methodologies — sending a signal along multiple redundant paths, for instance.
He is careful to say he is not proposing it, and that such experiments usually fail for good
reasons.[^ss26-dean]

He notes the resemblance to how brains work: neural signals are not especially reliable, and
important signals travel multiple pathways.

# The cost version

[Max Hodak](/sources/max-hodak.md) runs the same style of arithmetic on burn: a $20M Series A,
half of burn as headcount, plus rent, leaves roughly a $3M annual research budget — which at
$40,000 per wafer iteration goes far faster than founders expect. See
[/concepts/cost-attribution-in-physical-r-and-d.md](/concepts/cost-attribution-in-physical-r-and-d.md).

# See also

- [/concepts/energy-and-data-movement.md](/concepts/energy-and-data-movement.md)
- [/concepts/taste-as-the-scarce-skill.md](/concepts/taste-as-the-scarce-skill.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
