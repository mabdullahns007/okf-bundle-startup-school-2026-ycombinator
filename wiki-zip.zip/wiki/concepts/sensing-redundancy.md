---
type: Concept
title: "Sensing redundancy and complementary physics"
description: "You need redundancy anyway, so you may as well buy sensors whose physics fail differently."
tags: [physical-ai, sensors, reliability, hardware]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

# The argument

Waymo uses cameras, lidar and radar, each with its own encoder, fused into a single
representation Dolgov describes as far more precise than any single sensor. His
characterisation: cameras give high resolution and colour but are passive and degrade in
darkness and glare; lidar directly measures the 3D structure of the world; radar punches through
fog, rain and snow and measures velocity directly via Doppler. Lidar and radar being active
sensors, they see equally well in pitch darkness or into a blinding sunset.[^ss26-dolgov]

His shown cases: a Phoenix dust storm where a high-dynamic-range camera sees roughly what a
human would — not much — while lidar clearly shows a pedestrian at the roadside; pedestrians
about to cross a construction barrier at night; and dogs chasing a ball with children chasing
the dogs, in complete darkness with no headlights or lamps. His point in each is *early*
detection changing how the situation plays out.

# The redundancy argument proper

Without sensing redundancy a single leaf landing on a sensor can bring a robot to a full stop —
he shows a car that picked up a tree branch the wipers could not clear and returned safely to
the depot for cleaning. Redundancy does not *require* multiple modalities, but since you need
redundancy regardless, you may as well get complementary physics in the nominal case.

# On cost

Do not anchor to today's component prices. Waymo is on its sixth generation of the driver, and
each generation both added capability and drastically reduced hardware cost. Betting the company
on today's prices is betting on a number with a short shelf life — so design for that future and
be ready to upgrade.[^ss26-dolgov]

# See also

- [/concepts/performance-vs-effort-curves.md](/concepts/performance-vs-effort-curves.md)

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
