---
type: Concept
title: "Talent density compounds"
description: "Wang's stated core bet in rebuilding a frontier lab: the more talented people you have, the more of the most talented want to join."
tags: [talent, hiring, research-orgs, culture]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# The bet

Describing roughly a year rebuilding Meta's frontier lab — a "zero-based build" after Llama 4 was
judged off the needed trajectory — Wang says the first and most important thing that struck him was
that **talent density was incredibly important**, and that it is something which compounds
naturally: the more talented people you have, the more of the most talented people want to join
you.[^ss26-wang]

The claimed result: a new frontier model within nine months of that decision, and an update two
months later.

# The operating-model claim underneath it

His second observation is that frontier AI work is *research*, not product engineering — exploring
what these models can do and how far they can be pushed — which requires a different mindset and
operating model from the one that existed for internet companies and internet products. More
experimentation, more science, more scaling.

His metaphor for the lab is an organism: something that must grow along several simultaneous
exponentials — capability, compute, adoption and usage.

# Why this belongs next to the startup advice

The same mechanism appears at startup scale in
[/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md) and
[/concepts/scenes-as-the-source-of-startups.md](/concepts/scenes-as-the-source-of-startups.md):
concentrations of ambitious people are self-reinforcing, which is an argument both for joining one
and for deliberately assembling one.

# See also

- [/concepts/hire-for-slope-not-intercept.md](/concepts/hire-for-slope-not-intercept.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
