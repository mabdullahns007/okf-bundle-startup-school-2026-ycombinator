---
type: Concept
title: "Storytelling as the core CEO skill"
description: "You must sell the company to yourself first, because working this hard without believing your own story is very hard."
tags: [leadership, storytelling, recruiting, fundraising]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The claim

Asked which skills are most valuable now, Junestrand's first answer — at least for a CEO — is
storytelling, and he says he had completely underappreciated how important a skill it would
be.[^ss26-junestrand]

His decomposition of who you must sell to, in order:

1. **Yourself.** Because working this hard without believing your own story is really hard.
2. **Employees.** They are now competing with the frontier labs for talent, so they must tell the
   story of why working at Legora beats working at a lab.
3. **Investors.**
4. **Customers.**

His honesty about teaching it is worth noting: he does not know how to learn it and does not know
how he learned it, beyond a lot of exposure and a personal liking for stories — video games
included.

# Where he first learned it mattered

His first fundraise was 80 investor meetings in a week and a half, with both European and American
investors, and the takeaway he states is exactly this: you need to become a really good storyteller
to drive interest and get people on your team. He also notes a cultural asymmetry — in the US he
found more thought given to what could go right rather than what could go wrong.

# The unglamorous companion skill

In the same answer he volunteers that he used to be a bad teammate — yelling at volleyball
teammates who missed a serve — and had to change in high school, because that invites neither
followership nor a good vibe. Storytelling that nobody wants to follow is not worth much.

# See also

- [/concepts/love-the-hustle.md](/concepts/love-the-hustle.md)
- [/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
