---
type: Concept
title: "Self-maintaining codebases"
description: "Recurring one-sentence routines that delete dead code, ship finished experiments, manage tests and unify duplicated abstractions."
tags: [agents, maintenance, automation, engineering]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The practice

Anthropic runs roughly 20–30 recurring routines a day across its CLI, iOS, Android and desktop
codebases. Cherny's examples, each about one sentence of prompt:[^ss26-cherny]

- **Clean up dead code** — find it via static and dynamic analysis and open a pull request. He
  notes they did not prompt for the analysis approach; the model worked it out.
- **Ship experiments that should go out** — an experiment already at 100% rollout gets removed
  from the codebase and shipped.
- **Write tests** for areas needing coverage, and **delete tests** that were added by older
  models or people and no longer earn their place.
- **"Abstraction police"** — find near-duplicate abstractions that drifted apart across a large
  codebase and unify them.

His framing of the payoff: this is the work of dozens or hundreds of engineers, and automating
it means engineers do the part they actually want to do — new product, talking to users.

# The mechanism

A *loop* is a cron job running locally; a *routine* is the same thing running in the cloud so
the laptop can close. Both are repetitive tasks that do not share context between runs but may
share memory. See [/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md).

[Jensen Huang](/sources/jensen-huang.md) describes this as coarse-grained recursive
self-improvement that already exists: each run updates the markdown files and the long-term
memory, so the agent gets a little smarter.[^ss26-huang]

# See also

- [/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md)
- [/concepts/controllability-as-the-agent-frontier.md](/concepts/controllability-as-the-agent-frontier.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
