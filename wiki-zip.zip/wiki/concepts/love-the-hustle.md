---
type: Concept
title: "Love the hustle"
description: "Almost nothing that mattered happened at the big moments — it happened in a windowless room and a 2am Slack channel."
tags: [founder-psychology, motivation, culture]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The closing argument

Junestrand deliberately declines to offer the big lessons, noting he shares the stage with people
who have built at a scale he has not approached, and that three years in is smaller than
that.[^ss26-junestrand]

What he offers instead: most of what actually mattered at Legora so far did not revolve around
signing a big client, closing a round, or opening an office in Manhattan. It happened in a
windowless room without much oxygen, on a call on the way to the airport, in a Slack channel at 2am
trying to fix a bug before a Monday presentation. Nobody puts that in a pitch deck, and that is
what makes the company.

His conclusion: do not wait around for those big moments — you have to love the hustle.

# The biographical frame

He notes he was born in the Swedish archipelago in a class of ten, thought he had a big plan for
his life and was going to McKinsey after school, and instead made GPT-3.5 landing in their laps
into their thing. His closing line is the YC-native one: you can just do things — and he offers
himself and Legora as proof.

# Why this is more than sentiment

It is the counterweight to every other page in this wiki that reports a headline number. The
$1M→$100M curve, the 50-person team, the eleven-day rewrite — all of them are the visible output of
long stretches that looked like nothing. Compare
[/concepts/optimize-for-the-worst-day-and-the-best-day.md](/concepts/optimize-for-the-worst-day-and-the-best-day.md)
and [/concepts/fun-is-velocity.md](/concepts/fun-is-velocity.md), which make the same point about
what actually sustains output.

# See also

- [/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
