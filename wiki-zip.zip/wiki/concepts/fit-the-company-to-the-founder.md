---
type: Concept
title: "Fit the company to the founder"
description: "You are building an F1 car you have to drive; adapt the car to you, and let the next driver reshape it."
tags: [leadership, org-design, founder-mode]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The argument

Asked what happens to his unconventional management and organisational structure when he leaves,
Huang's answer is that they will simply have to reshape the company for the next CEO. His reason
for calling that wisdom rather than negligence: the founders are the F1 drivers, the world is
genuinely competitive, and you have to win and achieve the mission — so whatever it takes to fit
the car and the organisation to you is what you do. The next CEO, whatever their personality, can
figure it out.[^ss26-huang]

He notes this is continuous rather than a one-time design: he is constantly tweaking the company
and reshaping business processes so he can be more effective for it. And he adds the freeing
corollary — you do not have to change your personality or behaviour when you become CEO; it is
possible to continue being yourself.

# The related trait: curiosity as management technique

Huang describes his state of mind as starting with curiosity. He looks for the shortest path to an
answer, but often the answers from people near him are unsatisfying or they are busy with
something else, so his first instinct is to go discover the answer himself. His second is: if this
domain could matter to the company, how much can I learn so I can be of service and share it. His
own framing: not a management technique but a personality technique, and a CEO in service of the
company.[^ss26-huang]

His justification for being in the weeds is specifically about fast-moving technology: without a
tactile sense of what is happening it feels like it is moving too fast to understand, but if you
grasp the first principles it makes sense over time. His analogy is surfing — chaos to him, legible
to a surfer who can read waves and wind and has good timing, none of which you can have without
actually doing it.

# See also

- [/concepts/judgment-cannot-be-delegated.md](/concepts/judgment-cannot-be-delegated.md)
- [/concepts/how-hard-can-it-be.md](/concepts/how-hard-can-it-be.md)

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
