---
type: Concept
title: "Is the lean startup playbook still right?"
description: "The niches are more aggressively tilled and capital and capability constraints have changed — so you may have to decorrelate harder."
tags: [lean-startup, strategy, product-market-fit, launch-strategy]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

# The question

The classic doctrine: start narrow, buy some ads, find a crevice, aggressively expand out from it.
Collison observes that this assumed constrained capital and no cheap way to spin up an organisation
with many capabilities at once. He suggests you can imagine that path becoming much more
competitive and aggressively tilled, since the internet is a far bigger place than twenty years
ago — while a *divergent* starting point nobody else is trying to occupy is now more
reachable.[^ss26-collison]

His evidence: many of the most successful companies of the last decade are strongly anti-lean —
the labs themselves, Anduril, and others down the list. His formulation: twenty years ago lean was
almost the only thing you *could* do; now you can start much more aggressive and ambitious things
up front.

He is careful about the epistemics: this is the general problem with startup advice, that it is so
generalised, and in startups the exception proves the rule.

# The strongest counter-example in the playlist

[Blake Scholl](/sources/blake-scholl.md) simply could not use the lean approach: you cannot reach
product-market fit on a supersonic jet by building one and seeing if anyone likes it. Boom instead
searched the space of conceivably buildable aircraft *analytically* using its own simulation tools
to choose which one to build.[^ss26-scholl] See
[/concepts/engineering-tools-as-product.md](/concepts/engineering-tools-as-product.md).

His hindsight qualification matters though, and cuts the other way: he says Boom bit off too
challenging a first prototype, and should have planned something simpler giving multiple shots on
goal — because iterating at the *product* level surfaces wrong requirements, not just wrong
engineering.

# What has not changed

Collison's own account of why Stripe survived is pure lean-startup doctrine: it was grounded in a
concrete, viscerally felt customer problem rather than a hallucinated one. And
[Sam Altman](/sources/sam-altman.md) notes that a very ambitious idea often has a clear top-level
vision and genuinely unclear first steps — which is fine, but you must still take some steps and
get new data points.[^ss26-altman]

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
