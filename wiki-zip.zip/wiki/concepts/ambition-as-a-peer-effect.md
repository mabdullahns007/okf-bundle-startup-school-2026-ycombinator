---
type: Concept
title: "Ambition as a peer effect"
description: "Junestrand's answer to how you become more ambitious: assemble a peer group of ambitious people, then spread it through the whole company."
tags: [ambition, culture, career, peer-effects]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

# The claim

Asked how someone becomes more ambitious — and whether it is even possible — Junestrand says yes,
and that the best way is a peer group of very ambitious people.[^ss26-junestrand]

His evidence is autobiographical. He was lazy in his final school years and his first two years of
college, playing a lot of Dota, having an easy time academically, and not knowing how big the
world was outside his sphere. Then he made a new friend group of very ambitious people and it
clicked: he went from zero internships to eight jobs in one year.

He names this as one of the best parts of YC — you arrive and realise everyone is really ambitious,
so you become more ambitious together — and cites a YC essay making the same point.

# The organisational version

What makes his account more than a personal anecdote is that he claims Legora now works this way
internally, and that this is deliberate. He says he does not feel like the boss so much as a peer
in the team running the company, and gives as his example the CFO challenging the marketing team
to be more ambitious — something a CFO would not typically care about. His point about where the
compounding lives: it is not just at the top, it is everywhere, and you get to watch your creation
spiral into becoming more and more ambitious.

He adds a second input: having big idols and big companies ahead of you. Legora's were Spotify and
Klarna, the biggest Stockholm tech successes — and he describes passing Klarna's market cap as a
weird moment, while noting they feel they have done zero-to-one and one-to-ten, with ten-to-a-hundred
still ahead.

# The convergent view

[Sam Altman](/sources/sam-altman.md) frames the same mechanism as the co-founder-matching problem:
a lot of talented people simply could not find their tribe, which is why moving to the Bay Area
was such good advice.[^ss26-altman] See
[/concepts/loose-network-compounding.md](/concepts/loose-network-compounding.md).

# See also

- [/concepts/culture-against-local-norms.md](/concepts/culture-against-local-norms.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
