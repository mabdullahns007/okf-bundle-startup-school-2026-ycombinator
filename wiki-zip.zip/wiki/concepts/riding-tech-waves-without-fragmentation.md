---
type: Concept
title: "Riding tech waves without fragmenting the stack"
description: "Demand of every new technology not just capability but simplification — and know what happens if the tiger team succeeds."
tags: [architecture, engineering-management, complexity, research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

# The pattern

Waymo has rebuilt the driver around each major AI wave: ConvNets around 2013 for perception;
transformers around 2017 for perception *and* for behaviour prediction, decision-making and
planning; and now VLMs and frontier world models.[^ss26-dolgov]

His aside on why transformers transferred to driving: the task is not that dissimilar from
language modelling, because driving is social — a conversation with other dynamic actors
conducted in the body language of a vehicle, operating in sequences where local continuity
matters but so does global context.

# What is actually hard

Dolgov is direct that applied research in isolation, or a tiger team prototyping new technology,
is not the difficult part — many teams excel at it. The harder muscle is carrying bleeding-edge
research into production in a safety-critical environment without regressions, and without
breaking stride on scaling. The hardest is doing that *repeatedly* through successive waves.

# Two pieces of advice

1. **Plan the success case.** Before starting a new effort, be clear what the path into the
   whole product is if it succeeds. A very difficult technical project that succeeds into a dead
   end is wasteful and completely deflating.
2. **Set the launch bar to demand both.** Do not only ask what capability the new technology
   buys; ask whether it simplified the stack, and whether it produced unification or
   fragmentation. Adding capability is not the hardest part; adding capability while reducing
   complexity is.[^ss26-dolgov]

He credits this muscle for producing the Waymo foundation model itself. See
[/concepts/fast-path-slow-path-architecture.md](/concepts/fast-path-slow-path-architecture.md).

# See also

- [/concepts/configuration-sprawl.md](/concepts/configuration-sprawl.md) — the same disease in
  an open-source project.

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
