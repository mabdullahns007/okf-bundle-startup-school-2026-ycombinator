---
type: Concept
title: "Willingness to learn over domain expertise"
description: "The playlist's title claim: three non-lawyers built a leading legal AI company, and NVIDIA learned graphics from textbooks."
tags: [learning, domain-expertise, hiring, founder-psychology]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The claim in its strongest form

Junestrand's answer to whether domain expertise still matters: you do not need it, you need a
*willingness to learn about the market* — which Legora bought early by exposing themselves to
lawyers as much as possible. He offers a Swedish VC that passed on their pre-seed for having no
lawyers on the team, and says he met one of the partners at an airport recently and they were
bitter, treating Legora as their lesson.[^ss26-junestrand]

His important qualifier: it depends on the market. Quantum computing or fusion would be different.
Legal was easy enough to pick up as they went.

# The same claim at 34 years' scale

[Jensen Huang](/sources/jensen-huang.md) supplies the extreme version: NVIDIA's founding algorithm
was wrong, nobody there knew the right way either, and he bought three textbooks and handed them
to the engineers — after which they reinvented computer graphics and led it for 25 years. His
generalisation: technology changes constantly, so as long as you can confront reality and learn,
the technology itself does not matter.[^ss26-huang] See
[/case-studies/sega-dreamcast-contract.md](/case-studies/sega-dreamcast-contract.md).

# And the inverse advice

[Blake Scholl](/sources/blake-scholl.md) names "work on something you know something about" as
the worst advice he received, since his resume-driven first company left him with no product
vision. Knowledge is changeable; what you love is not. He also tells young engineers not to become
deep experts, because the moment you do, what you are steeped in is the past.[^ss26-scholl] See
[/concepts/work-on-what-you-love-not-what-you-know.md](/concepts/work-on-what-you-love-not-what-you-know.md).

# The dissent worth recording

[Max Hodak](/sources/max-hodak.md) is the counterweight: he argues startup culture and judgment are
an *oral tradition*, rarely rediscovered from first principles, which is why he recommends working
at a high-performing company adjacent to your target first.[^ss26-hodak] The synthesis on offer is
that domain *knowledge* is cheap to acquire while *judgment* is not.

# See also

- [/concepts/how-hard-can-it-be.md](/concepts/how-hard-can-it-be.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
