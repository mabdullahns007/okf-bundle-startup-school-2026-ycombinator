---
type: Concept
title: "AI and intellectual property"
description: "Kratsios's clear line is on model outputs; beyond that he prefers letting licensing markets mature."
tags: [policy, intellectual-property, creators]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

# The stated position

Kratsios names AI's interaction with intellectual property, and with name, image and likeness, as
the area where he thinks many Americans want Congress to step up — noting that creators are
worried, and that everyone has a craft of some kind, so having protections matters.[^ss26-kratsios]

The one place he says he has been clear is **model outputs**: if you build a model that outputs
Mickey Mouse, that is not acceptable and the company should not be allowing it. He thinks making
that explicit in statute is important.

Beyond outputs he is deliberately non-prescriptive. He notes industry can self-coordinate on
revenue-sharing models, and that many creators would happily license their own IP — musicians and
others. The interviewer cited a Yelp/ChatGPT deal surfacing reviews as an early instance.
Kratsios's summary: it is early, the market will mature, and this is probably a category where
you do not want to legislate too fast — while insisting it does matter, because Americans care.

# The two poles he is positioned between

He acknowledges the spectrum explicitly: traditional media filing lawsuits against AI companies
on one side, and maximalists arguing you should not even be able to opt out of being crawled for
training on the other.

# See also

- [/concepts/own-your-skill-files.md](/concepts/own-your-skill-files.md) — the same ownership
  question posed about a knowledge worker's extracted judgment rather than a creator's work.

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
