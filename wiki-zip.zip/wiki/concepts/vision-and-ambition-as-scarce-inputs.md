---
type: Concept
title: "Vision and ambition as the newly scarce inputs"
description: "If intelligence and agency become abundant, what is scarce is a clear view of how you want the world to differ."
tags: [founder-psychology, ambition, strategy]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The argument

Wang's framing: for the history of humanity, the bottleneck on progress was groups of smart
people getting together toward a shared goal — the story of the United States, of nearly every
American company, of every YC company. If intelligence and agency become abundant, that changes,
and the scarce resource becomes vision and ambition: do you have a clear view of what you want
the world to look like, one specific way you want to put your finger on the scale for the next
five to ten years, and the drive to go through all the crap to make it happen.[^ss26-wang]

His flip side is important: agents make execution maybe ten or a hundred times easier than a
decade ago — which means you can dream correspondingly bigger.

# The adjacent formulations

- [Jeff Dean](/sources/jeff-dean.md): taste — knowing which problem is worth the compute — is the
  scarce skill, and he does not expect models to be good at it soon. See
  [/concepts/taste-as-the-scarce-skill.md](/concepts/taste-as-the-scarce-skill.md).
- [Jensen Huang](/sources/jensen-huang.md): the scale of the task no longer matters, so you do not
  have to think about how much coding or how many engineers — you only have to think about what
  problem you have to solve.[^ss26-huang]

# The counterweight

Wang is explicit that systematic and rigorous thinking remain essential and that going all-in on
verbal facility over technical reasoning is a mistake, because the abstraction layer keeps moving
but systems thinking never goes out of style.

# See also

- [/concepts/rising-ambition-ceiling.md](/concepts/rising-ambition-ceiling.md)
- [/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
