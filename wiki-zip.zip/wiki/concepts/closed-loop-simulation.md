---
type: Concept
title: "Closed-loop simulation as a second AI"
description: "Counterfactual evaluation requires a generative world model as hard to build as the agent itself."
tags: [simulation, world-models, evaluation, physical-ai]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# Open loop vs closed loop

Open-loop training and evaluation passively observes input–output pairs; imitation learning works
this way, and evaluation amounts to asking "in this situation, what would you do?" and scoring
it. Closed loop takes an action, observes its effect on the world, updates the sensed view, takes
another action, and evaluates the sequence.[^ss26-dolgov]

Dolgov's claim is that the ability to take an action and evaluate the counterfactual is vital for
building and deploying safety-critical physical agents — and that a real simulator is how you do
it. Which means the simulator is not lightweight tooling beside your AI; it is a large AI model,
and building a good one is as hard as building the agent.

His striking observation: building an end-to-end model became fairly easy well before evaluating
one in closed loop did.

# What it must model

Physics, semantics, traffic, weather — at a fidelity sufficient not merely to look good but to
train and evaluate with confidence something going into a safety-critical deployment. Waymo built
*behavioural* world models for years, before the term was fashionable; the end-to-end era added
the need for *sensor* realism, so they now build sensing world models too. Because their policy
uses structured intermediate representations, the behavioural world model operates in that same
structured space, tightly coupled to a sensor world model producing realistic sensor
simulation.[^ss26-dolgov] The work leverages Google DeepMind's Genie 3.

# The payoff: scenarios that never happened

Purely synthetic rare scenarios, simulated closed-loop rather than merely generated as video: a
car stopped in a freeway lane, a plane landing on the freeway ahead, an elephant walking through
an intersection, snow on the Golden Gate Bridge, a dinosaur.

# See also

- [/concepts/agent-simulator-critic-flywheel.md](/concepts/agent-simulator-critic-flywheel.md)
- [/concepts/learned-surrogate-evaluators.md](/concepts/learned-surrogate-evaluators.md)

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
