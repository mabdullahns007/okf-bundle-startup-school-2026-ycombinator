---
type: Concept
title: "Show, don't tell — make it visual"
description: "An architect's answer to endless discussions around tables: do the drawing."
tags: [design, communication, decision-making, craft]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Susan Kare"
    last_modified: 2026-08-14
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

# The advice

One of the pieces of collected advice in Kare's closing section, from Daniel Nord — an architect,
born in Sweden, who worked in London for the mayor. He described how they used to sit around tables
having endless discussions about things, and his answer was to **make it visual**: do the drawing.
Kare's gloss is that he meant show, don't tell.[^ss26-kare]

# Why it belongs in a wiki about AI startups

Because [Peter Steinberger](/sources/peter-steinberger.md) independently reports having installed
this as a *rule* at work, enforced by agents. His account: if you come to him with a feature *idea*,
he gets mad — because it is now so easy to discuss the idea with an agent, build it, take
screenshots and let him play with it. If it is good they can iterate immediately; and most of the
time, people work out for themselves why it is not good and never bring it.[^ss26-steinberger]

This is one of the clearer instances in the collection of a 1980s design-practice norm becoming
cheap enough to be a default engineering policy. The advice did not change; the cost of complying
with it collapsed.

# The related practice from the same talk

Kare also says she likes to show either what a client asked for or what a programmer used as a
*placeholder*, because she has gotten many good ideas that way, and then refines them. The
placeholder is a drawing too.

# See also

- [/concepts/never-show-one-option.md](/concepts/never-show-one-option.md)
- [/concepts/how-to-commission-creative-work.md](/concepts/how-to-commission-creative-work.md)

[^ss26-kare]: Susan Kare, [Susan Kare: Designing Icons & Graphics For the Original Mac](/sources/susan-kare.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
