---
type: Concept
title: "The rising ambition ceiling"
description: "What took a whole YC batch in 2005 now takes minutes — which is an argument for attempting harder companies, not for despair."
tags: [ambition, strategy, founder-psychology]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# The reframe

Sam Altman's version: what each company built over a whole YC batch in 2005 could now be done in
minutes by a coding agent. You can either be sad that a prompt is a whole startup, or go start
the most ambitious company you can imagine — with experts in every field working together and
hard technological problems that were simply impossible. He expects a golden age of startups
doing things that would have been unthinkable for a startup a year ago, and would bet that
startups created today are more valuable and more impactful than those of the past.[^ss26-altman]

His caution on the counter-meme: the idea that you must join a frontier lab or join a permanent
underclass he calls dumb — if it were true the world would be a very bad place.

# The evidence being cited

- [Garry Tan](/sources/garry-tan.md): hard-tech was 5–10% of YC batches for years and is now
  toward 15–25%, which he attributes to agents and falling costs; plus extreme
  revenue-per-employee cases. See [/concepts/revenue-per-employee.md](/concepts/revenue-per-employee.md).
- [Jensen Huang](/sources/jensen-huang.md): a chip designer of his generation might design a
  thousand-transistor chip; now a trillion-transistor chip is unremarkable, because ambition
  scaled and the size of the task stopped mattering.[^ss26-huang]

# The discipline that has to come with it

Altman's own qualifier is the sharpest line in his talk: you can now do three months of work in
seventeen minutes, but you had better then go and do three months of work at whatever the new bar
is.[^ss26-altman]

# See also

- [/concepts/diffusion-is-the-bottleneck.md](/concepts/diffusion-is-the-bottleneck.md)
- [/concepts/vision-and-ambition-as-scarce-inputs.md](/concepts/vision-and-ambition-as-scarce-inputs.md)

[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
