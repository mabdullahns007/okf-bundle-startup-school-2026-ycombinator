---
type: Concept
title: "Reinforcement learning on real robots"
description: "Language-model RL assumes attempts are free. On hardware they are not — so avoid dead ends and amortise value estimation."
tags: [robotics, reinforcement-learning, data-efficiency, autonomy]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

# Why the language-model recipe does not port

PPO, GRPO and relatives have scaled to millions or tens of millions of attempts because an
attempt is just compute in a datacentre. Finn's translation to robotics: even one million
one-minute trajectories is roughly 700 robot-days — for a task *shorter* than making espresso.
Not strictly impossible, but the calculus differs, because you are consuming real hardware
attempting a real task in the real world.[^ss26-finn]

# Two sources of inefficiency, and their fixes

1. **Dead-end trajectories.** Fine when you are only spending compute; expensive on hardware.
   Her example: a robot builds cardboard boxes and accidentally grabs two boxes flush against
   each other; left alone it will keep trying to fold both, which teaches nothing. So a human
   teleoperates an intervention showing how to separate them — and intervenes again if the robot
   cannot recover autonomously. At minimum, terminate the episode early.
2. **Per-prompt rollouts.** These algorithms make many attempts at a single prompt (ten, fifty)
   to estimate which responses are good. Instead, amortise across prompts: train one
   general-purpose value function on robot experience that learns, for instance, that
   accidentally unfolding a shirt is negative progress — and which then estimates good and bad
   for an unrelated task such as retrieving an item from a fridge. It is essentially predicting
   time-to-success, and it sharply reduces the attempts needed.

# The full recipe and its results

Train a foundation model on diverse data → collect experience with human intervention where
needed → train a general value function → use it to improve the model. Measured on **throughput**
(coupling success rate and speed), the RL post-training stage roughly doubled throughput, and
espresso success exceeded 90%. A latte policy ran 13 hours continuously; the same algorithm
handled a real Dandelion Chocolate box workflow and folding unseen clothes in an unseen home.

Her caveats are notable and unprompted: only a few improvement iterations were run, the robot
still makes mistakes, and it is still slower than a person.

# See also

- [/concepts/multi-timescale-robot-memory.md](/concepts/multi-timescale-robot-memory.md)
- [/concepts/metadata-prompting-for-heterogeneous-data.md](/concepts/metadata-prompting-for-heterogeneous-data.md)

[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
