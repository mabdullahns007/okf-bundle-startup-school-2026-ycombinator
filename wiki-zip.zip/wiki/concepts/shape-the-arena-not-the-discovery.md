---
type: Concept
title: "Shape the arena, don't direct the discovery"
description: "The stated principle of US science policy after the public/private R&D funding share inverted."
tags: [policy, science-funding, research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The history

In 1945 FDR wrote to his science adviser, Vannevar Bush — the role Kratsios now holds — asking how
to organise American science after the war, when federal energy had gone into the Manhattan
Project and similar. Bush's reply, *Science, the Endless Frontier*, argued that government has an
important role funding science in the national interest, particularly early-stage basic research
the private sector is not incentivised to do. That report defined how the country did science for
about seventy years.[^ss26-kratsios]

# What changed

Around 1950 the federal government funded almost 70% of R&D and the private sector 30% or less.
That has fully inverted: private sector plus philanthropy now do roughly 70%. For pure basic
research — the kind associated with universities — there is now near-parity. And new actors exist
that did not before: startups, and focused research organisations sitting outside universities
doing their own research.

# The response

Kratsios says President Trump wrote him a letter in the same form as FDR's on his confirmation,
and the resulting roughly 150-page report, *Science and the New Golden Age*, is the year-long
answer. Its central thesis relevant to founders: AI will transform how scientific discovery is
done — materials science, pharmaceuticals, chemistry — and a government spending nearly **$200
billion a year** on R&D must be aware of that and prioritise accordingly.

The interviewer summarised the concrete commitments in the budget memo: **fast grants decided in
under a month**, **prizes built for 3:1 private leverage**, and **every major agency filing an
action plan within 90 days** — under the report's stated principle that government's job is to
shape the arena, not direct discovery.

# What he wants founders to build

See [/concepts/autonomous-cloud-labs.md](/concepts/autonomous-cloud-labs.md), and
[Jeff Dean](/sources/jeff-dean.md)'s software-side version in
[/concepts/automated-experimentation-loops.md](/concepts/automated-experimentation-loops.md).

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
