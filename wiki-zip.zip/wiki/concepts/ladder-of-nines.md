---
type: Concept
title: "The ladder of nines"
description: "Each additional nine of reliability costs about ten times more and requires doing something categorically different."
tags: [reliability, physical-ai, engineering, product]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

# The claim

Dolgov's first and most-quoted lesson: a working demo is at best 1% of the work, and reliability
lives on an exponential ladder. The first 90% or 99% is the easy part; every subsequent nine
takes roughly ten times more effort. So you need to know up front how many nines your product
actually needs — a demo might need one, an assist product a few, a fully autonomous agent
engaging with the public a whole stack.[^ss26-dolgov]

# The part people miss

You do not reach six nines by doing what got you two, only for longer. Each nine requires a
*fundamentally different approach*. His reliability example: proper engineering and bug fixes
buy the first couple of nines; the next few require fully redundant systems and tiered backup
architectures. The same holds for model performance.[^ss26-dolgov]

At scale the long tail becomes the entire problem statement — at millions of miles per week, an
event that happens once in a million miles is a daily occurrence.

# Why every hype cycle produces demos and few products

His mechanism: each breakthrough — deep learning, ConvNets, transformers, VLMs — makes demos
perhaps a hundred times easier while barely moving the tail. So each wave produces spectacular
demos and very few products, and the recurring mistake is *spending on the demo when you should
be saving for the nines.* His summary: count your nines before you count your demo views.

# The counterweight

He is explicit about not throwing cold water: the early days are genuinely magical and should be
leveraged. The discipline is being honest about which product you are building.

See [/case-studies/waymo-demo-to-product-timeline.md](/case-studies/waymo-demo-to-product-timeline.md)
for the numbers, and [/concepts/performance-vs-effort-curves.md](/concepts/performance-vs-effort-curves.md)
for the architectural consequence.

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
