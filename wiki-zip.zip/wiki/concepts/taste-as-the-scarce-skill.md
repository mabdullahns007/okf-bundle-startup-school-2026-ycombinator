---
type: Concept
title: "Taste as the scarce skill"
description: "When agents write everything, what is scarce is knowing which problem is worth their time — and taste is trainable."
tags: [taste, research-method, problem-selection, judgment]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# The claim

Asked what becomes scarce once code is free, Jeff Dean's answer is taste: having incredibly good
judgment about what you ask your agents to work on. His analogy is from research — a researcher
can have every tool and technique, and most of the battle is still which problem to spend time
on, because delightfully executing an investigation into a boring problem is worse than picking
well and succeeding. He does not expect models to be good at this soon, which is why people will
be steering large amounts of AI-assisted computation.[^ss26-dean]

# Three ways to train it

1. **Experience across many problems**, which teaches what might be barely possible by cobbling
   previous approaches together, and which open problems stand in the way.
2. **Keep a scored forecast.** Write down what you think will matter in the next twelve months,
   work on one, then come back and grade the rest against what the world actually built — giving
   yourself more samples for taste formation.
3. **Deliberate thought experiments** that refuse to take a widely shared assumption as given.
   See [/concepts/napkin-math.md](/concepts/napkin-math.md) for his unreliable-transistor
   example, and note his caveat that most such experiments fail for good reasons accumulated
   over fifty years — and are still worth revisiting.[^ss26-dean]

# Related framings

[Sam Altman](/sources/sam-altman.md) names taste and agency, plus an understanding of the
physics of business — what a real network effect or moat looks like versus a fake one — as what
still matters, while betting the balance tips against years of experience and toward tool
fluency.[^ss26-altman] [Alexandr Wang](/sources/alexandr-wang.md) generalises it to
[/concepts/vision-and-ambition-as-scarce-inputs.md](/concepts/vision-and-ambition-as-scarce-inputs.md).

# See also

- [/concepts/specification-as-the-new-source.md](/concepts/specification-as-the-new-source.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
