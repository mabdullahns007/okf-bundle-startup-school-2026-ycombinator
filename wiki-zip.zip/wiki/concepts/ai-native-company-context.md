---
type: Concept
title: "Making your company AI-native by centralising context"
description: "Put everything in one place not only to trace it but so you can hand all of it to agents."
tags: [ai-native, internal-software, operations, agents]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

# The design principle

Hodak's answer to what AI does not replace in research is that agents are a multiplier rather
than a replacement — and that you should therefore think about how to make your company AI-native
in a specific sense: gather all the context of everything happening in the company and make it
efficiently available to agents.[^ss26-hodak]

At Science that is Helix, where essentially everything goes. He gives two reasons and they are
distinct: it is powerful to have one database linking purchasing to quality to batch records to
manufacturing so things can be traced; *and* so that all of it can be given to agents.

# Where AI has actually paid off there

Three areas, in his account:[^ss26-hodak]

1. **Coding.** He says he has written a lot of code in his life and has barely looked at source
   in six months.
2. **Regulatory and quality systems.** Building a regulated product means identifying every
   standard that might apply — there are standards for how lithium-ion batteries connect to a
   PCB, for board insulation, even for whether a shipping label's corners curl in a vibration
   test — and maintaining a spreadsheet of evidence of compliance with all of them. Historically
   months of work; he says AI has transformed it. His notable framing: regulations are largely
   written in blood and mostly good ideas, and the real problem is that humans are bad at reading
   and interpreting them — which makes AI and regulation a better fit than people think.
3. **Context for agents**, as above.

# The individual-scale version

[Garry Tan](/sources/garry-tan.md)'s personal library is the same argument applied to one person
rather than one company. See
[/concepts/personal-context-as-a-compounding-asset.md](/concepts/personal-context-as-a-compounding-asset.md).

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
