---
type: Concept
title: "Regulating a moving frontier"
description: "Firm red lines do not survive contact with a fast-moving technology, and government finds them very hard to reset."
tags: [regulation, policy, thresholds]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

# The position

Asked how you write rules for something reinventing itself every six months, Kratsios's answer is
that you do not want to set very firm red lines, because they ultimately do not work.[^ss26-kratsios]

# Two examples he gives

1. **The EU AI Act.** He notes it went through years of process and was passed and finalised
   before ChatGPT existed — so language models and everything since must comply with a rule
   written before they were a thing. His point is about the hazard of drawing the line too firmly
   at the start.
2. **A hard compute threshold.** He cites the previous administration's specific compute cap
   above which disclosures to government were required, and argues such firm thresholds do not
   stand the test of time.

His governing principle: any action should be able to move along with the frontier — and once
government sets something, it is very hard to reset, so be very cautious about hard thresholds.

⚠️ **Factual note.** The auto-transcript renders Kratsios dating ChatGPT's release to November
2021. The actual release was November 2022. Either a misstatement or a transcription artifact; the
argument does not depend on it. See [transcription caveats](/sources/index.md#transcription-caveats).

# The executive-order asymmetry

He notes the mechanical reason so much AI policy arrives by executive order rather than statute:
an EO can simply be revoked when an administration changes, while a law cannot. His stated
preference is to find places to collaborate with Congress on genuinely pro-innovation rules — with
preemption as the priority. See [/concepts/preemption-and-little-tech.md](/concepts/preemption-and-little-tech.md).

# See also

- [/concepts/born-free-vs-born-in-captivity.md](/concepts/born-free-vs-born-in-captivity.md)

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
