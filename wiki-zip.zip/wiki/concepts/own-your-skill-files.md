---
type: Concept
title: "Own your skill files"
description: "The same 40 files are two opposite futures depending on one variable: whose repo they live in."
tags: [ownership, labor, skills, politics]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

# The parable

Tan's argument that a skill file is not a document but a piece of your cognition — how you do the
thing, extracted from your head, written down, executable. So every skill you teach an agent is
you externalised, and the same file is two opposite futures depending on who controls it.[^ss26-tan]

His worked example: a support engineer teaches her agents 40 skills over two years — how to triage
a P0 at 2am, how to de-escalate a customer about to churn, how to write a postmortem that
actually prevents the next incident. Two years of judgment sitting on a disk.

- **Version one:** the files live in her repo. She changes jobs and they go with her; day one at
  the new company she operates with years of compounded judgment on tap. Every year compounds.
  And if she wants to start a company doing this, it is her expertise and she can.
- **Version two:** the files live in the company's repo under the company's IT policy. She leaves
  with nothing; the company keeps running her judgment without her, 40 files executing forever
  with her name not even in the commit history. In his words: she did not have a career, she had
  an extraction.

# The historical analogy

Craftsmen owned their tools, and that is what made them free. The factory broke that — the loom
belonged to the mill. Knowledge workers assumed they were safe because their tools lived in their
heads where nobody could confiscate them. Skill files end that: for the first time your cognition
can be extracted, stored, versioned and owned, and the only question is by whom.

His doctrine, stated to be repeatable: skill files are yours. Own your skills, because if you do
not, your job becomes a skill file. Keep your brain and your skills in a repo you control from
day one, before any platform or acquirer has an opinion about it.

# The Spinoza frame

Tan ties it to the thousand guilders Spinoza was offered to stop building, and to Heidelberg's
1673 professorship with freedom to philosophise "provided he not disturb the established
religion" — an offer he reads as terms of service, declined.

# The adjacent claim

[Peter Steinberger](/sources/peter-steinberger.md) makes the individual version: anything you
build can be forked or cloned, but your name cannot.[^ss26-steinberger] See
[/concepts/personal-brand-as-the-uncloneable-asset.md](/concepts/personal-brand-as-the-uncloneable-asset.md).

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
