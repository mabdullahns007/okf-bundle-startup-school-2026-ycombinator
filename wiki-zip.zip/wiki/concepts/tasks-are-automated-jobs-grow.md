---
type: Concept
title: "AI automates tasks; jobs grow"
description: "Huang's argument that the job-destruction narrative is backwards, because a job is a purpose composed of many tasks."
tags: [economics, employment, automation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# The argument

Huang concedes the effect is uneven and that cognitive tasks will be automated — his example being
a role that consists of receiving a question by phone and answering it from a database, which he
grants will be automated away. But his central claim is that **AI eliminates tasks, not jobs**,
because a person's job has a *purpose* composed of many tasks, some automatable and many
not.[^ss26-huang]

# The figures he cites

Presented as his own reading of the evidence, not verified here:

- Coding has been automated as a task, and software-engineering jobs appear to be growing — he
  gives roughly **10% year over year**.
- Reading radiology scans has been automated, and radiology jobs have increased by some **20%**
  in recent years, "even though AI's taken over the whole field."
- Paralegals were predicted to be eliminated by legal AI and he says they are growing rapidly.

# The mechanism he proposes

Backlog. The backlog of patients is enormous, so hospitals can now admit far more — which needs
more nurses and more radiologists. Law firms can push far more cases through, which needs more
people. And in software the backlog of ideas, ambition and aspiration is so high that automating
programming lets you hire *more* engineers to do more things and be more ambitious. His summary:
a classic case of productivity increasing growth, and growth driving employment — which he says is
why there is more employment today than when he left school.

# The corroborating observation

[Blake Scholl](/sources/blake-scholl.md) reports exactly this from inside one company: Boom needs
*more* software engineers post-AI than pre-AI, because the cost of software fell, hardware
engineers can now code, and someone must ensure the architectures are coherent.[^ss26-scholl]
[Patrick Collison](/sources/patrick-collison.md) adds that the labs themselves still pay an
enormous premium for cognitive ability.[^ss26-collison]

# See also

- [/concepts/rising-ambition-ceiling.md](/concepts/rising-ambition-ceiling.md)

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
