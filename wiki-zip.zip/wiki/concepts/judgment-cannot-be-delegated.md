---
type: Concept
title: "Judgment cannot be delegated"
description: "Copying your neighbour drags you toward the class average, and the average is not good enough."
tags: [judgment, leadership, founder-psychology, decision-making]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The argument

Hodak calls this one of the harder things to deal with as a founder: as CEO you must always make
decisions that make sense *to you*, no matter how much momentum or inertia the alternatives seem to
have.[^ss26-hodak]

His analogy: in school, if you cheat by looking at the person next to you, all else equal your
grade is dragged toward the class average. That is not good enough in startups, because successful
companies are the exceptions — you have to do things far out on the tail. So your judgment has to
be *differentiatedly good*.

The uncomfortable corollary he states directly: you may not know yet whether your judgment is good.
One way or another you will have to find out, and that means making decisions that make sense to
you even when you are totally alone in that conclusion.

# The specific moment he describes

Not the everyday case, which he notes is rarely everyone-versus-you. It is the moment four or five
years in, with hundreds of millions of dollars on the line and one high-stakes decision only you
can make. Early on there are many things that are easily advised or easily figured out; at that
point you look for advice and *there is nobody to ask*. He calls it a very eerie feeling, and says
you must by then have a really good sense of the limits and boundaries of your judgment, and be
able to commit regardless.

# How judgment gets trained

His answer is apprenticeship, and it is why he recommends working somewhere excellent first. What
he valued most at Neuralink was working with someone with empirically excellent judgment: you could
get into trouble together, bring a genuine two-option decision with stakes attached, and get a
call that turned out to be right. He describes that feedback — made with stakes, before you know the
answer — as fitting your filters, and an essential part of an entrepreneur's education that many
people underrate. Hearing the stories without being the one deciding does not substitute.

# The related posture

[Jensen Huang](/sources/jensen-huang.md)'s version is organisational: build the car you can drive,
and do not adopt someone else's structure. See
[/concepts/fit-the-company-to-the-founder.md](/concepts/fit-the-company-to-the-founder.md).

# See also

- [/concepts/action-produces-information.md](/concepts/action-produces-information.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
