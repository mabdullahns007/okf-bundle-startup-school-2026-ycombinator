---
type: Concept
title: "Iteration velocity as the master variable"
description: "A competitor learning weekly beats one learning monthly regardless of other merits — so prefer the shorter loop even at real cost."
tags: [iteration-velocity, strategy, infrastructure, engineering]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The claim

Max Hodak's stated theme: rate of iteration separates success from failure, and a fast loop
overcomes many other disadvantages. His illustration of the severity — if you learn one thing a
week and a competitor learns one a month, they will never matter.[^ss26-hodak]

The decision rule he draws: when comparing two approaches, if one compounds in much less time,
strongly prefer it *even when the other has significant redeeming characteristics*, because the
compounding effect is so dramatic. He immediately qualifies it: there are no blanket rules in
startups, and each new fact pattern is its own thing.

# Where speed actually comes from

His central and less obvious claim is that speed is determined by *infrastructure* — purchasing,
recruiting, spending, budgeting, safety and quality processes, which together are the operating
system of the company. His observation about Science's reputation for moving quickly: it is
mostly not that they are smarter. See
[/concepts/procurement-and-budgeting-as-infrastructure.md](/concepts/procurement-and-budgeting-as-infrastructure.md)
and [/concepts/internal-software-as-competitive-advantage.md](/concepts/internal-software-as-competitive-advantage.md).

And his diagnosis of deep-tech failure: it is uncommon for these companies to fail because the
technology did not work. They fail because hundreds of people and hundreds of thousands of
square feet became unwieldy without systems to manage it, and strategy could no longer connect
to execution.

# Convergent versions

- [Blake Scholl](/sources/blake-scholl.md): reduce the cost of iteration in both bits and atoms
  — see [/concepts/engineering-tools-as-product.md](/concepts/engineering-tools-as-product.md)
  and [/concepts/vertical-integration-for-iteration-speed.md](/concepts/vertical-integration-for-iteration-speed.md).
  His hindsight lesson is to iterate at the *product* level, because that surfaces wrong
  requirements and not just wrong engineering.[^ss26-scholl]
- [Max Junestrand](/sources/max-junestrand.md): a smaller company's ability to be fast against
  incumbents is the superpower, and you lean into a superpower.[^ss26-junestrand]
- [Peter Steinberger](/sources/peter-steinberger.md): fun is the input to velocity — the weeks
  he enjoyed building, the product visibly improved.[^ss26-steinberger] See
  [/concepts/fun-is-velocity.md](/concepts/fun-is-velocity.md).

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
