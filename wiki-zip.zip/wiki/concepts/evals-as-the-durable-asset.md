---
type: Concept
title: "Evals and metrics as the strategic moat"
description: "Architectures are known and models leak; a quantified definition of good enough, and the audited evidence behind it, does not replicate."
tags: [evals, metrics, moats, trust, safety]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# The claim

Dolgov's final and strongest lesson: your model is table stakes, and eval and metrics are your
most important strategic moat. Build your eval before you build the technology and before you
build the product — *"if you can't quantitatively define what good enough means, you're not
really building a product, you're just iterating on your demo."*[^ss26-dolgov]

His reasoning: the best architectures are fairly well known and new ideas proliferate quickly.
Data matters enormously, but without good metrics you are flying blind — not leveraging the best
data and unable to evaluate the return on changing it.

# For physical agents, model-level eval is not enough

Evaluation and validation must extend to every component from the physical layer to the
behavioural layer, on-board and off-board, plus the operational processes around them — what
Waymo calls its safety and readiness framework, refined over years and described as one of its
most important assets.

# Trust as the compounding asset

His business argument: in the physical world trust is everything, and it is earned in the field
by relentlessly proving the system works, not by clever architecture or flashy demos — which is
why Waymo publishes its safety data and research openly. Models can leak and algorithms can be
replicated, but hundreds of millions of real autonomous miles backed by evidence-grade
evaluation and publicly audited proof cannot.

# The startup-scale version

[Max Junestrand](/sources/max-junestrand.md) makes the same argument for an application company:
the core muscle worth building is the ability to evaluate use cases, because that is what makes
model routing possible. See [/concepts/eval-driven-model-routing.md](/concepts/eval-driven-model-routing.md).
[Alexandr Wang](/sources/alexandr-wang.md) notes an agent swarm outperforms a large team only
when you have the right eval for it to optimise.[^ss26-wang]

# The caveat from the other side

[Boris Cherny](/sources/boris-cherny.md) warns that evals are less permanent than they look: an
eval might live one to three model generations before being saturated and discarded.[^ss26-cherny]
The reconciliation is that the *capability* to build and rebuild evals is the moat, not any
particular eval file.

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
