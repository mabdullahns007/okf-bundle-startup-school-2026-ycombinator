---
type: Concept
title: "What the Stripe data showed in 2026"
description: "New businesses roughly doubling year over year, the median business doing better, and time to revenue falling."
tags: [data, economics, business-formation, adoption]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
---

# The figures

Collison's report from aggregate Stripe data at the time of the talk (late July 2026):[^ss26-collison]

- **New businesses starting on Stripe: up around 2x year over year** — a bit under, but around
  double — which he says is the largest relative jump they have seen. For comparison, the
  COVID-era jump from 2019 to 2020 inflected the growth rate to roughly 50%.
- **The median business is doing better** than a year earlier — his pre-emptive answer to the
  objection that this is just more lightweight vibe-coded slop.
- **The probability of any given business reaching a revenue threshold** — $1M, $5M, $10M — is
  improving across the board.
- **Time to revenue for newly incorporated Atlas companies is declining.**
- Contextually: about **25% of all Delaware corporations** are started through Stripe Atlas.

His summary, hedged: by all the objective metrics they can look at, it seems a better time than
ever to start a business — though things can change and he does not know what the world looks like
in five years.

# The mechanism he proposes

Buyers are spring-loaded. Businesses everywhere are more willing to adapt and try new things, with
a real terror of being left behind with antiquated ways of operating. In normal times a CIO does
not want to talk to you because your thing is unvalidated and you may not exist in two years. Now
people know the risk of the *status quo* is extremely high, so even though the new path carries
risk, the old one looks dangerous too. His conclusion: there has never been a better time for
startups to sell and get adopted at meaningful scale right out of the gate.

The YC-side corroboration offered in the same conversation: enterprises now sign contracts with
companies within their first ninety days, which is new.

He also notes a consumer version — complicated views on AI and data centres coexisting with real
intrigue and an openness to experimenting with new products.

# Why it matters for the wiki's other claims

This is the only *aggregate measured* evidence in the playlist for the claims made rhetorically
elsewhere. See [/concepts/diffusion-is-the-bottleneck.md](/concepts/diffusion-is-the-bottleneck.md),
[/concepts/rising-ambition-ceiling.md](/concepts/rising-ambition-ceiling.md) and
[/concepts/concentration-of-power.md](/concepts/concentration-of-power.md), where Collison's data
is the basis for his dissent from the centralisation thesis.

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
