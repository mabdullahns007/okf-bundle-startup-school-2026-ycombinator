---
type: Concept
title: "Configuration sprawl"
description: "Around 9,500 configuration options, because every feature shipped with one so nobody's setup would break."
tags: [software-design, maintenance, open-source, technical-debt]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# The mechanism

Steinberger's account of how it happened is not carelessness but consideration. Features are the
fun part and a new one is a prompt away; the real cost arrives afterwards. And because he did not
want to break anyone's existing setup, **every feature shipped with a configuration
option.**[^ss26-steinberger]

At the peak he counted around **9,500 configuration options.** Counting all the permutations, you
can write every test you want and it is impossible to cover them and not break things from time to
time.

His line, which is the general lesson: it is infinitely harder to evolve software that has users.

# The contributing factor

He also names a governance cause. OpenCloud attracted an excellent community of maintainers who
each added their own feature — and he felt he had no standing to tell people what to do when they
work for free, while his own attention was scattered across press, lawyers and another job. His
hindsight on saying no: he did not say no enough. He now writes a `vision.md` explaining what a
project is and where it is going, while conceding it is not perfect science and that he needs to
adhere to it better.

His sharpest point about merging a popular feature: what you rarely think about is that you are
accepting a pile of code the contributor probably does not fully understand, that you do not fully
understand, and that you now own.

# The opposite discipline

[Boris Cherny](/sources/boris-cherny.md) runs the inverse policy on a product with far more users:
delete aggressively, unship tools, and treat every retained line as something the model pays for on
every call.[^ss26-cherny] See
[/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md). The
contrast is one of the more instructive pairings in this collection — and the difference is who
bears the cost of a breaking change.

[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
