---
type: Concept
title: "Be mildly helpful to a lot of people"
description: "Altman's highest-confidence advice on networks — and the eight-year gap between the favour and the company."
tags: [networks, career, relationships]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# The advice

Asked for his highest-confidence advice to people figuring out who their people are, Altman's
answer is to find a way to be mildly helpful to a lot of people. It is fun to do, you see a lot of
interesting things, and it is gratifying — and he is explicit that you should do it for its own
sake rather than instrumentally.[^ss26-altman]

# The story

As a very early Stripe investor at around 22, before Stripe had investors who could really help,
he was asked to drive to Palo Alto and have dinner with a prospective first hire to convince him
to drop out of school and join. That was Greg Brockman. About eight years later they started
OpenAI together. Altman notes he could spend the rest of the session telling stories of that
shape — entirely unpredicted and eventually important.

He generalises it to the Bay Area's redeeming feature: for all the culture's negatives, the loose
network, the spirit of mutual help and the long-term outlook have been an awesome thing. And he
argues the sooner you put yourself in a flow where you meet the people who will be your eventual
co-founders — for this startup or the next — the better, because it takes a long time to compound.

# The founder-side version

[Max Junestrand](/sources/max-junestrand.md) names the same asset from the other direction: it is
very powerful to be a person and a company that others want to see succeed and want to help — his
lesson from cold-emailing lawyers and asking for help.[^ss26-junestrand]
[Blake Scholl](/sources/blake-scholl.md) reports that experienced, accomplished people are rarely
unwilling to take the call, which is why Boom's rule is that you must find the person who has done
it before and hear their advice.[^ss26-scholl]

# See also

- [/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md)

[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
