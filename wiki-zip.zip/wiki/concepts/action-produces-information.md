---
type: Concept
title: "Action produces information"
description: "A thrown ball follows an information-minimising trajectory; injecting action into the world is what creates information."
tags: [decision-making, physics-analogy, judgment, unsticking]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The idea

Hodak says this is much deeper than it sounds, and he means it physically. In physics there is a
quantity called action. Throw a ball and its parabolic trajectory is totally determined the moment
it leaves your hand, unless wind or some other action is exerted on it — which makes it, in his
framing, an *information-minimising* trajectory: you can say "it was ballistic" and that completely
determines it. For anything else to happen, energy had to be spent. So whenever you exert action
into the universe you create information, in a fundamental sense.[^ss26-hodak]

His operational conclusion: when you get stuck, you have to start injecting action — producing
entropy.

# The counterintuitive corollary

He offers a specific and uncomfortable instance: he has seen a company stuck in a deep local
minimum where someone great in many ways was simply the wrong fit for what the company needed at
that time, and *removing them* — despite individual strength — unblocked the company and let it
enter a new phase.

# The companion observation

He also says it is very difficult to actually get stuck, and that the action space is always larger
than it appears. It is easy to anticipate all kinds of problems you never actually run into; then
you go and do the thing, hit a real limitation, and find there are always a hundred ideas about how
to make it better.

# The related fundraising advice

This is why his advice on runway is to price out the experiment rather than the company: figure out
what it costs to actually run the experiment to your next value inflection point, then raise twice
that. Some ideas are worth $50M or $0 but not $5M, because $5M buys an ambiguous outcome. He is
also candid that you will not get a guarantee you are not on a bridge to nowhere — you have to get
in there and figure it out halfway through.

# See also

- [/concepts/judgment-cannot-be-delegated.md](/concepts/judgment-cannot-be-delegated.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
