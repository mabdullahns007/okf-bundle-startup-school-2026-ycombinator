---
type: Concept
title: "Vertical integration for iteration speed"
description: "Owning the machine shop and the test stand converts supplier lead times into hours — and can create a fundable product."
tags: [hardware, manufacturing, iteration-velocity, financing]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# Why they integrated

Scholl says one of the most important things they discovered is that it is extremely difficult to
iterate with outside suppliers, particularly in aerospace — about which he says he has no kind
words. So Boom built its own machine shop, going from a digitally designed engine part to a
prototype part in about 24 hours. His characterisation of their Denver R&D shop: *a room that
does not exist at GE, Rolls-Royce, Boeing or any other large aerospace company*, where engineers
work hand in hand with manufacturing technicians.[^ss26-scholl]

They also vertically integrated test assets, building their own engine stand about half an hour
from engineering, so they can test when they want rather than reserving a slot in someone else's
test cell.

At scale this becomes a "superfactory" for engines and ultimately airframes — a building that was
an empty lease in January and had its first machines going in six months later.

# The financing consequence

The unexpected payoff: because propulsion was in-house, the same supersonic engine could be sold
separately on the ground as a natural-gas power turbine ("Superpower"). That ships without the
rest of the airplane, and generates test data, learnings, reliability evidence *and* the capital
needed to go big — his stated solution to the otherwise very hard problem of financing
development when you cannot predict how much capital or time it will take.[^ss26-scholl]

# The manufacturing-strategy version

His answer on competing with China follows the same logic: do not try to repatriate what left,
because you do not beat China at its own game. The tool-and-die industry migrated and is now
hard to staff in the US — so Boom is working to eliminate tooling entirely, with an all-digital
path from design to turbine blade in 24 hours. Win by inventing the next wave of manufacturing,
because what America is still best at is invention.

# See also

- [/concepts/engineering-tools-as-product.md](/concepts/engineering-tools-as-product.md)
- [/concepts/iteration-velocity-as-the-master-variable.md](/concepts/iteration-velocity-as-the-master-variable.md)

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
