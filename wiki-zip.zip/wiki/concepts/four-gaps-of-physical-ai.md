---
type: Concept
title: "The four gaps between digital and physical AI"
description: "Cost of error, latency, data and validation each differ in kind, not degree, once an agent acts on atoms."
tags: [physical-ai, robotics, reliability, safety]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

# The four gaps

Dmitri Dolgov's opening frame for why physical AI is a different problem:[^ss26-dolgov]

1. **Cost of error.** A language model's mistake costs a retry. In the physical world the cost
   can be measured in human lives; there is no undo button.
2. **Latency.** A VLM or assistant may take seconds or minutes. A car at freeway speed covers
   roughly 100 feet per second, so milliseconds matter — and all inference must run on a
   computer that fits in the trunk.
3. **Data.** Digital AI had the internet: an immense pre-labelled cache of human knowledge and
   thought. There is no digitised internet of the physical world.
4. **Validation.** In digital AI you can ship something good enough at effectively unlimited
   scale and let users find the edge cases. In physical AI you need high safety and high
   confidence *before* the first deployed mile — while the real-world experience remains
   irreplaceable, which is the bind that forces crisply defined operating conditions and a
   rigorous deployment framework.

# The corollary

[Chelsea Finn](/sources/chelsea-finn.md) arrives at the same conclusion by a different route:
every profitable ML deployment so far has had a human making the decision from the model's
recommendation, so mistakes were tolerable. Physical AI must be far more reliable because it is
far more useful when fully autonomous. See
[/concepts/decision-support-vs-direct-action.md](/concepts/decision-support-vs-direct-action.md).

Dolgov notes driving is simply the first domain where AI has crossed all four gaps at scale
with the public interacting with the product — and that these gaps will appear in some form for
any non-trivial physical agent.

# See also

- [/concepts/ladder-of-nines.md](/concepts/ladder-of-nines.md)
- [/concepts/closed-loop-simulation.md](/concepts/closed-loop-simulation.md)

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
