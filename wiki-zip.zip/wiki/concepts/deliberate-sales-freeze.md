---
type: Concept
title: "The deliberate sales freeze"
description: "With $35M in the bank and ten people, Legora stopped selling for six months — because with lawyers you get one chance."
tags: [go-to-market, product, enterprise-sales, timing]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The decision

Three weeks after a $9.51M Benchmark round came a Redpoint pre-emptive Series A. Junestrand
describes the resulting problem plainly: about $35M in the bank, ten people on the team, and a
month in which they made more money from interest on the cash than from customers — which he flags
as a bad sign, because you have become a bank.[^ss26-junestrand]

At their first board meeting, with both investors present, they made what he calls a very hard
decision: **freeze the sales motion for six months.**

# The reasoning

With lawyers you only really get one chance to get it right. If you show up and the product does
not work, or system latency is too high, or the system goes down under traffic, you are toast. See
[/concepts/customer-discovery-by-paying-for-access.md](/concepts/customer-discovery-by-paying-for-access.md)
for where that understanding came from.

# The result

His claim is that the $1M → $100M curve starts at the *end* of that freeze — the freeze is what
turned a small startup looking for product-market fit into an established product and business. The
work done during it is described in
[/concepts/product-manifesto.md](/concepts/product-manifesto.md). Figures in
[/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md).

# Why this is worth recording

It is a direct counter-example to default startup advice — sell continuously, iterate in market —
and the conditions under which it applies are legible: a market where the cost of a single failed
first impression exceeds the value of early revenue, and enough capital to survive the pause.
Compare [/concepts/private-beta-with-real-users.md](/concepts/private-beta-with-real-users.md),
where Stripe reached the same conclusion for the same reason in a different regulated domain.

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
