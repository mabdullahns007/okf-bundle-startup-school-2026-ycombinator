---
type: Concept
title: "Accelerating algorithm domains, not building chips"
description: "NVIDIA's durable bet: what you accelerate is a class of algorithms, and the chip is downstream of that."
tags: [hardware, strategy, first-principles, platform]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The bet

Jensen Huang separates NVIDIA's wrong founding *technology* from its right founding *idea*. The
idea: general-purpose CPUs are useful, but augmenting them with accelerators makes otherwise
intractable problems solvable. 3D graphics was merely the first chosen domain; molecular
dynamics, fluid dynamics, image processing, inverse physics, particle physics and eventually
deep learning followed.[^ss26-huang]

His crucial early realisation, in his own framing: it is not about building a great chip, it is
about accelerating an *algorithm domain*.

# What makes a great company, in his view

Not the technology and not even the market, though he grants that the right technology for the
right market at the right time makes life much easier. What makes a great company is a unique
high-level perspective about the future of something important that you deeply believe in — and
ideally one that is hard to pursue. In NVIDIA's case: accelerated computing would matter, and
the substance was the algorithm, not the chip.[^ss26-huang]

# How the lens paid off at AlexNet

Because he was always asking "what is the algorithm," AlexNet registered not as a better image
classifier but as the discovery of a universal function approximator — something that can learn
any function, most interesting functions being imprecise ones. That reading immediately raised
the questions of what it does to the computing stack, to software, and to which industries —
which is what set off computer vision, robotics and self-driving work fifteen years
earlier.[^ss26-huang]

# See also

- [/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md)
- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md)
- [/case-studies/sega-dreamcast-contract.md](/case-studies/sega-dreamcast-contract.md)

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
