---
type: Concept
title: "Each AI wave is roughly ten times the last"
description: "Self-driving to chatbots to coding agents, each about an order of magnitude bigger — with more form factors to come."
tags: [strategy, market-sizing, technology-waves]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The claim

Wang's rough sizing, from having lived through them at Scale: self-driving cars were the first
wave and genuinely cool, but paled beside large language models and chatbots, which were perhaps
ten times bigger; coding agents came a few years later and are perhaps ten times bigger again. His
conclusion is that we are on a steep curve and will keep seeing new modalities and form factors,
each dramatically bigger than the last.[^ss26-wang]

The strategic implication he draws: the best AI products have not been developed yet, so the right
move is to unleash the ecosystem, explore, and not ration intelligence by price.

# The related structural claim

[Jensen Huang](/sources/jensen-huang.md) reads waves the same way but from the algorithm side, and
supplies a sizing for the physical one: NVIDIA's robotics and autonomous-vehicle business is
already *almost $10 billion*, likely becomes one of the largest industries in the world, will take
longer than two or three years and less than ten, and is his candidate for the next $100 billion
business.[^ss26-huang]

# The caution

Wang himself argues that debating exactly when the next wave arrives — two years or five, will we
hit a wall — is close to a waste of time, because the trend is what matters. See
[/concepts/diffusion-is-the-bottleneck.md](/concepts/diffusion-is-the-bottleneck.md).

# See also

- [/concepts/find-the-steepest-longest-exponential.md](/concepts/find-the-steepest-longest-exponential.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
