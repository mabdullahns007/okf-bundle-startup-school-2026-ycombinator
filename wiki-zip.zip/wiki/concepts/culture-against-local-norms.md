---
type: Concept
title: "Building a culture against local norms"
description: "Jantelagen says you are not more important than anyone else — good for ideas, hard for building the fastest-growing enterprise company."
tags: [culture, values, international, org-design]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The specific obstacle

Junestrand names *Jantelagen*, the law of Jante — a Scandinavian norm holding that you should not
think you are somebody, or that your ideas are better than anyone else's — and says it is very
foreign to his American audience.[^ss26-junestrand]

His treatment of it is genuinely two-sided. Part of that humility is good: it supports a culture
where the best ideas win and where people earlier in their careers feel empowered to speak up. But
it is very hard to build one of the fastest-growing enterprise companies in the world if you think
you are not somebody, or do not think you are better than anybody else.

Their answer was to mix US, European and Asian culture into what he calls a cocktail, to make a
genuinely global company.

# The instruments

- **Three values arranged as an acronym:** lean in, fight for excellence, grow together — LFG. He
  notes the implicit profanity itself signals to leaders arriving from more established backgrounds
  what kind of company this is.
- **Winner-take-most framing.** A press article summarised their stance as: there is only winning,
  everything else is losing, and the company must run as though there is no place for number two.
  His image is professional swimmers looking down their own lane while the competition looks
  sideways.
- **A shared idiom.** A Swedish expression about waking with the taste of blood from excitement,
  rendered literally in an English-language article, produced jokes about vampires and flossing and
  then became internal shorthand for simply continuing to go at it.
- **One onboarding location.** Everyone globally onboards in Stockholm, which he credits for every
  Legora office worldwide having the same feel. His illustrating anecdote: a US firm had a
  document-drafting problem a competitor had promised and failed to solve; a US-based legal engineer
  flew to Stockholm, spent a week with engineers, solved it there, and delivered it back.

# The stated payoff

Building a strong culture is, in his framing, the best guarantee of attracting and keeping the best
people — and how you sustain intensity in a country where the norm is a mid-afternoon coffee break
and leaving at five.

# What he says about losing

Notably, the mechanism he describes is symmetric: big wins are really celebrated and losses are
mourned together, followed immediately by a plan to flip it — so people are in solution mode rather
than blame mode.

# See also

- [/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md)
- [/concepts/hire-for-slope-not-intercept.md](/concepts/hire-for-slope-not-intercept.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
