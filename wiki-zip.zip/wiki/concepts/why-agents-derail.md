---
type: Concept
title: "Why agents derail on long horizons"
description: "Performance degrades as a task leaves the distribution the model has practised; skills keep it on lit paths and search recovers from bad branches."
tags: [agents, reliability, orchestration, distribution-shift]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# The diagnosis

Jeff Dean's explanation for agents that work for ten tool interactions and then stop working:
the model is attempting something it has little experience doing. As with any ML model, as soon
as you leave the distribution of what it knows, performance starts to degrade — and the further
out, the faster.[^ss26-dean]

# Two remedies

1. **Keep it in distribution.** Give the model skills and hints that steer it toward the
   well-lit paths it does know. See [/concepts/skills-as-encoded-method.md](/concepts/skills-as-encoded-method.md).
2. **Search instead of committing.** Run multiple agents on different approaches with another
   model evaluating which look promising, discarding the ones that went off the rails. Dean
   calls this a very useful general technique: inference-time compute spent searching the space
   of possible solutions, which buys much higher reliability on long-running
   flows.[^ss26-dean]

# The token-cost caveat

[Peter Steinberger](/sources/peter-steinberger.md) points out the other half: perpetually
running proactive agents are not blocked by capability but by tokens, and by the difficulty of
designing something that does not burn empty ones. His concrete failure: a static heartbeat
firing an hour into a large session, after the KV cache has cleared, resends hundreds of
thousands of tokens for very little useful work.[^ss26-steinberger]

[Boris Cherny](/sources/boris-cherny.md) reports the counter-trend — runs that continue for days
or weeks without scaffolding — which suggests derailment is model-generation-dependent rather
than fundamental.[^ss26-cherny]

# See also

- [/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
