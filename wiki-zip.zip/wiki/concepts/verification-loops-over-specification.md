---
type: Concept
title: "Verification loops beat specification"
description: "Give the model a task slightly harder than you think it can do, plus a way to check its own work — then stop describing how."
tags: [agents, prompting, verification, orchestration]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

# The claim

Cherny names over-specification as the most common failure he sees, and specifically as a
failure mode of experienced engineers who try to make the model do the task exactly the way
they would have. His prescription: describe the task, the guardrails and the exit criteria,
go a little higher-level than feels comfortable, and let it run.[^ss26-cherny]

Verification is the part he says people get wrong most: *"give it a way to verify the output of
its work so it doesn't get stuck, and it will just go."* In his Electron-to-Swift run the
verification loop was literally in the prompt — run the old app in a VM, screenshot it, compare
pixel by pixel with the new one, don't stop until done. See
[/case-studies/electron-to-swift-two-week-run.md](/case-studies/electron-to-swift-two-week-run.md).
In the Bun rewrite the verifier was an existing large test suite. See
[/case-studies/bun-zig-to-rust-rewrite.md](/case-studies/bun-zig-to-rust-rewrite.md).

# Not the same as vague prompting

[Jeff Dean](/sources/jeff-dean.md) argues the opposite-sounding point — that crisp
specification became *more* important, not less — and the two reconcile cleanly: specify
*what* and *how you will know it worked*, not *how to do it*. His illustration is that
translating software between languages works so well because the existing implementation plus
its tests is a perfect spec.[^ss26-dean] See
[/concepts/specification-as-the-new-source.md](/concepts/specification-as-the-new-source.md).

[Peter Steinberger](/sources/peter-steinberger.md) reports the same at the review end: with
orchestration, computer use and browser use, an agent fleet becomes the QA
environment.[^ss26-steinberger]

# See also

- [/concepts/why-agents-derail.md](/concepts/why-agents-derail.md)
- [/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
