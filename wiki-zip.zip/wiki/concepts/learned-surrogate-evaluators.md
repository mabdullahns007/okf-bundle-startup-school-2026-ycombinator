---
type: Concept
title: "Learned surrogate evaluators"
description: "Train a neural approximation of an expensive simulator and the experimental loop changes character entirely."
tags: [science, evaluation, simulation, ml-for-science]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

# The example

Jeff Dean's case: in quantum chemistry you generate a molecule configuration and want its
properties, which requires a computationally intensive density-functional-theory simulation —
roughly a night of computation for one answer. Colleagues took the input configurations and
outputs of many such runs and trained a neural approximation of the simulator. The result was
about **300,000 times faster** and nearly as accurate.[^ss26-dean]

# Why that changes the science, not just the cost

With ten million candidates to screen, the difference is between a six-month endeavour scraping
together compute and something you run while you go to lunch. Dean's general claim is that many
domains have room for much faster validation models — possibly learned ones giving an
approximation to the true answer — and that this changes how experimental loops can be conceived
and how fast you can go around them.[^ss26-dean]

His caveat when discussing self-improving systems: yes, formally verifiable or well-evaluated
domains are ripe, but in many cases *the evaluator itself must first be made much faster.*

# The adjacent case

[Dmitri Dolgov](/sources/dmitri-dolgov.md)'s generative simulator is the same move in a
safety-critical setting — build the evaluator as a serious AI model in its own right. See
[/concepts/closed-loop-simulation.md](/concepts/closed-loop-simulation.md).

# See also

- [/concepts/automated-experimentation-loops.md](/concepts/automated-experimentation-loops.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
