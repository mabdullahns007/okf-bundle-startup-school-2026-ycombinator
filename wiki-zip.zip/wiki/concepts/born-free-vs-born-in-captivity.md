---
type: Concept
title: "Born free vs born in captivity technologies"
description: "Some technologies have no rules on the books and must be protected; others cannot be commercialised without approval and need barriers removed."
tags: [regulation, policy, strategy]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# The distinction

Kratsios's framework for founders worried about compliance costs, and for how his own office
prioritises.[^ss26-kratsios]

**Born free.** No regulations on the books — the internet when it started. People can build
anything and thrive, so the policy job is *preservation*: be very thoughtful before introducing
new regulation into that domain.

**Born in captivity.** You can build the thing but cannot legally commercialise it without
government approval. His example: you could build an excellent drone in your backyard and
excellent software connecting a vendor to a customer, and still not legally close the transaction
and fly, without an FAA waiver. For these, the job is relentlessly figuring out how to remove the
barriers.

# His favourite case

Supersonic flight, which he calls the most obvious in-your-face example of technological
stagnation — the Concorde flew years ago and we fly slower now, which he calls an absolute
tragedy. The specific regulatory fix he identifies is a **noise limit instead of a speed limit**
over the United States. He mentions having heard from Boom's founder earlier in the day; see
[/sources/blake-scholl.md](/sources/blake-scholl.md) and
[/case-studies/xb1-mach-cutoff.md](/case-studies/xb1-mach-cutoff.md), where exactly that change
happened.

His stated first instinct on joining the administration was this framing generally: look across
all existing rules and ask how to make it easier for innovators to build — commercial drone
operations, autonomous vehicles on the road, drone delivery.

# See also

- [/concepts/regulating-a-moving-frontier.md](/concepts/regulating-a-moving-frontier.md)
- [/concepts/regulatory-strategy-for-startups.md](/concepts/regulatory-strategy-for-startups.md)

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
