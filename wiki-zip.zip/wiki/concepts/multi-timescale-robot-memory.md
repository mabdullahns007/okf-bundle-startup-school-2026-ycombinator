---
type: Concept
title: "Multi-timescale robot memory"
description: "Video memory for seconds, text summaries for minutes and hours — because naive video context is prohibitively expensive."
tags: [robotics, memory, context, efficiency]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

# Why most robot foundation models have no memory

Finn notes it may be surprising, but most state-of-the-art robot foundation models operate purely
on current sensor observations. That works for short motor skills and repetitive tasks — the
long-autonomy videos in the first half of her talk had no context at all — but not for
multi-step tasks, where memory is critical for tracking which steps are done.[^ss26-finn]

# The cost that blocks the naive approach

Ten seconds of video at 50 Hz (a common control frequency) across four robot cameras at roughly
256 tokens per image is about half a million tokens — in real time. Subsampling to 1 fps still
means 10,000 tokens, and that is still only ten seconds of memory.[^ss26-finn]

# The solution shape

Memory at multiple timescales: a short-term video memory of about ten seconds, computed far more
efficiently than naive context stuffing; and for minutes to hours, *text* — summaries of what
happened, fed back as a much more compressed representation.

The payoff is a 10–15 minute fully autonomous non-repetitive task: wipe the counter with a
sponge, dry it with a paper towel, throw the towel away, put the mustard in the fridge, put
dishes in the cabinet, wash the dirty dishes in the sink.

# The parallel

This is structurally the same as [Garry Tan](/sources/garry-tan.md)'s librarian problem — a
context window is small relative to a life, so something must decide what is loaded and at what
fidelity. See [/concepts/library-and-librarian.md](/concepts/library-and-librarian.md).

[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
