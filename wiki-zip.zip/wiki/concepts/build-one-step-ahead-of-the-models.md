---
type: Concept
title: "Build for the world today and one step ahead"
description: "Legora bet the models would improve rather than fine-tuning — partly from conviction, partly from having no money."
tags: [strategy, model-dependency, product, timing]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The bet

Asked what gave him confidence to build a legal product on a model that was good but not good
enough, Junestrand describes the tribal knowledge of 2022–23: you had to fine-tune. He cites a
large financial-data company spending heavily on its own legal model. Legora's view was the
opposite — partly because they did not have enough money, and partly because they genuinely
believed the models would keep improving — so what you should focus on is *how to deliver the value
the models generate to your market*.[^ss26-junestrand]

His honest account of the first sale: essentially "we are like ChatGPT but compliant in Europe,"
which he calls not a very strong pitch, and which the labs would obviously figure out later. It was
good enough at the time.

# The formulation

Do not build for the world far out; build for the world *today* and maybe one step ahead. He frames
it as a ladder: maximise the current opportunity and build genuinely good customer relationships,
so that when everyone's bet on exponential capability improvement pays off, your platform keeps
delivering more value on those relationships. His estimate: they have built about 1% of the
software they will build over the company's history, and the product will look very different in a
few years.

# The screening question from the other side

[Jeff Dean](/sources/jeff-dean.md) gives the complementary test for whether the ground under you is
about to shift — 0–1% model success is a good sign, 20% is not — and asks explicitly whether the
capability arrives in six months, twelve, or three years.[^ss26-dean] See
[/concepts/the-one-percent-rule.md](/concepts/the-one-percent-rule.md).

# The dependency this creates

Junestrand also names the flip side: compute and model contracts become a real operational
dependency once a meaningful share of the world's lawyers rely on your uptime. See
[/concepts/dependency-business-model-risk.md](/concepts/dependency-business-model-risk.md) and
[/concepts/eval-driven-model-routing.md](/concepts/eval-driven-model-routing.md).

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
