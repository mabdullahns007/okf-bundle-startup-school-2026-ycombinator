---
type: Concept
title: "Agent orchestration as a new axis of test-time compute"
description: "Beyond parameters, data and generated tokens, how you compose fan-out, verification and re-fan-out is itself a scaling axis."
tags: [agents, orchestration, scaling-laws, test-time-compute]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The argument

Historically model capability scaled with neural-net size, training data and training FLOPs;
then test-time compute — how many tokens are generated — was added. Cherny argues *dynamic
workflows* are a further axis: a way to ramp test-time compute up enormously on one hard
task.[^ss26-cherny]

# The shape

His background is functional programming and the design reflects it: an "algebra for agents"
with primitives for running agents in sequence and in parallel, inside a sandboxed runtime, so
a model can orchestrate other agents and spend tokens efficiently. A run might fan out for a
first pass, use a second stage of agents to verify or summarise that work, then fan out
again.[^ss26-cherny] He estimates thousands to tens of thousands of agents in his longest run.

He distinguishes this from *loops* and *routines*: a dynamic workflow is one task decomposed
into chunks; a loop or routine is one repetitive task run over and over on a schedule — locally
or in the cloud — sharing memory but not context. See
[/concepts/self-maintaining-codebases.md](/concepts/self-maintaining-codebases.md).

# Corroboration

[Alexandr Wang](/sources/alexandr-wang.md) reports internal cases where a swarm of agents with
the right eval accomplished more than a team of a hundred engineers, and frames the future
abstraction layer as orchestrating a million and then a trillion agents.[^ss26-wang]
[Jeff Dean](/sources/jeff-dean.md) describes the same mechanism as inference-time search over
plausible solutions, with a model judging which branches look promising.[^ss26-dean]

# See also

- [/concepts/agentic-feedback-loops.md](/concepts/agentic-feedback-loops.md)
- [/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
