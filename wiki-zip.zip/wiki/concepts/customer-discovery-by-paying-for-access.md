---
type: Concept
title: "Customer discovery by paying for access"
description: "Legora cold-emailed lawyers offering to pay their hourly rate for lunch. Many accepted; many waived the fee."
tags: [customer-discovery, go-to-market, sales]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The tactic

Knowing nothing about law, Legora's founders cold-emailed lawyers whose addresses they could find
on firm websites and messaged them on LinkedIn, asking for a lunch where they could learn about
their practice areas — and offered to pay their hourly fee for the time.[^ss26-junestrand]

Junestrand's report of what happened: many took them up on the offer, many did not make them pay
for the hour, and many even paid for lunch.

# Why it works

The offer removes the objection. A senior professional's reason to decline an unknown founder is
that their time is expensive; pricing that explicitly converts the ask from a favour into a
transaction — at which point the reciprocity norm frequently takes over and the fee is waived.

His stated general lesson from these early years is adjacent and broader: the power of simply
reaching out and asking for help, and how powerful it is to be a person and a company that others
want to see succeed and want to help. See
[/concepts/loose-network-compounding.md](/concepts/loose-network-compounding.md).

# What it bought them

Enough understanding to approach one of the largest Nordic firms — whose managing partner had said
on television two years earlier that AI was more artificial than intelligent — and eventually to
move into that firm's offices. It also produced the domain insight that shaped the product: in law
you are not paid when things go right, you are punished when things go wrong. That is what later
justified [/concepts/deliberate-sales-freeze.md](/concepts/deliberate-sales-freeze.md).

# See also

- [/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
