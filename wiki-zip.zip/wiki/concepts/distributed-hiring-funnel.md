---
type: Concept
title: "The distributed hiring funnel"
description: "Company-wide voting at the top, a shared bar at the phone screen, AI-resistant homework, and a 25% interview-to-offer floor."
tags: [hiring, process, internal-software, operations]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# Why distribute the top of funnel

Hodak's reasoning: if you are doing anything cool, by a couple of years in the top of funnel is
overwhelming, and placing any small group or single person in the way makes them a bottleneck on
the whole organisation. He also wants to *average over judgment*, since different people are better
or worse at hiring and hold different views of what you are looking for at that stage.[^ss26-hodak]

The mechanism: applicants apply through internal software that captures structured information
(including applying to multiple roles in parallel); the system then picks seven or eight current
employees whose backgrounds resemble the applicant's and pings each for a vote on a scale from
*known good* through *strong yes / yes / no / strong no*. Turnaround is usually 24–48 hours.

He notes this specifically could not be done in the commercial applicant-tracking system they had
been using, which is part of why they built their own. See
[/concepts/internal-software-as-competitive-advantage.md](/concepts/internal-software-as-competitive-advantage.md).

# The four stages and the real conversion rates

1. **Company-wide voting.**
2. **Phone screen** — 17% of top-of-funnel applications reach it, drawn from a company-wide pool
   against a company-wide bar rather than a team-specific one. It tests three things: **judgment**
   (thrown into a complex, vaguely defined situation, will you make good decisions or create
   diplomatic incidents), **horsepower** (a basic hurdle for technical competence and demonstrated
   ability to learn), and **agency** (are you effective at causing the world to look like you wish
   it were — does your life look like your ambitions).
3. **Homework** — about half of phone screens. See
   [/concepts/hiring-for-evidence-of-exceptional-ability.md](/concepts/hiring-for-evidence-of-exceptional-ability.md)
   for the AI-resistance requirement.
4. **Full interview**, which must convert to an offer at 25% or better, or you waste too much of
   the team's time on candidates who do not convert.

Hodak calls this the *minimum* set of information needed for a full decision, and says he does not
think there is a smaller number of steps that would elicit it.

# The founder's role

In the beginning you can and should meet everybody, and that carries you quite far. Beyond that you
still want mechanisms to average over the team's judgment — and voting is usually a good one.

# See also

- [/case-studies/eigen-reviews-at-science.md](/case-studies/eigen-reviews-at-science.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
