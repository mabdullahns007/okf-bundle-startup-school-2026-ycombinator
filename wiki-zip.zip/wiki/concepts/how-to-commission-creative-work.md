---
type: Concept
title: "How to commission creative work"
description: "Jobs wanted a contest paying five firms $15,000 each. Rand's counter-offer: $100,000, one logo, and you will like it."
tags: [design, hiring, contracts, craft]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Susan Kare"
    last_modified: 2026-08-14
---

# The episode

At NeXT, Kare — then a creative director — wanted to hire Paul Rand for the logo, because he was her
hero. Jobs had not really heard of him and thought they should run a contest: hire five people or
firms, pay them $15,000 each, then pick the best and continue working with them. Kare notes
parenthetically that she would never think a contest is the best way to get good creative
work.[^ss26-kare]

She invited some people, and then invited Rand. His answer: *you will pay me $100,000, I will do one
logo, and you will like it.*

That is what happened. They did like it, they paid him, and she describes it as a great learning
experience for everybody to work with him.

# What the structure actually buys

The contest treats design as a lottery over outputs; Rand's terms treat it as a commission of
judgment. The price is not for the artifact but for the accountability — one option, no hedge, and
the designer carrying the risk of being right. Which is also why he could refuse to produce
alternatives while [/concepts/never-show-one-option.md](/concepts/never-show-one-option.md)
recommends the opposite for *internal* review: the two are answering different questions.

# The rest of Rand's method, as Kare reports it

- Focus on making things meaningful and memorable — have a good idea, and the form will follow.
- You do not need many fonts; you need to know how to use them well. She notes he reused the same
  fonts and colours, and that she still takes colours from his books.
- Try hard to do something *to the name* of the product — as he did putting NeXT in a cube.
- His counter-example was a since-replaced AT&T mark: you can spend a fortune associating a
  meaningless symbol with your company, but most people do not have unlimited money.
- His own test of legibility: he showed the UPS mark to his six-year-old daughter and asked what it
  was; she reportedly said "it's a present, Daddy," which he took as sufficient justification.

# See also

- [/concepts/sparse-metaphor-over-literal-detail.md](/concepts/sparse-metaphor-over-literal-detail.md)

[^ss26-kare]: Susan Kare, [Susan Kare: Designing Icons & Graphics For the Original Mac](/sources/susan-kare.md), Startup School 2026.
