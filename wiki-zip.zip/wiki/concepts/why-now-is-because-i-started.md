---
type: Concept
title: "Why now can be because I started now"
description: "Scholl's named false belief: that if an idea is good and nobody is working on it, something must be wrong with the idea."
tags: [strategy, timing, ideas, contrarianism]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
---

# The false belief

Scholl says one belief almost stopped him founding Boom: that every technology gets created at the
earliest moment in history it could be, so if your idea is any good and nobody else is working on
it, something is probably wrong with the idea — and maybe with you. Investors reinforce it by
asking "why now?"[^ss26-scholl]

His claim about the effect: it compounds into a lot of founders running at a relatively small base
of ideas that are only recently possible. That is why there is an explosion of AI companies now,
and why there was an explosion of photo-sharing apps a while ago.

# Why he thinks it is false

There are many unsolved problems and many great ideas hiding in plain sight that were solvable —
and could have been multi-billion or multi-trillion dollar businesses — that nobody is building, for
no reason other than that nobody went and did it. His own evidence: the technology for supersonic
flight existed long before Boom was founded, and the company could technologically have been
created ten years earlier. Nobody started it.

His formulation: the law of large numbers does not apply to startups, because the world is a
smaller place than we are told. So pick a problem you want to go solve, and do not worry too much
about the answer to "why now" — the answer can be *because I started now.*

# The related dissolution

[Patrick Collison](/sources/patrick-collison.md) dismantles the mirror-image belief — that
opportunities are ephemeral and you must move now or lose them — against decades of evidence that
Silicon Valley has a surfeit of opportunities.[^ss26-collison] See
[/concepts/college-and-urgency.md](/concepts/college-and-urgency.md).

Between them: neither "too late" nor "too early" is usually the real constraint.

# See also

- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md)

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
