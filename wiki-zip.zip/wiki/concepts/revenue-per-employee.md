---
type: Concept
title: "Revenue per employee that did not exist before"
description: "Nine figures in eight months; $15M annualised at 15 people; $60M at about 40 — figures Tan says have no precedent in software, oil or railroads."
tags: [metrics, company-building, ai-native]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The numbers

Garry Tan's cited cases from recent YC batches:[^ss26-tan]

- **Emergent** (S24): public launch to nine figures of revenue in eight months; at $15M
  annualised revenue the company was 15 people.
- A Winter 24 company reaching about **$60M annualised with roughly 40 people**. (The
  auto-transcript renders the name as "Retail"; treat the company name as unverified — see
  [transcription caveats](/sources/index.md#transcription-caveats).)

His claim about them: that revenue per person did not exist before — not in software, not in oil,
not in railroads — and that these are not freaks of nature but the first companies built natively
on the new physics, each starting as one or two people wired the way he describes in
[/concepts/personal-agi.md](/concepts/personal-agi.md).

# The batch-level version

A quarter of the W25 batch had codebases that were 95% AI-generated, and that batch is on track
to be one of the fastest-growing and most profitable in YC history. Tan explicitly disclaims
causation: he cannot prove the AI-generated code caused the growth. What he claims is narrower and
harder to dismiss — that the fastest-growing founders YC funds do not treat AI as autocomplete but
as a workforce.

# The scaling-organisation counterpoint

[Max Junestrand](/sources/max-junestrand.md) is the counter-datapoint in the same playlist:
Legora's $1M→$100M run came with headcount growing to the high hundreds and beyond, and his
account of what broke first at scale is *communication*.[^ss26-junestrand] High revenue per head
appears to be a property of a phase, not a permanent state.

# See also

- [/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md)
- [/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
