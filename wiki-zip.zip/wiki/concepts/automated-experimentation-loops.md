---
type: Concept
title: "Automated experimentation loops"
description: "Decompose a goal into sub-problems, run each in a tight automated propose-implement-evaluate loop, and reassemble."
tags: [research-method, agents, science, ml-research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

# The prediction

Asked for a bold 2027 prediction, Jeff Dean names automation of ML systems themselves: getting
ML systems to improve their own capabilities by running many experiments, breaking problems into
sub-problems, running those in a tight automatic experimentation loop, and putting the results
together into an improved system. He extends it immediately beyond ML — anything with a
measurable objective.[^ss26-dean]

# Why it is the scientific method with the latency removed

His framing: propose an experiment, implement what you need to run it, evaluate it, get results.
What is newly possible is running not a few experiments but very many, because the loop is
automated and its latency is low. Add an orchestration framework that takes high-level
objectives, decomposes them into sub-problems, runs an automated loop per sub-problem, and
assembles the solutions — and you get acceleration in ML, science and engineering
simultaneously.

Applied to model development specifically: today humans think of ideas, run small-scale
experiments, promote the promising ones to larger scale, and integrate results into a new
recipe. Dean sees no real impediment to that becoming a much more automated loop, with a nudge
from people at the highest level, optimising discoveries per unit of compute input.[^ss26-dean]

He notes AlphaChip (layout) and AlphaEvolve (propose, evaluate, keep what works) as existing
instances of the shape.

# The policy version

[Michael Kratsios](/sources/michael-kratsios.md) describes the physical counterpart as the thing
he hopes founders build: see [/concepts/autonomous-cloud-labs.md](/concepts/autonomous-cloud-labs.md).

# The dependency

Fast evaluation is the gating factor. See
[/concepts/learned-surrogate-evaluators.md](/concepts/learned-surrogate-evaluators.md).

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
