---
type: Concept
title: "Mini-games and re-qualifying for the job"
description: "Junestrand tells his executives he must re-qualify as CEO every quarter, because the company is a new company every quarter."
tags: [leadership, scaling, executives, hiring]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The frame

The interviewer offers the "mini-games" framing — that a founder plays a sequence of distinct games
and earns the next one by winning the last — and Junestrand accepts it, noting he has played a lot
of them in eighteen months and is now at the game of hiring people to run functions, which he has
never done.[^ss26-junestrand]

His answer to how you learn something like that: in a way, most of the work up to that point is
what qualifies you for it. But you have to make sure you *actually learn* in each mini-game, and
put the company first, well ahead of your own ego.

His statement to his executive team: he needs to re-qualify for the job of CEO every quarter,
because it is a new company with new challenges — and so do they, since running a sales team at $1M
ARR is very different from $150M.

# The specific difficulty at their growth rate

Very few people have done it this fast. The executives they bring on come from a SaaS world of
triple-triple-double-double, where 40% year-over-year growth means you are doing fantastically and
on track. His CFO joined from a company that grew from about $30M to $300M over roughly four years
and from 200 to 1,300 people — and Legora is compressing that into about one year.

⚠️ The transcript's headcount figures are internally inconsistent between the talk (over 750
people) and the Q&A comparison (1,300); see
[/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md).

# What he says the job requires

Compress timelines; be brutal at saying no to things; understand where you personally have the most
competitive edge and can do the most. And on the personal precondition: if you enjoy learning new
things and being challenged, and accept that your most important job is now building the executive
team, you will succeed at it.

# What breaks first at scale

His unprompted answer, which is worth recording: communication is the thing that really breaks when
you scale.

# See also

- [/concepts/founder-rate-of-improvement.md](/concepts/founder-rate-of-improvement.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
