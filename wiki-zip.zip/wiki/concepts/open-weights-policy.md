---
type: Concept
title: "Open weights as stated US policy"
description: "The administration's position, per Kratsios: US leadership requires both a vibrant closed and a vibrant open ecosystem."
tags: [policy, open-source, open-weights]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

# The stated position

Against a week of speculation that an executive order might clamp down on open-weight models —
and a letter YC helped organise, addressed in part to him — Kratsios said the policy is unchanged
from page one of the AI Action Plan released the previous July, which he co-authored: chapter one
opens with a commitment to open source, on the view that if the US wants to lead in AI it must
have a vibrant closed *and* open ecosystem working together.[^ss26-kratsios]

He framed the week's noise positively: if Washington hears nothing from the startup ecosystem, or
big tech, or financial services, it cannot make the best decisions — so weeks like that are
practically useful because they force the community to articulate what it believes.

# The industry chorus

This is the single most consistently held position across the playlist.

- [Alexandr Wang](/sources/alexandr-wang.md): a decentralised world of AI capability, with
  open-source models coming, because empowering the ecosystem and developers is the
  goal.[^ss26-wang]
- [Jensen Huang](/sources/jensen-huang.md): modern AI would not exist without Linux, Kubernetes,
  Torch, Theano, Caffe and PyTorch; everybody and every company should be able to build their own
  AI, and open source is what makes it possible.[^ss26-huang]
- [Peter Steinberger](/sources/peter-steinberger.md): every lab will sell you an agent, and open
  source is the alternative — running anywhere, working with any model, and with local models
  keeping your data on your device.[^ss26-steinberger]

# The commercial counterweight

Junestrand notes that banks and large law firms often refuse Chinese models regardless of
benchmark performance, and that a data-processing agreement, not capability, was what blocked him
from offering a strong cost-adjusted model. Open weights are necessary but not sufficient for
enterprise adoption. See [/concepts/eval-driven-model-routing.md](/concepts/eval-driven-model-routing.md).

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
