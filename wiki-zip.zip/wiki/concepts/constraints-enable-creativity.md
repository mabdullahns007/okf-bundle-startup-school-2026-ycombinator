---
type: Concept
title: "Constraints enable creativity"
description: "16x16, one bit, no undo — and Kare's position that you can be creative within any constraints if you understand and welcome them."
tags: [design, constraints, craft, iteration]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Susan Kare"
    last_modified: 2026-08-14
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# The claim

Susan Kare's stated position: you can be creative within any constraints — she notes you can make
pretty fun art out of beach trash while walking around. But it helps to understand what the
constraints *are*, and then be excited about them rather than upset that you do not have a thousand
colours.[^ss26-kare]

Her actual constraints on the Macintosh: 16x16 and 32x32 pixels, one bit — black and white. The
boot icon had to be 32x32 because the machine had 128K of memory.

# The tooling constraint, and why she calls it a marvel

Andy Hertzfeld wrote an icon editor so she no longer had to design on graph paper. It had **no
drawing tools** — you toggled individual bits — no shape tools, and no undo stack. What it did have:
a greatly enlarged view alongside the actual 72-DPI result, and automatic generation of the icon's
hex code. Her assessment is worth sitting with: it is hard to overstate how great this was, because
*you could iterate without an eraser.*

Her stated moral for the whole icon section is simply: lots of iteration. Compare
[/concepts/iteration-velocity-as-the-master-variable.md](/concepts/iteration-velocity-as-the-master-variable.md).

# Why this is not merely nostalgia

The constraint pattern recurs directly in this playlist under different names:

- [Chelsea Finn](/sources/chelsea-finn.md): the token budget forces tiered memory rather than more
  context. See [/concepts/multi-timescale-robot-memory.md](/concepts/multi-timescale-robot-memory.md).
- [Boris Cherny](/sources/boris-cherny.md): the original Claude Code was made by *removing*
  scaffolding, and the model turned out to be more intelligent with fewer instructions. See
  [/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md).

# See also

- [/concepts/sparse-metaphor-over-literal-detail.md](/concepts/sparse-metaphor-over-literal-detail.md)

[^ss26-kare]: Susan Kare, [Susan Kare: Designing Icons & Graphics For the Original Mac](/sources/susan-kare.md), Startup School 2026.
[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
