---
type: Concept
title: "Autonomous cloud labs"
description: "Hypothesis, experiment, result, new hypothesis — on a loop, without human intervention."
tags: [science, robotics, automation, policy]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The ask

Asked what he hopes a couple of 20-year-olds build because government cannot or should not,
Kratsios names the infrastructure of autonomous experimentation: cloud labs running experiments
on a loop with no human in it — testing a hypothesis, running the experiment, seeing the result,
forming a new hypothesis, testing it again, and reaching a conclusion. He says it is in
sight.[^ss26-kratsios]

# What is missing

Two things, in his account: robotics has to be perfected enough to build such labs, and the
software ecosystem has to exist to think through and generate the next hypothesis. He describes
the resulting space of work as almost infinite, and expects scientists across many domains to
lean on it.

# The two halves elsewhere in the playlist

- The robotics half: [/sources/chelsea-finn.md](/sources/chelsea-finn.md) on getting robots
  reliable and autonomous enough for real workflows, and
  [/concepts/robot-rl-with-human-interventions.md](/concepts/robot-rl-with-human-interventions.md).
- The software half: [Jeff Dean](/sources/jeff-dean.md)'s 2027 prediction is precisely the
  orchestrated automated experimentation loop, with the caveat that fast evaluators are the
  gating factor.[^ss26-dean] See
  [/concepts/learned-surrogate-evaluators.md](/concepts/learned-surrogate-evaluators.md).

That convergence — a policy official and a chief scientist independently naming the same missing
infrastructure in talks a fortnight apart — is one of the stronger signals in this collection.

# See also

- [/concepts/shape-the-arena-not-the-discovery.md](/concepts/shape-the-arena-not-the-discovery.md)

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
