---
type: Concept
title: "Eval-driven model routing"
description: "The core IP Junestrand recommends building: the ability to evaluate use cases, because that is what lets you route."
tags: [evals, model-routing, product, enterprise]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

# The claim

Junestrand's answer on working with many models: the core IP and muscle he encourages founders to
build is the ability to **evaluate use cases**, because that is the superpower that then lets you
route work effectively.[^ss26-junestrand]

How they built it: they hired lawyers into Legora and made part of their job customer-facing and
part of it building out use cases to run evals against.

# The two user camps

His observation that demand splits, and the split is economic rather than aesthetic:

- Users who want to loop the most capable models on complex problems for long periods, racking up
  large inference costs — justified because in law the token or software spend is tiny relative to
  the human expertise applied. On complex litigation you want the most brain you can throw at it.
- Users asking for cheaper open-source models to reduce consumption cost.

His answer is that the truth is somewhere in between, and that the cost/intelligence frontier is
yet to be seen.

# The benchmark

They published their internal benchmark after keeping it private for three years — the reason for
the delay being that when only two labs' models were worth offering, publishing benchmarks was not
interesting. With a wider field they found one model surprisingly strong given its cost, and could
not yet offer it to customers for lack of a data-processing agreement. He also notes banks and
large firms frequently refuse Chinese models regardless of performance.

# The structural version

[Dmitri Dolgov](/sources/dmitri-dolgov.md) makes the same argument at foundation-model scale: the
model is table stakes and evals are the moat.[^ss26-dolgov] See
[/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md).

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
