---
type: Concept
title: "Strong emotional reaction as a product-market-fit signal"
description: "Nobody understood the explanation, so Steinberger stopped explaining and let people talk to it — and every reaction was strong."
tags: [product-market-fit, product, user-research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

# The problem

Steinberger had built something that felt to him like the future — an agent reachable from his
phone, proactive, occasionally checking on him, with model choice, context size and session
boundaries hidden away. Despite a large existing following, week after week he failed to make
anyone understand why it was magical.[^ss26-steinberger]

# The move

He stopped explaining. He created group chats with friends, added the relay, and let them talk to
it directly.

# The signal

Every single time he got a **strong emotional reaction**. Some people were amazed. Some were
scared or even freaked out. The valence varied; the intensity did not. And the part he treats as
decisive: several people genuinely wanted it, and when he told non-technical friends it was not
ready for them, *they got mad.* His conclusion — if that is not an indicator of product-market fit,
he does not know what is.

# Why the shape of the signal matters

The useful generalisation is that indifference, not criticism, is the negative result. A demo that
produces a polite nod has failed; one that produces fear, delight or anger has found something
real. Note also the mechanism: the signal only appeared when he removed his own explanation from
the loop and let the artifact speak.

# The companion rule

His answer on getting the first ten users is the same instinct applied to himself: **user number
one should be you**, and users two through twenty are friends. If you do not get excited about what
you are building it probably will not be good — and in an era when building is fast, eyeballs are
the expensive currency.

# See also

- [/concepts/fun-is-velocity.md](/concepts/fun-is-velocity.md)

[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
