---
type: Concept
title: "College, dropping out, and manufactured urgency"
description: "Collison dropped out twice and returned in between; the urgency he felt he now judges unnecessary."
tags: [education, career, founder-psychology, timing]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# The mechanics

Collison notes he has the slightly unusual distinction of having dropped out of college twice to
start a company — after his freshman semester, returning for another year at MIT, then leaving
again for Stripe. His point in saying so: it is not a trapdoor. You can drop out and in fact
return.[^ss26-collison]

His assessment of the risk: a lot of parents think dropping out is very risky and will impugn your
reputation for life, and as far as he can tell nobody has ever cared. So he both thinks you do not
*need* to and that the costs of doing so are minimal. If you enjoy college, there is no harm in
finishing; if you do not, that is a reason.

# Where the urgency came from, and why he now discounts it

He describes a general haste — life is short, and having speed-run high school you naturally try to
speed-run college. Plus a specific belief he attributes to a version Marc Andreessen also
articulates: that Silicon Valley opportunities are ephemeral and fleeting, so if you do not build
it now the chance will be gone in three or four years. In hindsight he calls that a poor intuition,
against decades of evidence that Silicon Valley has a *surfeit* of opportunities.

Applied to the current "drop out now or join a permanent underclass" meme, he invokes humanity's
long affinity for millenarian models of technological change — citing *The Winged Gospel* on the
belief that aviation had inaugurated a wholly new era for the species — and says he would take the
under on this being the last couple of years to get a company going.

# The other views

[Sam Altman](/sources/sam-altman.md) calls the same meme dumb, and notes that if it were true the
world would be a very bad place.[^ss26-altman]
[Alexandr Wang](/sources/alexandr-wang.md) provides the constructive middle: his gap year at a
company taught him what building and iterating actually look like from the inside, and his one year
at MIT gave him the room to explore that produced the idea.[^ss26-wang]

# See also

- [/concepts/why-now-is-because-i-started.md](/concepts/why-now-is-because-i-started.md)

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
