---
type: Concept
title: "Concentration of power"
description: "The named failure mode of the AI transition — and the two speakers best placed to know disagree about how likely it is."
tags: [ai-safety, economics, politics, decentralization]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# Altman's framing

Sam Altman argues concentration of power has been bad in essentially every moment of human
history, to varying degrees, and that he holds a genuinely startup-flavoured belief that society
is best off when power is widely distributed and anyone with a good idea can start a company,
make art, or run for office.[^ss26-altman]

He can imagine both worlds: AI producing the greatest distribution of power ever seen, or
concentrating it to a degree never seen — one company, person or model with more power than
everything else on Earth combined, which he calls terrible and a long-term disaster even if it
bought short-term safety. His stated conclusion: none of us should want to be locked into one
company's or one person's moral worldview.

The practical consequence he draws for how OpenAI behaves: be fairly reserved about imposing a
worldview on what people should do with AI, while still maintaining a safety bar.

His second, less-discussed dystopia: over-correcting on safety so that you get a cure for cancer
and material abundance purchased with a perfect surveillance state, no privacy and no agency —
comfort with nothing left that matters. His proposed metric against both: every year, people have
more freedom, agency and control over their time.

# Collison's disagreement

[Patrick Collison](/sources/patrick-collison.md) is the most concrete dissenter, and argues from
data rather than principle: given the hunger with which new companies are starting and existing
ones retooling, he does not worry about centralisation in the same way and expects many thousands
of winners and a more decentralised, broadly prosperous world — while explicitly declining
definitive prognostication.[^ss26-collison] See
[/concepts/business-formation-data-2026.md](/concepts/business-formation-data-2026.md).

[Alexandr Wang](/sources/alexandr-wang.md) also rejects a totalising single-AI world in favour of
an ecosystem of billions of personal agents and business agents.[^ss26-wang]

# What a founder can do about it

Altman's answer is unusually modest: start a successful startup. If that is all you do, the
economy keeps working and power stays diffused, and that alone is a large contribution.
[Garry Tan](/sources/garry-tan.md) makes it a personal-ownership question instead — see
[/concepts/own-your-skill-files.md](/concepts/own-your-skill-files.md).

[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
