---
type: Concept
title: "Context engineering"
description: "The context window is unambiguous where training data is a soup; the system around the model is therefore most of what determines capability."
tags: [agents, context-engineering, retrieval, tools]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# Why context beats parameters for the builder

Jeff Dean's argument is informational: trillions of training tokens are stirred into hundreds of
billions of parameters, which makes them *less clear* to the model than the context it is handed
directly for this particular problem. So the model is only one piece of a system that also knows
how to use tools, retrieve relevant information, carry history from past problems, decompose a
problem into a sequence of tool calls, try multiple approaches and evaluate them.[^ss26-dean]

His practical point for founders: this is the layer you can work on without a training run.
Training required enormous compute and data; context engineering needs an API key and your own
retrieval and tool setup.[^ss26-dean]

# How to get good at it

Dean's method is empirical: use the models on real problems, watch where they fail, and fix it
from the outside — better guidelines, skills that teach tool use — which puts you on a
self-improving loop for the *setup* rather than the weights.[^ss26-dean] This is the same
empirical posture [Boris Cherny](/sources/boris-cherny.md) describes in
[/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md).

[Garry Tan](/sources/garry-tan.md) makes the strongest version of the claim: the weights are
everyone's and the library is yours, so a better model makes your context worth *more*, because
a smarter reader extracts more from the same books.[^ss26-tan]

# See also

- [/concepts/library-and-librarian.md](/concepts/library-and-librarian.md)
- [/concepts/skills-as-encoded-method.md](/concepts/skills-as-encoded-method.md)
- [/concepts/personal-context-as-a-compounding-asset.md](/concepts/personal-context-as-a-compounding-asset.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
