---
type: Concept
title: "How hard can it be?"
description: "Huang's deliberate posture: assume the thing is learnable and let the difficulty arrive a day at a time rather than as anticipatory anxiety."
tags: [founder-psychology, resilience, learning]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The posture

Huang's answer to what he would tell his younger self begins with what he actually felt when
NVIDIA was founded: that there was so much for him to know and so much to learn, and he did not
know it. There was no YouTube and no YC, and nobody teaching you how to start a company — so he
bought a book called *How to Start a Company*, found it was 500 pages, and figured that by the time
he read it he would be out of business and out of money, so there was no sense reading it.[^ss26-huang]

What he remembers most vividly is how scared he was to raise money, because he was about to talk to
people whose questions he did not know how to answer. His comment: that was true, and he barely
knows how to answer their questions even today. And the thing he learned is that none of it matters
— you are always going to have things you do not know, and the technology changes every day.

# The mechanism

His formula: this is important, I have to go learn it, I have to do something about it, I had
better get to it as fast as I can, and *how hard can it be?* He is explicit that it always turns
out much harder than expected — but that you do not want your mind to be there, because imagining
how hard it will be turns into anxiety and not doing anything.

His decomposition of resilience: you do not have to overcome life in one day, you have to overcome
*this morning*. Get through today, work toward tomorrow. He names learning as the single greatest
superpower, and resilience as probably the single most important thing.

# The timing claim attached to it

He calls this the greatest time in sixty years to start a company, on the grounds that the single
most important technology in human history — the computer — has been completely reset, and says
he is jealous of the audience.

# See also

- [/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md)
- [/concepts/optimize-for-the-worst-day-and-the-best-day.md](/concepts/optimize-for-the-worst-day-and-the-best-day.md)

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
