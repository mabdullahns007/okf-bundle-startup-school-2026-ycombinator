---
type: Concept
title: "Code review as risk management"
description: "Steinberger's earliest speed decision, which he still lives with: he does not read all the code."
tags: [engineering, code-review, agents, risk]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The decision

Asked what decision he made purely for speed that he still lives with, Steinberger answers: very
early on, deciding not to read all the code. He reframes review as **risk management** rather than
verification.[^ss26-steinberger]

How he allocates attention: when you touch a system that is scary, you read more closely. When you
build UI, do you really care how it is built if it looks correct? No — you glance over it, or you
simply accept that it looks right.

# The substitute signal

The interesting part is what he uses instead of reading. Partly you develop a feel for how long
something should take: if a small tweak to how dragging works takes three hours, he knows something
is wrong and looks closely. Otherwise review is largely observing — how big the change is — and
trusting your gut.

# The important qualifier

He is explicit that the appropriate level depends on context: doing open source by himself is a
different risk-management problem than shipping software at a lab, where he says they *do* still
read all of the code.

# The convergent practice

[Max Hodak](/sources/max-hodak.md) reports the same posture from a very different domain — he has
written a lot of code in his life and says he has barely looked at the source in six
months.[^ss26-hodak] See [/concepts/ai-native-company-context.md](/concepts/ai-native-company-context.md).

# The tension worth recording

This sits uneasily beside [/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md),
and the reconciliation is that both replace human reading with something else: Cherny replaces it
with a machine-checkable verifier the agent runs itself; Steinberger replaces it with calibrated
human judgment about where the risk actually is. Neither claims that nothing checks the work.

[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
