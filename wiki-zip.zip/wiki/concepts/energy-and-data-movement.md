---
type: Concept
title: "Energy as the unit, and the thousandfold cost of moving data"
description: "An arithmetic operation costs about a picojoule; fetching its operand from memory costs roughly a thousand times more — which is why batching exists."
tags: [hardware, systems, energy, inference, latency]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The ratio

Jeff Dean's framing is that the unit in which everything is now measured is energy. A single
multiply is on the order of a picojoule; bringing the operand in from high-bandwidth memory into
the processor so it can be computed on costs roughly a thousand times that.[^ss26-dean]

# What that single ratio explains

Batching. Without the thousandfold gap you would not need it; because of it, you batch many
examples or tokens to amortise the movement, paying a thousand divided by batch size rather
than a thousand. Which is precisely why very low-latency serving is hard: batching is not good
for latency.[^ss26-dean]

His pointed observation for founders: problems that get called *model* problems are frequently
energy or data-I/O problems. Even the shape of training — assembling batches, running epochs —
reads as a modelling convention but is a systems and I/O consequence.

# The AI-era numbers worth knowing

His update to the famous latency-numbers list: bandwidth from accelerator main memory to on-chip
memory to the multiplier unit; the energy of a single multiply; interconnect bandwidth between
chips and how many chips that bandwidth spans; and how network bandwidth falls off when you must
talk to ten thousand chips rather than five hundred.[^ss26-dean]

# Where he thinks the headroom is

Inference, because it genuinely wants very low latency where training does not: minimise data
movement, use extremely low precision, and possibly support only the precisions you actually
need rather than many. He notes that specialisation delivers large wins precisely by
foreclosing generality — a TPU cannot run a browser. His provocation: imagine what you could
build if latency were fifty times better.

# See also

- [/case-studies/tpu-napkin-math.md](/case-studies/tpu-napkin-math.md)
- [/concepts/napkin-math.md](/concepts/napkin-math.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
