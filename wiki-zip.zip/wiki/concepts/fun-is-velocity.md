---
type: Concept
title: "Fun is velocity"
description: "Steinberger's thesis from the title of his talk: the weeks he enjoyed building, the product visibly improved; the weeks he did not, they shipped config options."
tags: [motivation, velocity, open-source, burnout]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# The claim

Peter Steinberger's talk is named for this line, and he arrives at it by way of failure rather than
inspiration. Around February, OpenClaw stopped being fun and started to feel like a
responsibility — and the man who did not want to build another company found he had a job and, as
he puts it, a calling.[^ss26-steinberger]

The worst symptom he names is diagnostic rather than emotional: **he stopped using his own
product.** Somewhere in that period he stopped making a product he loved and started making
something for everyone — less a thing he used every day and more a thing he saw and felt as work.

His summary of the correlation: the weeks he enjoyed building, the product got visibly better; the
weeks he did not, they shipped config options. See
[/concepts/configuration-sprawl.md](/concepts/configuration-sprawl.md).

# The recovery

Not willpower. Structural changes: sorting out a visa, forming a non-profit, corporate donors,
finding good collaborators who believe in open source, and one hardware vendor that simply asked
what he needed and then sent people to take over much of the security work. By around May the joy
was returning. His own hindsight: he could have asked for more help and moved responsibility off
his plate, but was too deep in everything to think strategically.

His closing formulation on competition: it is hard to compete with someone who is just there
having fun.

# The related but distinct claim

[Blake Scholl](/sources/blake-scholl.md) argues for work–life *harmony* rather than balance, on the
grounds that the opposition makes no sense if the work is meaningful, and that he never found he
could not fit in one more thing he wanted — he started Boom with three children under two. His
advice: do things you love and do not let non-meaningful detritus soak up your time, energy and
passion.[^ss26-scholl]

# See also

- [/concepts/emotional-reaction-as-pmf-signal.md](/concepts/emotional-reaction-as-pmf-signal.md)
- [/concepts/love-the-hustle.md](/concepts/love-the-hustle.md)

[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
