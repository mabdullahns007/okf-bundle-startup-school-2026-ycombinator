---
type: Concept
title: "Conviction against consensus"
description: "The most consistent claim across the playlist: build on a belief the field thinks is wrong, and be willing for that to take years."
tags: [founder-psychology, conviction, strategy, contrarianism]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The core claim

Four of the fifteen speakers make a version of this argument, and it is the closest thing the
event has to a thesis.

**Sam Altman** calls it his highest-order advice: find things you can develop reasonable
conviction in where conventional wisdom is simply wrong, and be okay with it taking a long time
while people are frustratingly dismissive. For years OpenAI was told not just that it was wrong
about AGI but that it was irresponsible and would cause another AI winter. In hindsight he calls
that an incredible gift — it meant no massive competitors and time to do the research and build
the company. His inverse observation: if you are starting the same startup as everyone else you
get hype and can raise money, but those are much less frequently the big outcomes.[^ss26-altman]

**Alexandr Wang** puts it structurally: the most successful companies were started long before
their core idea was popular, and toiled in obscurity until it became consensus. So you must
identify truths about the world early, and build your own compass, because going with the herd
leaves you immensely confused and nowhere. See
[/concepts/first-principles-market-discovery.md](/concepts/first-principles-market-discovery.md)
for the concrete instance.[^ss26-wang]

**Jensen Huang** frames it as what makes great companies: a unique high-level perspective about
the future of something important that you deeply believe in — ideally one that is hard to
pursue.[^ss26-huang]

**Max Junestrand** supplies the small-scale version: a VC passed on Legora's pre-seed for having
no lawyers on the team; Legora had, in his own words, no reason to exist.[^ss26-junestrand]

# The calibration

Altman supplies the guard rails that keep this from being mere stubbornness: if you cannot find
*anybody* who shares the belief, pay attention to that — and if everybody believes it, that is
also a bad sign. His joke is that only fifty people thought AGI was possible and forty-five
worked at OpenAI. He also notes that saying the heretical thing is probably *why* those people
wanted to be together.

**Max Hodak** gives the sharpest formulation of the underlying logic: in school, copying your
neighbour drags you toward the class average, and in startups the average is not good enough,
because the successful companies are the exceptions. See
[/concepts/judgment-cannot-be-delegated.md](/concepts/judgment-cannot-be-delegated.md).

# See also

- [/concepts/rejection-as-signal-vs-noise.md](/concepts/rejection-as-signal-vs-noise.md)
- [/concepts/why-now-is-because-i-started.md](/concepts/why-now-is-because-i-started.md)

[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
