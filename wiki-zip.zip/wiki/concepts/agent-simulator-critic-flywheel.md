---
type: Concept
title: "The agent, the simulator and the critic"
description: "Three AIs on one shared foundation, arranged as a flywheel and steered by metrics."
tags: [physical-ai, evaluation, flywheel, architecture]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

# The three AIs

Dolgov's sixth lesson: at this complexity you cannot build a model and call it done — you build
an ecosystem, and it needs three AIs. The **agent** that performs the task, the **simulator** as
a virtual playground to learn in, and the **critic** that rigorously evaluates the agent and
tells it how to improve. His key structural point: the fundamental reasoning and generative
capabilities of all three are shared, which is why in Waymo's case all three are built on the
same foundation world model.[^ss26-dolgov]

# The flywheel

Deployment in the real world generates data → data grounds the simulator and makes it more
realistic → the simulator generates harder edge cases for the critic to score and the agent to
learn from → the agent gets smarter and is deployed → more data. 

# Why metrics are the steering wheel

A flywheel will spin in any direction, or in place. Metrics are what make it turn the way you
want — which is how this lesson hands off to
[/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md).

# See also

- [/concepts/closed-loop-simulation.md](/concepts/closed-loop-simulation.md)
- [/concepts/automated-experimentation-loops.md](/concepts/automated-experimentation-loops.md) —
  the same shape applied to science and ML research.

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
