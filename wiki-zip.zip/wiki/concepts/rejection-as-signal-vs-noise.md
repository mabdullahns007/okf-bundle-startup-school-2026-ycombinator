---
type: Concept
title: "Rejection as signal vs noise"
description: "Legora was rejected by YC, Boom's seed was passed on, the distillation paper was rejected — and each rejection meant something different."
tags: [rejection, resilience, feedback, founder-psychology]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

# Four rejections in one playlist

- **[Max Junestrand](/sources/max-junestrand.md)**: Legora applied to YC in May 2023 and was
  rejected after answering "are there different types of lawyers?" — a partner laughed and they knew
  they were finished. His treatment of it: they were let down, got back to building the day after
  next, did the homework, and were accepted two months later under a new name with a different
  platform. This rejection was **signal**, and they acted on its content.[^ss26-junestrand]
- **[Blake Scholl](/sources/blake-scholl.md)**: Jeff Bezos passed on Boom's 2015 seed round and
  wrote in that year's Amazon shareholder letter that some things only large companies can do,
  citing airliners.[^ss26-scholl] XB-1 later became the first independently developed jet to break
  the sound barrier.
- **[Jeff Dean](/sources/jeff-dean.md)**: the distillation paper was rejected with the comment that
  it was unlikely to have significant impact. See
  [/case-studies/distillation-paper-rejection.md](/case-studies/distillation-paper-rejection.md).
  Dean explicitly does not blame the programme committee.
- **[Sam Altman](/sources/sam-altman.md)**: years of being told OpenAI was not merely wrong but
  irresponsible — which he now calls an incredible gift.[^ss26-altman]

# The distinction worth drawing

These are not the same event. Junestrand's rejection carried information about a real gap in their
understanding, and they closed it. Dean's and Altman's carried information about the *evaluators'*
vantage point — Dean's guess is the reviewer was thinking about fundamental advances rather than
serving models at scale, and simply had different experience.

The useful question is therefore not whether to persist but which kind you received: does the
rejection describe your work, or the reviewer's position? Both Junestrand and Dean answer it by
looking at the *content* of the objection rather than its valence.

# See also

- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
