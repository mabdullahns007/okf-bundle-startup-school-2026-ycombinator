---
type: Concept
title: "Compositional generalization"
description: "Combining concepts the training data never combined implies conceptual understanding — and buys data efficiency."
tags: [robotics, generalization, foundation-models, evaluation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

# Why it matters

Finn dates the first signs of compositional generalisation in generalist AI to 2021, and treats
the avocado-chair result as the milestone. Two things follow when a model has it: it must have
some conceptual understanding of both concepts to combine them, and your data need not cover
every possible combination — a real data-efficiency property.[^ss26-finn]

# The robotics tests

1. **Skill × rare appliance.** Open an air fryer, put a sweet potato in, close it. The appliance
   was chosen on the assumption it was absent from training data; post-hoc analysis found three
   episodes containing one, which Finn reports honestly while arguing it likely had no impact.
   The robot combined a manipulation skill with an object it had effectively never seen.
2. **Task × robot platform.** Folding clothes on a large industrial platform with *no* folding
   data collected on that platform — differing from the trained platform not just in size but in
   link lengths and joint configuration. She says the team was floored the first time it worked.
   Quantitatively, folding performance on the unseen platform rose sharply with model generation
   and approached human teleoperation despite no robot-specific folding data.
3. **An unplanned one.** In pinwheel assembly, every demonstration picked up the pin with the
   right hand and paper with the left. After a mistake reversed the objects, the robot inserted
   the pin with its left gripper into paper held in its right — a left/right equivariance present
   in neither post-training nor pre-training data. She calls it an emergent capability she had
   not seen before.

# What produces it

Her ablations point at data diversity plus prompting, not scale alone. See
[/concepts/metadata-prompting-for-heterogeneous-data.md](/concepts/metadata-prompting-for-heterogeneous-data.md).

[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
