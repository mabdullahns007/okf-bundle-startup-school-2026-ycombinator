---
type: Concept
title: "Fast path and slow path in one foundation model"
description: "A shared multimodal world-action-language model with millisecond reflexes and a slower semantic reasoner, distilled to a light on-vehicle layer."
tags: [architecture, world-models, physical-ai, foundation-models]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The model

Dolgov unpacks the Waymo foundation model term by term: **multimodal** because it processes
camera, lidar and radar; a **world model** because it encodes physics, dynamics and the social
and semantic character of the world; an **action model** because the agent is an active
participant that must understand the effect of its actions and tell good ones from bad; and
**language-aligned** so it inherits general world knowledge from VLMs, which is valuable in the
long tail of rare semantic situations.[^ss26-dolgov]

Architecturally it is an end-to-end encoder–decoder. The encoder compresses multimodal sensing
into an efficient representation retaining what the generative half needs; being end-to-end lets
gradients from the task you actually care about propagate to the earliest layers, so the encoder
learns the right rich representations.

# The two paths

- **Think fast** fuses raw camera, lidar and radar data for split-second safety-critical
  decisions — braking instantly for a pedestrian entering the road or a swerving cyclist.
  Dolgov's own framing is driving instincts, or the agent's lizard brain, handling largely
  geometric tasks in milliseconds.
- **Think slow** handles scene-level semantic understanding, where situations do not change in
  milliseconds, so latency can be traded for capability and deeper reasoning.

His illustrating case: a car on fire on the shoulder is a generic obstacle to the fast path,
which reasons the path ahead is clear. The slow path understands what a burning vehicle means
in context and chooses a different route even though the geometry is fine.[^ss26-dolgov]

# The distillation argument

Capacity and complexity are pushed upstream into the large shared foundation, keeping the
on-vehicle specialisation layer lightweight — which also speeds development and lets one
foundation serve several hardware generations and vehicle platforms, and later trucking and
personally owned vehicles.

[Jensen Huang](/sources/jensen-huang.md) describes the same class of system from the supplier
side, including world foundation models that understand physics.[^ss26-huang]

# See also

- [/concepts/structure-augmented-end-to-end.md](/concepts/structure-augmented-end-to-end.md)

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
