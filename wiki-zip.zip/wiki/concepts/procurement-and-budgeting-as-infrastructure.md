---
type: Concept
title: "Purchasing and budgeting as first-class infrastructure"
description: "Approval-time review is the wrong lever; budgeting is. And someone's job really is to buy things."
tags: [infrastructure, operations, deep-tech, burn]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The escalation

Hodak walks the path every physical company takes.[^ss26-hodak] The founder buys things on a
credit card, which works fine. Then: how does your seventeenth employee buy things? Hand out
cards and you begin approving purchases one at a time, which feels responsible because you care
about burn.

Then someone requests a $3,000 power supply and you wonder whether an auction in three days
might halve it. His resolution is arithmetic: at $100,000 a week of burn, waiting a week to save
$1,500 has already destroyed the saving several times over. And you hired highly paid talented
people — are you telling them they cannot have their tools? At a frontier lab they would simply
have the power supply.

# The actual conclusion

Purchase approval is *the inappropriate place to exercise spending review.* Review belongs
earlier, in budgeting: people need to understand the bucket of money they have so they can make
trade-offs inside it. He does not want to be adjudicating $1,500 versus $3,000 power supplies.

# The second wall

Set up a procurement system and now highly paid engineers spend their days in B2B enterprise
portals, while a power supply takes two weeks to arrive — because you cannot buy it on a card,
you must open a vendor account, handle insurance and certification paperwork, get a quote,
generate a purchase order, generate an invoice. Hodak's note is that people arriving from
academia often ask why anyone's job is *purchasing things*, and the answer is that the back and
forth is genuinely time-consuming and that going fast requires active management to metrics.

# See also

- [/concepts/cost-attribution-in-physical-r-and-d.md](/concepts/cost-attribution-in-physical-r-and-d.md)
- [/concepts/iteration-velocity-as-the-master-variable.md](/concepts/iteration-velocity-as-the-master-variable.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
