---
type: Concept
title: "Your dependency's business model is your business model"
description: "OpenClaw's harness was optimised for one lab's model; that lab gave roughly 24 hours' notice of disabling subscription access."
tags: [risk, dependencies, platform-risk, open-source]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The event

Steinberger names this as the thing that actually hurt the project most, and is careful to
separate it from the name-change demand, which he found stressful but understandable and says the
lab handled nicely.[^ss26-steinberger]

The substance: he built OpenClaw with one toolchain, but the harness had long been optimised for a
different lab's model. When that lab notified him with roughly **24 hours' notice** that they were
disabling subscription access for everyone, there was not enough time to change course. Open-weight
model support existed and had real work behind it, but the models were not good enough yet — and, in
his phrase, the early open models simply lacked character.

His formulation, offered as the line to write down: **your dependency's business model is your
business model.**

# The resolution

He reports it as fixed at the time of the talk: open-weight models are actually good now, and he
learned a great deal about harness engineering in the process. But he is clear about the cost — in
many ways people had moved on. Weekly downloads bottomed near 835,000 in May before peaking at an
all-time high of 4.7 million in June after the project was declared dead. Both are true at once,
and his metaphor for it is weather: you may see hype coming but you cannot control it.

# The enterprise version

[Max Junestrand](/sources/max-junestrand.md) names the same exposure from a commercial angle: when
a meaningful percentage of the world's lawyers are working in your system and their clients rely on
it, you cannot have it go down — which makes compute and model contracts with labs and providers a
genuine operational dependency, not a procurement detail.[^ss26-junestrand] His mitigation is
model portability backed by internal evals. See
[/concepts/eval-driven-model-routing.md](/concepts/eval-driven-model-routing.md).

# See also

- [/concepts/open-weights-policy.md](/concepts/open-weights-policy.md)

[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
