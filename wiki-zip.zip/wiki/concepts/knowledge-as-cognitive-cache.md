---
type: Concept
title: "Knowledge as cognitive cache"
description: "Collison's memory-hierarchy argument for still learning things: neuronal lookups are L1, and asking an agent is a network round trip."
tags: [learning, education, cognition]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

# The argument

Asked what students should still learn rather than outsource, Patrick Collison reaches for the
memory hierarchy — noting the pun on *cache*, not *cash*, and citing
[Jeff Dean](/people/jeff-dean.md)'s latency numbers as the reference. Retrieving from L1 cache is
very different from RAM, which is very different from crossing a network. He argues knowledge works
the same way: yes, you can ask an agent to look something up, but that is far slower than knowing
it, and you can run vastly more round trips inside your own head than you can by typing or
speaking.[^ss26-collison]

His second argument is from revealed preference: look at what companies — Stripe, the labs — actually
do, and there still seems to be an enormous premium on cognitive ability. So renouncing it before
there is evidence those benefits have saturated would be premature.

# What he still does himself

He still writes, both philosophically and substantively, saying he dislikes the models' writing.
His observation is precise: these systems can prove serious theorems, yet he has not read an LLM
essay he found compelling. His hypothesis is that the utility function is hard to define for RL,
and that writing and interpersonal communication are bound up with reasoning sensibly in the
multi-dimensional space of reality. He notes he has sent zero of the pre-written replies every tool
now suggests.

# The counterpoints in the same playlist

- [Boris Cherny](/sources/boris-cherny.md) agrees on substance but relocates it: learn computer
  science *applied* — design sense, business sense, data science, talking to users — because the
  combination is where value lies.[^ss26-cherny]
- [Jensen Huang](/sources/jensen-huang.md) draws the line differently again: the simple stuff gets
  automated, as long division did, and what survives is the hard sciences, systems thinking, and
  the intersections between domains.[^ss26-huang]

Collison's own framing of the loss is honest: we do not much mourn hand-writing assembly now that
compilers exist, so perhaps we should not mourn source code — but emotionally, he misses it.

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
