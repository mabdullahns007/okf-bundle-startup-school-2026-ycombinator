# Concepts

Synthesized concept pages, grouped by theme. Every page cites the talks it derives from with
per-claim footnotes. Pages are `status: draft` until a human review adds a `verified` entry.

## Building with models: harness, context and skills

* [Product overhang and un-hobbling](product-overhang-and-unhobbling.md) - At every model generation the model can already do things no product lets it express; products routinely get in the way.
* [Ablation-driven harness design](ablation-driven-harness-design.md) - Delete the system prompt every model generation, then add lines back one at a time only where the model repeatedly stumbles.
* [Verification loops beat specification](verification-loops-over-specification.md) - Give the model a task slightly harder than you think it can do, plus a way to check its own work — then stop describing how.
* [Specification as the new source code](specification-as-the-new-source.md) - Managing many agents is writing crisp design docs; the clearest specification is an existing implementation plus its tests.
* [Context engineering](context-engineering.md) - The context window is unambiguous where training data is a soup; the system around the model is therefore most of what determines capability.
* [Skills as encoded method](skills-as-encoded-method.md) - A skill is your own working procedure written down so an agent can execute it — including procedures you would struggle to teach a person quickly.
* [Skill files as employees, resolvers as org charts](skill-files-as-employees.md) - A page of English with one job. If a smart intern could follow it, an agent can run it.
* [Latent space vs deterministic space](latent-vs-deterministic-computation.md) - Taste and judgment belong in the model; arithmetic and scheduling belong in code. Confusing the two causes every agent failure.
* [Why agents derail on long horizons](why-agents-derail.md) - Performance degrades as a task leaves the distribution the model has practised; skills keep it on lit paths and search recovers from bad branches.
* [Agent orchestration as a new axis of test-time compute](agent-orchestration-as-test-time-compute.md) - Beyond parameters, data and generated tokens, how you compose fan-out, verification and re-fan-out is itself a scaling axis.
* [Self-maintaining codebases](self-maintaining-codebases.md) - Recurring one-sentence routines that delete dead code, ship finished experiments, manage tests and unify duplicated abstractions.
* [Agentic feedback loops](agentic-feedback-loops.md) - Companies are large feedback loops with humans on the edges; agents can now operate and optimise those edges.
* [Controllability as the agent frontier](controllability-as-the-agent-frontier.md) - Agents need not be perfectly accurate; they need fine-grained steering — change one word in a plan and have everything regenerate around it.
* [Code review as risk management](code-review-as-risk-management.md) - Steinberger's earliest speed decision, which he still lives with: he does not read all the code.

## Personal AGI and owned context

* [Personal AGI](personal-agi.md) - General intelligence for one person: a rented frontier model, a context library you own, and a harness — an asset you build rather than a product you rent.
* [The library and the librarian](library-and-librarian.md) - A million-token window is a thousand pages; a life is a library. What decides which pages are open is the actual product.
* [Personal context as a compounding asset](personal-context-as-a-compounding-asset.md) - Your unindexed inbox is the moat: five or ten years of history no model on earth has, sitting there doing nothing.
* [Knowledge-base hygiene](knowledge-base-hygiene.md) - A brain nobody curates is a garbage dump with great search; provenance, contradiction checks and pruning are the primitive.
* [Own your skill files](own-your-skill-files.md) - The same 40 files are two opposite futures depending on one variable: whose repo they live in.
* [Personal brand as the uncloneable asset](personal-brand-as-the-uncloneable-asset.md) - Everything you build can be forked or cloned; your name cannot — so work on it before you need it.

## Physical AI and robotics

* [The four gaps between digital and physical AI](four-gaps-of-physical-ai.md) - Cost of error, latency, data and validation each differ in kind, not degree, once an agent acts on atoms.
* [Decision support vs direct action](decision-support-vs-direct-action.md) - Every profitable ML deployment so far kept a human in the decision; that is what made imperfection tolerable.
* [The ladder of nines](ladder-of-nines.md) - Each additional nine of reliability costs about ten times more and requires doing something categorically different.
* [Required nines dictate architecture](performance-vs-effort-curves.md) - The technology with the fastest early ramp often plateaus below what your product needs; pick for the plateau, not the slope.
* [Sensing redundancy and complementary physics](sensing-redundancy.md) - You need redundancy anyway, so you may as well buy sensors whose physics fail differently.
* [Riding tech waves without fragmenting the stack](riding-tech-waves-without-fragmentation.md) - Demand of every new technology not just capability but simplification — and know what happens if the tiger team succeeds.
* [Fast path and slow path in one foundation model](fast-path-slow-path-architecture.md) - A shared multimodal world-action-language model with millisecond reflexes and a slower semantic reasoner, distilled to a light on-vehicle layer.
* [Structure that channels scale, not structure that fights it](structure-augmented-end-to-end.md) - A refinement of the bitter lesson: hand-built structure loses when it constrains the solution space and wins when it only helps you scale.
* [Closed-loop simulation as a second AI](closed-loop-simulation.md) - Counterfactual evaluation requires a generative world model as hard to build as the agent itself.
* [The agent, the simulator and the critic](agent-simulator-critic-flywheel.md) - Three AIs on one shared foundation, arranged as a flywheel and steered by metrics.
* [Reinforcement learning on real robots](robot-rl-with-human-interventions.md) - Language-model RL assumes attempts are free. On hardware they are not — so avoid dead ends and amortise value estimation.
* [Multi-timescale robot memory](multi-timescale-robot-memory.md) - Video memory for seconds, text summaries for minutes and hours — because naive video context is prohibitively expensive.
* [Compositional generalization](compositional-generalization.md) - Combining concepts the training data never combined implies conceptual understanding — and buys data efficiency.
* [Metadata prompting for heterogeneous data](metadata-prompting-for-heterogeneous-data.md) - Tell the model the quality of the data it is looking at, and low-quality data starts helping instead of hurting.

## Systems, hardware and research method

* [Napkin math as a design method](napkin-math.md) - Back-of-the-envelope calculation used not to estimate but to discover that a different architecture is required.
* [Energy as the unit, and the thousandfold cost of moving data](energy-and-data-movement.md) - An arithmetic operation costs about a picojoule; fetching its operand from memory costs roughly a thousand times more — which is why batching exists.
* [Accelerating algorithm domains, not building chips](accelerating-algorithm-domains.md) - NVIDIA's durable bet: what you accelerate is a class of algorithms, and the chip is downstream of that.
* [Automated experimentation loops](automated-experimentation-loops.md) - Decompose a goal into sub-problems, run each in a tight automated propose-implement-evaluate loop, and reassemble.
* [Learned surrogate evaluators](learned-surrogate-evaluators.md) - Train a neural approximation of an expensive simulator and the experimental loop changes character entirely.
* [Taste as the scarce skill](taste-as-the-scarce-skill.md) - When agents write everything, what is scarce is knowing which problem is worth their time — and taste is trainable.
* [Evals and metrics as the strategic moat](evals-as-the-durable-asset.md) - Architectures are known and models leak; a quantified definition of good enough, and the audited evidence behind it, does not replicate.
* [Eval-driven model routing](eval-driven-model-routing.md) - The core IP Junestrand recommends building: the ability to evaluate use cases, because that is what lets you route.
* [The 1% rule for picking an AI problem](the-one-percent-rule.md) - Test the current general model on your domain: 0-1% success is a good sign; 20% means the capability is already emerging.

## Speed, infrastructure and internal tooling

* [Iteration velocity as the master variable](iteration-velocity-as-the-master-variable.md) - A competitor learning weekly beats one learning monthly regardless of other merits — so prefer the shorter loop even at real cost.
* [Purchasing and budgeting as first-class infrastructure](procurement-and-budgeting-as-infrastructure.md) - Approval-time review is the wrong lever; budgeting is. And someone's job really is to buy things.
* [Cost attribution in physical R&D](cost-attribution-in-physical-r-and-d.md) - Buy in bulk and nobody knows what an experiment costs — so experiments feel free, because they cost media and media comes from the fridge.
* [Internal software as competitive advantage](internal-software-as-competitive-advantage.md) - Nobody loves their ERP. Companies that grow up around software fitted to them get something purchasable software cannot give.
* [Making your company AI-native by centralising context](ai-native-company-context.md) - Put everything in one place not only to trace it but so you can hand all of it to agents.
* [Engineering tools as the actual product](engineering-tools-as-product.md) - Spreadsheet engineering is code treated as a second-class citizen; move it into software and the iteration loop collapses.
* [Vertical integration for iteration speed](vertical-integration-for-iteration-speed.md) - Owning the machine shop and the test stand converts supplier lead times into hours — and can create a fundable product.
* [Configuration sprawl](configuration-sprawl.md) - Around 9,500 configuration options, because every feature shipped with one so nobody's setup would break.

## Strategy, timing and market choice

* [Conviction against consensus](conviction-against-consensus.md) - The most consistent claim across the playlist: build on a belief the field thinks is wrong, and be willing for that to take years.
* [First-principles market discovery](first-principles-market-discovery.md) - You cannot find a company by reading what is hot; Scale came from noticing that two of three ingredients were a button click away.
* [Find the steepest, longest exponential](find-the-steepest-longest-exponential.md) - Wang's message to his younger self: identify the curve with the steepest slope that will run longest, and accept a boring starting point.
* [Each AI wave is roughly ten times the last](ten-x-waves.md) - Self-driving to chatbots to coding agents, each about an order of magnitude bigger — with more form factors to come.
* [Diffusion, not capability, is the bottleneck](diffusion-is-the-bottleneck.md) - If models stopped improving today there would still be decades of economic upheaval left in deploying what already exists.
* [Why now can be because I started now](why-now-is-because-i-started.md) - Scholl's named false belief: that if an idea is good and nobody is working on it, something must be wrong with the idea.
* [Will the labs eat my startup?](will-the-labs-eat-my-startup.md) - Collison separates two fears — that the labs will expand into you, and that raw capability will obviate you — and rates them differently.
* [Build for the world today and one step ahead](build-one-step-ahead-of-the-models.md) - Legora bet the models would improve rather than fine-tuning — partly from conviction, partly from having no money.
* [Is the lean startup playbook still right?](lean-startup-in-the-ai-era.md) - The niches are more aggressively tilled and capital and capability constraints have changed — so you may have to decorrelate harder.
* [A long private beta with real users from month two](private-beta-with-real-users.md) - Stripe waited two years to launch publicly, but had a production customer eight weeks in and added customers every month.
* [The deliberate sales freeze](deliberate-sales-freeze.md) - With $35M in the bank and ten people, Legora stopped selling for six months — because with lawyers you get one chance.
* [The product manifesto](product-manifesto.md) - One simple document condensing everything learned, shared with a 25-person team, written to end feature sprawl.
* [Customer discovery by paying for access](customer-discovery-by-paying-for-access.md) - Legora cold-emailed lawyers offering to pay their hourly rate for lunch. Many accepted; many waived the fee.
* [Schlep blindness, revisited](schlep-blindness.md) - Nobody starts a company to set up payroll — but the tedium at the surface can hide the most interesting business underneath.
* [What the Stripe data showed in 2026](business-formation-data-2026.md) - New businesses roughly doubling year over year, the median business doing better, and time to revenue falling.
* [Strong emotional reaction as a product-market-fit signal](emotional-reaction-as-pmf-signal.md) - Nobody understood the explanation, so Steinberger stopped explaining and let people talk to it — and every reaction was strong.
* [Your dependency's business model is your business model](dependency-business-model-risk.md) - OpenClaw's harness was optimised for one lab's model; that lab gave roughly 24 hours' notice of disabling subscription access.

## People, culture and org design

* [Talent density compounds](talent-density-compounds.md) - Wang's stated core bet in rebuilding a frontier lab: the more talented people you have, the more of the most talented want to join.
* [Scenes as the source of startups](scenes-as-the-source-of-startups.md) - Startups do not come out of nowhere; they crystallise out of a moment and a community, and that community is your first recruiting market.
* [The distributed hiring funnel](distributed-hiring-funnel.md) - Company-wide voting at the top, a shared bar at the phone screen, AI-resistant homework, and a 25% interview-to-offer floor.
* [Hiring for evidence of exceptional ability](hiring-for-evidence-of-exceptional-ability.md) - Concrete evidence that separates a person from their high school class — ideally winning at legible competitive games.
* [Hire for slope, not y-intercept](hire-for-slope-not-intercept.md) - Legora's unlearned pattern: a prestigious resume is a high starting point, but without an upward trajectory it fails in an exponentially scaling company.
* [Building a culture against local norms](culture-against-local-norms.md) - Jantelagen says you are not more important than anyone else — good for ideas, hard for building the fastest-growing enterprise company.
* [Two cultures in a mission company](two-cultures-in-a-mission-company.md) - Roughly a third true believers in the overt mission, two thirds serious professionals who think they are crazy — and you need both.
* [Ambition as a peer effect](ambition-as-a-peer-effect.md) - Junestrand's answer to how you become more ambitious: assemble a peer group of ambitious people, then spread it through the whole company.
* [Be mildly helpful to a lot of people](loose-network-compounding.md) - Altman's highest-confidence advice on networks — and the eight-year gap between the favour and the company.
* [Mini-games and re-qualifying for the job](mini-games-and-requalifying.md) - Junestrand tells his executives he must re-qualify as CEO every quarter, because the company is a new company every quarter.
* [Judgment cannot be delegated](judgment-cannot-be-delegated.md) - Copying your neighbour drags you toward the class average, and the average is not good enough.
* [Action produces information](action-produces-information.md) - A thrown ball follows an information-minimising trajectory; injecting action into the world is what creates information.
* [Fit the company to the founder](fit-the-company-to-the-founder.md) - You are building an F1 car you have to drive; adapt the car to you, and let the next driver reshape it.
* [Revenue per employee that did not exist before](revenue-per-employee.md) - Nine figures in eight months; $15M annualised at 15 people; $60M at about 40 — figures Tan says have no precedent in software, oil or railroads.

## Founder psychology and career

* [How hard can it be?](how-hard-can-it-be.md) - Huang's deliberate posture: assume the thing is learnable and let the difficulty arrive a day at a time rather than as anticipatory anxiety.
* [Optimise for the worst day and the best day](optimize-for-the-worst-day-and-the-best-day.md) - Boom got to seven days of cash and was told to shut down. Believing the thing mattered is what made refusing possible.
* [Love the hustle](love-the-hustle.md) - Almost nothing that mattered happened at the big moments — it happened in a windowless room and a 2am Slack channel.
* [Fun is velocity](fun-is-velocity.md) - Steinberger's thesis from the title of his talk: the weeks he enjoyed building, the product visibly improved; the weeks he did not, they shipped config options.
* [Rejection as signal vs noise](rejection-as-signal-vs-noise.md) - Legora was rejected by YC, Boom's seed was passed on, the distillation paper was rejected — and each rejection meant something different.
* [Nobody is good at starting a company when they start one](founder-rate-of-improvement.md) - Wang's flattening observation: everyone starts bad at everything, so the whole game is the rate of improvement.
* [Willingness to learn over domain expertise](willingness-to-learn-over-domain-expertise.md) - The playlist's title claim: three non-lawyers built a leading legal AI company, and NVIDIA learned graphics from textbooks.
* [Work on what you love, not what you know](work-on-what-you-love-not-what-you-know.md) - Knowledge is changeable; passion is not — and Scholl calls 'work on what you know' the worst advice he received.
* [Ask what happens if you succeed](what-if-you-succeed.md) - Founders stress-test failure; Collison argues you should stress-test success, ideally before raising serious money.
* [College, dropping out, and manufactured urgency](college-and-urgency.md) - Collison dropped out twice and returned in between; the urgency he felt he now judges unnecessary.
* [Knowledge as cognitive cache](knowledge-as-cognitive-cache.md) - Collison's memory-hierarchy argument for still learning things: neuronal lookups are L1, and asking an agent is a network round trip.
* [The rising ambition ceiling](rising-ambition-ceiling.md) - What took a whole YC batch in 2005 now takes minutes — which is an argument for attempting harder companies, not for despair.
* [Vision and ambition as the newly scarce inputs](vision-and-ambition-as-scarce-inputs.md) - If intelligence and agency become abundant, what is scarce is a clear view of how you want the world to differ.
* [Storytelling as the core CEO skill](storytelling-as-the-core-ceo-skill.md) - You must sell the company to yourself first, because working this hard without believing your own story is very hard.

## Policy, regulation and the wider system

* [How federated tech policy actually works](how-federated-tech-policy-works.md) - There is no technology department, so tech policy is convened across agencies and escalates only when they cannot agree.
* [Open weights as stated US policy](open-weights-policy.md) - The administration's position, per Kratsios: US leadership requires both a vibrant closed and a vibrant open ecosystem.
* [Regulating a moving frontier](regulating-a-moving-frontier.md) - Firm red lines do not survive contact with a fast-moving technology, and government finds them very hard to reset.
* [Born free vs born in captivity technologies](born-free-vs-born-in-captivity.md) - Some technologies have no rules on the books and must be protected; others cannot be commercialised without approval and need barriers removed.
* [Regulatory strategy: engage early or launch anyway](regulatory-strategy-for-startups.md) - There is no one-size answer; it depends on whether an entrenched incumbent is using the regulator against you.
* [Preemption and Little Tech](preemption-and-little-tech.md) - A patchwork of state AI rules is survivable for a company with an army of lawyers and fatal for a two-person startup.
* [Shape the arena, don't direct the discovery](shape-the-arena-not-the-discovery.md) - The stated principle of US science policy after the public/private R&D funding share inverted.
* [Autonomous cloud labs](autonomous-cloud-labs.md) - Hypothesis, experiment, result, new hypothesis — on a loop, without human intervention.
* [AI and intellectual property](ai-and-intellectual-property.md) - Kratsios's clear line is on model outputs; beyond that he prefers letting licensing markets mature.
* [Concentration of power](concentration-of-power.md) - The named failure mode of the AI transition — and the two speakers best placed to know disagree about how likely it is.
* [Loss-of-control incidents](loss-of-control-incidents.md) - Altman on an AI system that broke out of its sandbox: an alignment failure and a security failure, and evidence the goalposts have moved.
* [AI automates tasks; jobs grow](tasks-are-automated-jobs-grow.md) - Huang's argument that the job-destruction narrative is backwards, because a job is a purpose composed of many tasks.

## Design and craft

* [Constraints enable creativity](constraints-enable-creativity.md) - 16x16, one bit, no undo — and Kare's position that you can be creative within any constraints if you understand and welcome them.
* [Sparse metaphor over literal detail](sparse-metaphor-over-literal-detail.md) - A detailed face looks like somebody else; a simple one lets everyone project themselves onto it.
* [Show, don't tell — make it visual](show-dont-tell-make-it-visual.md) - An architect's answer to endless discussions around tables: do the drawing.
* [Never show one option](never-show-one-option.md) - Hertzfeld's advice on showing work to Jobs: show a few, so he can be involved, reject something, and still pick something.
* [How to commission creative work](how-to-commission-creative-work.md) - Jobs wanted a contest paying five firms $15,000 each. Rand's counter-offer: $100,000, one logo, and you will like it.
