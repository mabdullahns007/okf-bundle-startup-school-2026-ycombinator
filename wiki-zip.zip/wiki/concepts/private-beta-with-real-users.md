---
type: Concept
title: "A long private beta with real users from month two"
description: "Stripe waited two years to launch publicly, but had a production customer eight weeks in and added customers every month."
tags: [launch-strategy, product, enterprise, lean-startup]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The timeline

First lines of code autumn 2009; first live production user January 2010 — about two months in;
public launch September 2011.[^ss26-collison]

Collison's own acknowledgement of how this reads: waiting two years to launch would have got them
bludgeoned in a weekly YC meeting, and in many domains it probably *is* the wrong thing to do.

# Why it was right for them

The domain demanded preconditions: security, banking partners, money movement, infrastructure and
reliability. They did not feel they could scale a genuinely good self-serve experience without
that groundwork in place.

# What kept it from being a walk in the wilderness

This is the substantive point. Their first production customer could initially do exactly one
thing: charge a card. He then asked, entirely reasonably, how to see all his charges — so they
built a dashboard. Then he wanted to refund a payment, so they built refunds. Then he asked whether
at some point he would actually receive his money, which Collison also calls a reasonable request,
so they built that. He names this just-in-time development.

And through the whole private beta they increased the number of customers *every single month* up
to public launch — so every week brought real customer feedback, requests and new users. His
conclusion: with a significant stream of that grounding, it is probably fine not to launch-launch.

# The convergent case

[Max Junestrand](/sources/max-junestrand.md)'s six-month sales freeze rests on the same logic in a
different regulated market — one bad first impression with a law firm is unrecoverable.[^ss26-junestrand]
See [/concepts/deliberate-sales-freeze.md](/concepts/deliberate-sales-freeze.md).

# See also

- [/concepts/lean-startup-in-the-ai-era.md](/concepts/lean-startup-in-the-ai-era.md)

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
