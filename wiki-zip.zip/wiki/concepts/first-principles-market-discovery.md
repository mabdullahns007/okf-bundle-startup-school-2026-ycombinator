---
type: Concept
title: "First-principles market discovery"
description: "You cannot find a company by reading what is hot; Scale came from noticing that two of three ingredients were a button click away."
tags: [strategy, first-principles, market-discovery]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The instance

Training a model at MIT required three things: a cloud account for compute, code to run, and a
dataset. For two of the three you could press a button online. For data there was no effective
way. Wang says it therefore felt incredibly obvious that there would be a way to press a button
and get data.[^ss26-wang]

The interviewer's framing, which Wang accepts, is that this is why you cannot start a company by
opening a newspaper and noticing that data is hot — you could not have started Scale that way.
You start from simple statements about the world you know to be true and build for those.

# The confirming irony

For years data remained unsexy. Wang reports that every fundraise met scepticism — is this a good
business, does it have longevity, is it durable — despite strong revenue, and his explanation is
that none of the investors had ever trained a model. Some of the same investors who passed later
wrote think pieces about data being one of the biggest business opportunities in AI.[^ss26-wang]

# The same move by others

[Jensen Huang](/sources/jensen-huang.md) reads AlexNet by asking what the *algorithm* is and what
else it can do, arriving at the universal-function-approximator framing rather than at image
classification.[^ss26-huang] [Jeff Dean](/sources/jeff-dean.md)'s advice is the method in general
form: do not anchor on how the problem is solved today, ask how you would solve it from first
principles, and you get ideas others are not considering.[^ss26-dean]

# See also

- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md)
- [/concepts/find-the-steepest-longest-exponential.md](/concepts/find-the-steepest-longest-exponential.md)
- [/concepts/napkin-math.md](/concepts/napkin-math.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
