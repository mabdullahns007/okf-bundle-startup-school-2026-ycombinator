---
type: Concept
title: "The library and the librarian"
description: "A million-token window is a thousand pages; a life is a library. What decides which pages are open is the actual product."
tags: [context-engineering, memory, retrieval, personal-agi]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The two numbers

Garry Tan's framing rests on a comparison. A human holds about seven things in working memory —
seven plus or minus two, the reason local phone numbers were seven digits and the reason you
forget the eighth item on a grocery list. Every institution humanity has built, he argues — every
checklist, org chart, filing cabinet and stand-up meeting — is a prosthetic for that limit.[^ss26-tan]

An agent holds a million tokens: about a thousand pages, which he likens to three books open at
once, with the ability to find anything in any of them and synthesise across all three in seconds.
He grants this is not quite AGI and insists it is already a different operating regime — and that
almost everyone is still running their life on structures designed for the seven-item brain.

# Then he runs the number the other way

A thousand pages is also *very little*. Your life is not three books; it is a library — every email
you ever sent, every meeting, every decision and the reasons behind it, every conversation with
everyone you know. So the question that decides whether your agent is a genius or a goldfish is
**what decides which three books are open on the desk.** That, he says, is what a brain is: the
library plus the librarian.

# The same problem elsewhere

[Chelsea Finn](/sources/chelsea-finn.md) hits the identical wall in robotics — ten seconds of
multi-camera video is half a million tokens — and solves it with tiered fidelity: video for
seconds, text summaries for hours. See
[/concepts/multi-timescale-robot-memory.md](/concepts/multi-timescale-robot-memory.md).
[Jeff Dean](/sources/jeff-dean.md)'s reason this matters at all is that context is *clearer* to a
model than training data, so what you put in it is high leverage. See
[/concepts/context-engineering.md](/concepts/context-engineering.md).

# See also

- [/concepts/knowledge-base-hygiene.md](/concepts/knowledge-base-hygiene.md)
- [/concepts/personal-context-as-a-compounding-asset.md](/concepts/personal-context-as-a-compounding-asset.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
