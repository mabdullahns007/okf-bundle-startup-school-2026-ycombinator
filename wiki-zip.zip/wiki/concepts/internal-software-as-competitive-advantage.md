---
type: Concept
title: "Internal software as competitive advantage"
description: "Nobody loves their ERP. Companies that grow up around software fitted to them get something purchasable software cannot give."
tags: [internal-software, operations, ai-native, strategy]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

# The argument

Asked why build rather than buy, Hodak's answer starts empirically: ERP systems exist, and he
does not know anyone who loves theirs or wants to spend more time in one. Against that he cites
cases where a company grew up around software fitted precisely to it — YC's own internal
software, which he thinks is a big part of why YC works; Facebook's heavy investment in internal
tools; and the large internal system running manufacturing and R&D processes at SpaceX and
Tesla. His claim: software fitted to one company is powerful in a way purchasable software is
not.[^ss26-hodak]

His concrete instance: they left a commercial applicant-tracking system because it forced a
small group to be the bottleneck at the top of the hiring funnel, and replacing it let them
explore voting mechanisms that infer who would know about an applicant. See
[/concepts/distributed-hiring-funnel.md](/concepts/distributed-hiring-funnel.md).

# Why this changed recently

Hodak is explicit that this was historically the wrong call — software was so expensive you
bought it, which he calls a worse world — and that agents changed the economics. He is equally
candid that it remains contrarian: telling your board after a Series A that you will vibe-code a
purchasing system would normally draw questions, and he only avoided them because he controls
the company.[^ss26-hodak]

# Convergent cases

[Blake Scholl](/sources/blake-scholl.md) makes the same argument from Amazon: personalisation,
recommendations and warehouse/delivery back-ends were all in-house, and software fitting the
business like a glove is part of why Amazon won e-commerce — but doing that in the early 2000s
required scale. What AI changes is that the cost of custom software fell, so more businesses can
have software that fits, and any user can become a tool builder rather than the builders and
users sitting in different companies that do not understand each other.[^ss26-scholl]

[Garry Tan](/sources/garry-tan.md) reports YC finance, media and event staff who never open a
terminal building their own tools — one compiling about a hundred Excel workbooks into a single
app.[^ss26-tan]

# See also

- [/concepts/ai-native-company-context.md](/concepts/ai-native-company-context.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
