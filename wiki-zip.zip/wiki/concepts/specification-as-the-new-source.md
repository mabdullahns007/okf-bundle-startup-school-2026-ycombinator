---
type: Concept
title: "Specification as the new source code"
description: "Managing many agents is writing crisp design docs; the clearest specification is an existing implementation plus its tests."
tags: [agents, specification, engineering, design-docs]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

# The claim

Jeff Dean's point is that specification became *more* important rather than less. Under-specify
and the agent must infer what you meant, often inferring something different from what you
imagined. Computer scientists were always told to specify before writing; now agents do the
writing, and the specification step is what remains — and the thing you hand off to is less able
to ask clarifying questions than a smart human colleague.[^ss26-dean]

# The proof case

His illustration of a *perfect* specification is translating software between languages: you
have the whole implementation saying what the system does, plus tests. Models are consequently
very good at it — take the Python tests, make them pass in Go, translate the tests, compare
behavioural differences until none remain.[^ss26-dean] This is exactly the shape of
[/case-studies/bun-zig-to-rust-rewrite.md](/case-studies/bun-zig-to-rust-rewrite.md).

# Reconciling with "don't over-specify"

[Boris Cherny](/sources/boris-cherny.md)'s advice sounds contradictory but is not: specify the
*task*, the guardrails, the exit criteria and the verifier — not the procedure. See
[/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md).

# See also

- [/concepts/taste-as-the-scarce-skill.md](/concepts/taste-as-the-scarce-skill.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
