---
type: Concept
title: "Nobody is good at starting a company when they start one"
description: "Wang's flattening observation: everyone starts bad at everything, so the whole game is the rate of improvement."
tags: [founder-psychology, learning, leadership]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# The claim

Wang's answer to how he got good at the mechanics of company-building — convincing investors,
customers and recruits — is that you might have some predisposition, but nobody is good at starting
a company when they start one. He notes investors he met early would later say he grew and changed
so quickly that they had not seen it at the time, and he takes that as true of essentially
everyone: nobody is good at something they have never done before, so the whole game is developing
yourself to improve continuously and learn quickly.[^ss26-wang]

# The corroborating accounts

- [Max Junestrand](/sources/max-junestrand.md): the amount you learn is a function of the discomfort
  you are willing to endure. He was introverted, wanted to code as much as possible, was
  uncomfortable talking to customers, and found separating from an employee for the first time
  genuinely hard — while arguing startups are one of the places you can learn most in a short time.
  See [/concepts/mini-games-and-requalifying.md](/concepts/mini-games-and-requalifying.md).
- [Blake Scholl](/sources/blake-scholl.md): the self-belief came *late*, and there are still days he
  wonders whether he can pull it off. Nobody taps you on the shoulder to tell you that out of
  billions of people you are the one who will do the incredible thing — that conversation never
  happens and nobody gives you permission. His method was to stop worrying about whether he *could*
  and put all his mental energy on *how*.[^ss26-scholl]

# The consequence for how to choose

If competence is acquired on the way rather than possessed at the start, resume-fit is a weak
selection criterion — which is why several speakers converge on
[/concepts/work-on-what-you-love-not-what-you-know.md](/concepts/work-on-what-you-love-not-what-you-know.md)
and [/concepts/hire-for-slope-not-intercept.md](/concepts/hire-for-slope-not-intercept.md).

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
