---
type: Concept
title: "The product manifesto"
description: "One simple document condensing everything learned, shared with a 25-person team, written to end feature sprawl."
tags: [product, focus, culture, decision-making]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

# The problem it solved

In Legora's earliest days product decisions were made by *democratic vote across the entire team*.
Junestrand's assessment is blunt: anyone who has built software knows too many chefs in the kitchen
does not make a good dish, and that was exactly what was happening — they were working on too many
features, and had to rebuild everything for the post-freeze launch.[^ss26-junestrand]

# What it was

In October 2024 they wrote what they called the product manifesto: everything they had learned
gathered into one very simple document, shared with the entire then-25-person team, that they could
rally around.

# The context that makes it notable

At the time they were at roughly $1.3M ARR while several competitors were at ten times that — with
products that had only *one* of Legora's features. He connects the refocus directly to two
outcomes: out-competing rivals on product, and building enough momentum to justify moving to the US
and competing for the largest logos.

The platform requirement embedded in it: build something adaptable to constantly changing
foundations — both the underlying models and the agent frameworks being used.

# The related structural constraint

He notes a Swedish home market is not big enough to house a unicorn, which is why "when will you
move to the United States" was among YC's earliest questions to them.

# See also

- [/concepts/deliberate-sales-freeze.md](/concepts/deliberate-sales-freeze.md)
- [/concepts/build-one-step-ahead-of-the-models.md](/concepts/build-one-step-ahead-of-the-models.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
