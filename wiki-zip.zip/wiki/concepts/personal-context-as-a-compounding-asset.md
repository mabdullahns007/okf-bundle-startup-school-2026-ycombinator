---
type: Concept
title: "Personal context as a compounding asset"
description: "Your unindexed inbox is the moat: five or ten years of history no model on earth has, sitting there doing nothing."
tags: [personal-agi, context-engineering, compounding, ownership]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

# The argument

Tan's step two is deliberately small: not a grand archive, but one folder of markdown files.
Export your notes and your email if you can. Write one page per project and one page per person
you work with, containing what you actually know — what you are building together, what they care
about, what you owe them, what they said last time. His point about that material: no model on
earth has it, because it only exists in your head, and your head holds seven things.[^ss26-tan]

His claim about the threshold: the first time an agent answers a question using your context
instead of the internet's, you feel the click and do not go back. And his claim about the cost:
everyone is sitting on five or ten years of their own history in one inbox or another, which is
a moat lying there unindexed, doing nothing — with maybe 24 hours between you and the whole
architecture.

Nobody builds the warehouse first. His own 220,000-page library started as a few markdown files
about the companies he was working with and the people he kept emailing, and got big the way
anything gets big: a little every day, with agents doing the filing.

# The structural version

[Jeff Dean](/sources/jeff-dean.md) names the same asset from the outside: one of the two durable
advantages a small team has over a general model is access to data the model cannot see, and his
example is organising *your* personal information rather than the world's.[^ss26-dean] See
[/concepts/the-one-percent-rule.md](/concepts/the-one-percent-rule.md).

# The tension worth holding

[/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md) argues
for deleting your accumulated instructions every six months. The reconciliation: delete
*corrective scaffolding*, which decays as models improve; keep *facts*, which do not.

# See also

- [/concepts/knowledge-base-hygiene.md](/concepts/knowledge-base-hygiene.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
