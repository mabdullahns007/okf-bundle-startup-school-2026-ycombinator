---
type: Concept
title: "Ask what happens if you succeed"
description: "Founders stress-test failure; Collison argues you should stress-test success, ideally before raising serious money."
tags: [founder-psychology, company-building, motivation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

# The question

Collison observes that founders naturally worry about the possibility of failure and how to
mitigate and avoid it. He thinks you need to ask the converse: **what if you succeed?** You raise
money, you have customers and employees and a whole thing — are you going to enjoy that? Do you
want to work on it for ten years, seventeen years, thirty years? He notes Larry Ellison will soon
be at roughly half a century at Oracle.[^ss26-collison]

His view on timing: you may not need to think about it much up front, but you should ask it before
raising a significant amount of money.

# His own answer

He says he feels extremely lucky with Stripe, because every business is a kind of applied theory
about how some aspect of the world works, or how some market works — and a new company with a new
model is a contrarian thesis on some counterfactual. His line: he has never met a Stripe customer
and thought that was boring. Which makes the company as a whole the *opposite* of the schlep it
appears to be from outside. See [/concepts/schlep-blindness.md](/concepts/schlep-blindness.md).

# The failure mode this prevents

[Blake Scholl](/sources/blake-scholl.md) names it precisely: the worst thing you can do is start a
company you do not love and then get stuck. He says he knows successful founders running successful
companies they do not love, who feel a debt of responsibility to employees and investors — and since
it is very hard to replace a founder CEO, they are trapped. He calls it a champagne problem that is
actually pretty bad, and concludes: start a company, but only if it is a company you want to
keep.[^ss26-scholl]

# See also

- [/concepts/work-on-what-you-love-not-what-you-know.md](/concepts/work-on-what-you-love-not-what-you-know.md)

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
