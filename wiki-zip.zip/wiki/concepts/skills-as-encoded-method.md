---
type: Concept
title: "Skills as encoded method"
description: "A skill is your own working procedure written down so an agent can execute it — including procedures you would struggle to teach a person quickly."
tags: [agents, skills, context-engineering, performance]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

# Dean's example

Jeff Dean and Sanjay Ghemawat do low-level performance work on libraries used by millions of
processes. The manual loop is: measure a microbenchmark, make a change, re-measure, widen the
benchmark set, measure cache footprint, iterate. They wrote a skill teaching a model to do most
of that in sequence, so it could run the loop self-improvingly — and it worked well for some
classes of problem. His framing of what a skill *is*: giving the model the approach you would
use as a person, in a form it can use.[^ss26-dean]

He adds a second instance: a roughly 30-page internal "performance hints" document he and
Ghemawat wrote, which people have summarised into model context to make models better at
reasoning about performance in code. Google's internal agents likewise carry skills for
internal tooling — code review, log fetching, performance measurement — that no base model was
trained on.[^ss26-dean]

# Why this is the leverage point

Skills also keep a model on the brightly lit path of things it does know how to do, which is
Dean's main remedy for long-horizon derailment. See
[/concepts/why-agents-derail.md](/concepts/why-agents-derail.md).

[Garry Tan](/sources/garry-tan.md) pushes the same primitive further into org design in
[/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md), and
[Alexandr Wang](/sources/alexandr-wang.md) confirms that mechanically the frontier is
unglamorous: skills, markdown files and cron jobs.[^ss26-wang]

# See also

- [/concepts/own-your-skill-files.md](/concepts/own-your-skill-files.md)
- [/concepts/context-engineering.md](/concepts/context-engineering.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
