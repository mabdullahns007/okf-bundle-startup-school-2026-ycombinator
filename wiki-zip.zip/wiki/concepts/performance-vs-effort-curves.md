---
type: Concept
title: "Required nines dictate architecture"
description: "The technology with the fastest early ramp often plateaus below what your product needs; pick for the plateau, not the slope."
tags: [architecture, reliability, physical-ai, technology-choice]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

# The failure mode

Every technology has a performance-versus-effort curve that starts steep and flattens. Dolgov's
named failure: pick the tech with the fastest early ramp, ride the steep part, feel like you are
winning, extrapolate the slope forward — then hit the plateau and discover it sits below the
performance your product requires.[^ss26-dolgov]

He allows that you may deliberately choose the steep curve for a while, to prototype, to demo or
to learn. The discipline is being honest with yourself about which of those you are doing.

# The worked example

Sensing. Humans drive with eyes, so vision alone has an existence proof, and for approximate
human parity or an assist product Dolgov calls it a very reasonable approach. But if the target
is full autonomy at strongly superhuman safety, weak sensing yields a safety curve that flattens
far too early — which is why Waymo fuses cameras, lidar and radar. See
[/concepts/sensing-redundancy.md](/concepts/sensing-redundancy.md).

The same logic drives the choice of a high-capacity foundation model distilled down, rather than
optimising a small model directly: better scaling laws. See
[/concepts/fast-path-slow-path-architecture.md](/concepts/fast-path-slow-path-architecture.md).

# See also

- [/concepts/ladder-of-nines.md](/concepts/ladder-of-nines.md)
- [/concepts/structure-augmented-end-to-end.md](/concepts/structure-augmented-end-to-end.md)

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
