---
type: Concept
title: "Two cultures in a mission company"
description: "Roughly a third true believers in the overt mission, two thirds serious professionals who think they are crazy — and you need both."
tags: [culture, mission, org-design, deep-tech]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

# The observation

Hodak reports from time spent around the periphery of SpaceX roughly seven or eight years before
the talk that perhaps **20% of the company were what you might call committed Martian colonists
and 80% were serious engineers** who think those people are lunatics and simply want to work on
the highest-performance methalox engines in the world. His claim: you need *both* cultures to be
successful long-term.[^ss26-hodak]

At Science he puts the split at roughly **30% overtly transhumanist mission and 70% serious
clinicians, scientists and researchers** who think the first group is crazy but are going to build
valuable medical devices for critical unmet needs in the process.

He notes this is especially tricky in medicine, which he characterises as a very conservative and
arguably very authoritarian culture.

# Why it matters

His claim about what makes the company work: it holds both cultures and integrates them, which is
what lets it simultaneously do research he describes as at the edge of the Overton window *and* run
clinical trials in six countries with an approved device in Europe and results in the New England
Journal of Medicine.

The general lesson he draws: you have to be able to navigate both of those things to really reshape
the future — the visionary culture alone does not ship a regulated product, and the professional
culture alone does not attempt something worth reshaping.

# The related structure

[/concepts/two-cultures-in-a-mission-company.md](/concepts/two-cultures-in-a-mission-company.md) is
the cultural analogue of [/concepts/scenes-as-the-source-of-startups.md](/concepts/scenes-as-the-source-of-startups.md):
the mission attracts the scene, and the scene alone cannot staff the company.

# See also

- [/concepts/culture-against-local-norms.md](/concepts/culture-against-local-norms.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
