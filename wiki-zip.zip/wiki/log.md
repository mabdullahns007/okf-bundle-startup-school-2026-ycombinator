# Bundle Update Log

## 2026-09-05

* **Initialization**: Created the Startup School 2026 OKF bundle. Reviewed the OKF v0.2 sources
  (spec, README, and the two Google Cloud blog posts listed in `okf-links-to-review.txt`) and the
  [LLM wiki pattern](../karpathy-llm-wiki.md), then instantiated a bundle at `okf_version: "0.2"`.
* **Ingest**: Fetched auto-generated English captions for all 15 videos in YouTube playlist
  `PLEb7ftOB0yf0` (~131,000 words / ~11.5 hours of talks). Transcripts were processed in a scratch
  directory and **not** committed; `raw/` holds one immutable metadata record per source plus a
  playlist record. See [/sources/index.md](/sources/index.md#transcription-caveats) for the ASR
  normalisation table.
* **Creation**: [Sources](/sources/index.md) - 15 talk hub pages, one per video.
* **Creation**: [Concepts](/concepts/index.md) - 113 concept pages across 10 themes. Multi-source
  pages were preferred wherever speakers converged, since cross-talk synthesis is the point of the
  pattern; the most heavily cross-cited are
  [conviction against consensus](/concepts/conviction-against-consensus.md) (5 sources),
  [evals as the durable asset](/concepts/evals-as-the-durable-asset.md) (4),
  [personal AGI](/concepts/personal-agi.md) (4) and
  [iteration velocity](/concepts/iteration-velocity-as-the-master-variable.md) (4).
* **Creation**: [Case studies](/case-studies/index.md) - 10 worked examples, separated from the
  concept pages so the concrete figures stay auditable.
* **Creation**: [People](/people/index.md) - 15 speakers plus
  [Paul Graham](/people/paul-graham.md), referenced by four speakers but not present.
* **Creation**: [Organizations](/organizations/index.md) - 15 companies and institutions.
* **Contradictions logged**: Three internal inconsistencies and one apparent factual slip were
  preserved rather than smoothed - Legora's headcount, the NVIDIA/Sega contract figures, Waymo's
  weekly trip count, and Kratsios's date for the ChatGPT release. All are cross-referenced from
  [/sources/index.md](/sources/index.md#transcription-caveats).
* **Disagreements recorded**: Where speakers genuinely conflict, both positions are kept on the
  concept page rather than resolved - notably
  [lean startup in the AI era](/concepts/lean-startup-in-the-ai-era.md) (Collison vs Scholl),
  [concentration of power](/concepts/concentration-of-power.md) (Altman vs Collison),
  [ablation-driven harness design](/concepts/ablation-driven-harness-design.md) vs
  [personal context as a compounding asset](/concepts/personal-context-as-a-compounding-asset.md)
  (Cherny vs Tan), and
  [willingness to learn over domain expertise](/concepts/willingness-to-learn-over-domain-expertise.md)
  (Junestrand/Huang/Scholl vs Hodak on judgment as an oral tradition).
* **Status**: All 154 content pages are `status: draft`. None carry a `verified` entry yet, so the
  whole bundle is at the *unverified* trust tier under OKF §5.2.

## Suggested next actions

* **Human review**: Flip pages to `status: stable` with a `verified: [{by: human:<id>, at: ...}]`
  entry as they are checked. The pages most worth reviewing first are the ones carrying numbers:
  the 10 case studies and [/concepts/business-formation-data-2026.md](/concepts/business-formation-data-2026.md).
* **Gaps worth filling with a web search**: the actual names of the models referenced obliquely in
  the Kratsios and Wang talks; confirmation of Legora's current headcount and ARR; the published
  Waymo safety report behind the 17x figure; and the title/URL of the OSTP report *Science and the
  New Golden Age*.
* **Concepts mentioned but not yet paged**: quantum information science as a policy priority;
  focused research organisations (FROs) as a new actor in the science ecosystem; packaging /
  tropicalization as an open materials-science problem in implants; the "born free" internet as a
  historical case.
* **Next ingest**: if the 2025 edition of this event is available, Chelsea Finn refers to speaking
  at it, which would let the robotics pages carry a year-over-year comparison rather than a
  snapshot.
