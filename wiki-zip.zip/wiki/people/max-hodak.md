---
type: Person
title: "Max Hodak"
description: "Co-founder and CEO of Science Corp; previously Neuralink. Spoke on infrastructure as the determinant of speed."
tags: [bci, deep-tech, infrastructure, hiring]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

Co-founder and CEO of [Science Corp](/organizations/science-corp.md). Spent five years running a
company for his CEO at Neuralink; four of his five Science co-founders came from Neuralink. Began as
an undergraduate in a Duke lab working on brain–computer interfaces roughly twenty years before the
talk. Has no PhD.

# What he contributes to this wiki

The playlist's deepest treatment of company operations as an engineering problem:

- [/concepts/iteration-velocity-as-the-master-variable.md](/concepts/iteration-velocity-as-the-master-variable.md)
  — his stated theme.
- [/concepts/procurement-and-budgeting-as-infrastructure.md](/concepts/procurement-and-budgeting-as-infrastructure.md)
  and [/concepts/cost-attribution-in-physical-r-and-d.md](/concepts/cost-attribution-in-physical-r-and-d.md).
- [/concepts/distributed-hiring-funnel.md](/concepts/distributed-hiring-funnel.md) with real
  conversion rates, and
  [/case-studies/eigen-reviews-at-science.md](/case-studies/eigen-reviews-at-science.md).
- [/concepts/judgment-cannot-be-delegated.md](/concepts/judgment-cannot-be-delegated.md) and
  [/concepts/action-produces-information.md](/concepts/action-produces-information.md).
- [/concepts/internal-software-as-competitive-advantage.md](/concepts/internal-software-as-competitive-advantage.md)
  and [/concepts/ai-native-company-context.md](/concepts/ai-native-company-context.md).
- [/concepts/scenes-as-the-source-of-startups.md](/concepts/scenes-as-the-source-of-startups.md)
  and [/concepts/two-cultures-in-a-mission-company.md](/concepts/two-cultures-in-a-mission-company.md).

# His position on BCIs

He argues neural engineering is much broader than motor decoding, and that in the near term BCI is
really a **longevity and healthcare story** rather than an AI-adjacent one — because direct brain
interfaces produce effect sizes medicine rarely sees without first solving biology problems beyond
humanity's current capability. His examples: a deep brain stimulator turning on and a patient going
from being unable to hold a cup of water to writing cursive in seconds, and a newborn's cochlear
implant being switched on. His framing of why it matters: the brain is the only organ that in
principle cannot be transplanted, and it is usually not the thing that fails.

On the far end, asked whether BCIs could resolve consciousness, he treats it as a practical rather
than philosophical problem: the brain is ordinary matter obeying chemistry, so the task is finding
the mapping between substrate activity and phenomenal content.

He is also candid about the sector: biotech remains capital-intensive and he would not necessarily
recommend it if you have other options, because starting a company in this space means committing a
decade of your life you will not get back regardless of outcome.

# Source

- [/sources/max-hodak.md](/sources/max-hodak.md)

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
