---
type: Person
title: "Patrick Collison"
description: "Co-founder and CEO of Stripe; spoke on the cognitive-cache argument and what Stripe's data shows."
tags: [stripe, fintech, data, founders]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
---

Co-founder and CEO of [Stripe](/organizations/stripe.md). Dropped out of MIT twice — once for an
earlier company with his Startup School interviewer Harj Taggar, once for Stripe. Grew up in
Ireland; wrote a Lisp dialect as a teenager.

# What he contributes to this wiki

- [/concepts/knowledge-as-cognitive-cache.md](/concepts/knowledge-as-cognitive-cache.md) — the
  memory-hierarchy argument for still learning things yourself.
- [/concepts/college-and-urgency.md](/concepts/college-and-urgency.md) — why the urgency he felt
  was unnecessary.
- [/concepts/private-beta-with-real-users.md](/concepts/private-beta-with-real-users.md) — Stripe's
  two-year pre-launch period with a production customer from month two.
- [/concepts/lean-startup-in-the-ai-era.md](/concepts/lean-startup-in-the-ai-era.md) — his
  suggestion that the doctrine's niches are now more aggressively tilled.
- [/concepts/business-formation-data-2026.md](/concepts/business-formation-data-2026.md) — the only
  aggregate measured evidence in the playlist.
- [/concepts/will-the-labs-eat-my-startup.md](/concepts/will-the-labs-eat-my-startup.md) and
  [/concepts/concentration-of-power.md](/concepts/concentration-of-power.md), where he dissents from
  the centralisation thesis.
- [/concepts/what-if-you-succeed.md](/concepts/what-if-you-succeed.md) and
  [/concepts/schlep-blindness.md](/concepts/schlep-blindness.md).

# On the founding of Stripe

He and his brother John attended Startup School in Berkeley in 2009, got sushi in Potrero
afterwards, and decided to start Stripe walking back — he says he remembers exactly where in the
road they were, and what they said: they might as well, because it probably would not be that hard.
That was almost seventeen years before this talk. He offers it as a caution about yak shaves.

# Source

- [/sources/patrick-collison.md](/sources/patrick-collison.md)

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
