---
type: Person
title: "Peter Steinberger"
description: "Creator of OpenClaw; spoke candidly on viral open-source success, burnout and fun as velocity."
tags: [open-source, agents, burnout, personal-brand]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

Creator of [OpenClaw](/organizations/openclaw.md). Previously spent his twenties and thirties
bootstrapping a B2B software company around a PDF framework he wrote by hand, grew it to nearly 80
people, then sold his shares and burned out badly — followed by roughly three years of recovery
during which he sometimes did not open a computer for months. Now also works at a frontier lab.

# What he contributes to this wiki

The most candid account in the playlist of what a viral open-source success actually costs:

- [/concepts/fun-is-velocity.md](/concepts/fun-is-velocity.md) — his talk's title claim.
- [/concepts/emotional-reaction-as-pmf-signal.md](/concepts/emotional-reaction-as-pmf-signal.md).
- [/concepts/configuration-sprawl.md](/concepts/configuration-sprawl.md) — ~9,500 config options.
- [/concepts/dependency-business-model-risk.md](/concepts/dependency-business-model-risk.md) — the
  sharpest single lesson in his talk.
- [/concepts/personal-brand-as-the-uncloneable-asset.md](/concepts/personal-brand-as-the-uncloneable-asset.md).
- [/concepts/code-review-as-risk-management.md](/concepts/code-review-as-risk-management.md).

# His stated method

His source of inspiration is *being annoyed* — a phrase he repeats three times in the talk. These
days what annoys him is having to use software he cannot change by sending a prompt to an agent.

# On the cost

Worth recording plainly, because few speakers say it: press calls in the middle of the night
exploiting the iPhone's repeated-call emergency bypass; his phone number leaked; being called both a
messiah and an antichrist; stopping answering friends; not wanting to look at his phone. He says he
came close to deleting the whole thing. His summary: be careful what you wish for.

His stated regret about the security-report period is specific and useful: he should have clearly
defined what was and was not inside the project's security boundary, and he notes many reports were
agent-generated without testing and aimed at credit rather than helping.

# Source

- [/sources/peter-steinberger.md](/sources/peter-steinberger.md)

[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
