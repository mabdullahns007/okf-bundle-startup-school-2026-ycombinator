---
type: Person
title: "Sam Altman"
description: "Co-founder and CEO of OpenAI; YC's first batch in 2005 and later its president."
tags: [openai, yc, agi, ai-safety]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

Co-founder and CEO of [OpenAI](/organizations/openai.md). Was in
[Y Combinator](/organizations/y-combinator.md)'s first batch in 2005 with a location-sharing
company, Loopt, and later ran YC. Closed Startup School 2026.

# What he contributes to this wiki

- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md) — his
  highest-order advice, and the "45 of 50" joke.
- [/concepts/concentration-of-power.md](/concepts/concentration-of-power.md) and
  [/concepts/loss-of-control-incidents.md](/concepts/loss-of-control-incidents.md) — the safety and
  political core of his session.
- [/concepts/rising-ambition-ceiling.md](/concepts/rising-ambition-ceiling.md), with his own
  discipline attached: you can do three months of work in seventeen minutes, and then you had
  better go do three months of work.
- [/concepts/loose-network-compounding.md](/concepts/loose-network-compounding.md) — the eight-year
  gap between driving to Palo Alto for Stripe and founding OpenAI with Greg Brockman.
- Inference demand growth and token statistics; see [/sources/sam-altman.md](/sources/sam-altman.md).
- A pointed critique of sarcastic dunking online, which he calls morally bankrupt and corrosive to
  the person doing it.

# On Paul Graham

His account of [Paul Graham](/people/paul-graham.md) as a *flight instructor* rather than a
lecturer is the clearest articulation of that idea in the collection, along with the weekly dinners
PG cooked for the first batch.

# Source

- [/sources/sam-altman.md](/sources/sam-altman.md)

[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
