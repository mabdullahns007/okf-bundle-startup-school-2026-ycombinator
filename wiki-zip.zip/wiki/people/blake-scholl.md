---
type: Person
title: "Blake Scholl"
description: "Founder and CEO of Boom Supersonic; broke the sound barrier with a 50-person team."
tags: [aerospace, hardware, regulation, founders]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
---

Founder and CEO of [Boom Supersonic](/organizations/boom-supersonic.md), started in 2014 when he was
33. Previously a software engineer, early at Amazon from 2001, and founder of an apps company
acquired by Groupon. His aviation knowledge at the outset was a private pilot's licence — he could
fly a Cessna. Started an internet service provider in his parents' basement in high school, mainly
to get a better internet connection.

# What he contributes to this wiki

- [/case-studies/xb1-mach-cutoff.md](/case-studies/xb1-mach-cutoff.md) — the flight and the
  regulatory cascade.
- [/concepts/engineering-tools-as-product.md](/concepts/engineering-tools-as-product.md) and
  [/concepts/vertical-integration-for-iteration-speed.md](/concepts/vertical-integration-for-iteration-speed.md).
- [/concepts/why-now-is-because-i-started.md](/concepts/why-now-is-because-i-started.md) — his named
  false belief.
- [/concepts/regulatory-strategy-for-startups.md](/concepts/regulatory-strategy-for-startups.md).
- [/concepts/work-on-what-you-love-not-what-you-know.md](/concepts/work-on-what-you-love-not-what-you-know.md)
  — his mother's well-meaning advice, which he names as the worst he received.
- [/concepts/optimize-for-the-worst-day-and-the-best-day.md](/concepts/optimize-for-the-worst-day-and-the-best-day.md)
  — seven days of cash and a board telling him to shut down.
- [/concepts/hiring-for-evidence-of-exceptional-ability.md](/concepts/hiring-for-evidence-of-exceptional-ability.md)
  and [/concepts/hire-for-slope-not-intercept.md](/concepts/hire-for-slope-not-intercept.md).
- The **confusion list** method for teaching yourself hard things: distinguish knowing enough to
  pass a test from real understanding, and keep a list of things you cannot actually explain.

# On Amazon and Bezos

He credits Amazon with combining very long-range thinking — seven-year business plans, and taking
long-term cash-flow decisions rather than massaging a quarter — with strong day-to-day operating
discipline, and says doing both together is rare and is what great companies are made of. He also
notes Bezos passed on Boom's 2015 seed round.

# Source

- [/sources/blake-scholl.md](/sources/blake-scholl.md)

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
