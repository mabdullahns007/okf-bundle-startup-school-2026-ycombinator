---
type: Person
title: "Boris Cherny"
description: "Creator of Claude Code at Anthropic; spoke on harness design, product overhang and multi-day agent runs."
tags: [anthropic, agents, harness-design, coding]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
---

Creator of Claude Code at [Anthropic](/organizations/anthropic.md). Spoke at Startup School 2026 the
day after an Opus 5 release.

# What he contributes to this wiki

The most operationally specific talk in the playlist on building on frontier models:

- [/concepts/product-overhang-and-unhobbling.md](/concepts/product-overhang-and-unhobbling.md) —
  his central framing, and the origin story of Claude Code itself.
- [/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md) —
  deleting 80%+ of the system prompt each model generation.
- [/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md)
  — his most emphatic point, that verification is what people get wrong.
- [/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md)
  — dynamic workflows as an "algebra for agents," drawing on his functional-programming background.
- [/concepts/self-maintaining-codebases.md](/concepts/self-maintaining-codebases.md) — the ~20–30
  daily routines, including "abstraction police."
- [/case-studies/bun-zig-to-rust-rewrite.md](/case-studies/bun-zig-to-rust-rewrite.md) and
  [/case-studies/electron-to-swift-two-week-run.md](/case-studies/electron-to-swift-two-week-run.md).

# Biographical details mentioned

Learned to program on a TI-83 calculator in middle school, in BASIC, in order to do better on maths
tests — and wrote an internet guide to programming them, which he says is still online. Later
learned assembly to write a better solver when the maths reached calculus. His advice follows from
this: learn computer science *applied*.

# Source

- [/sources/boris-cherny.md](/sources/boris-cherny.md)

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
