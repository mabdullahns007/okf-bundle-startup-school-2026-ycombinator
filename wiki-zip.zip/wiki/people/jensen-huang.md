---
type: Person
title: "Jensen Huang"
description: "Founder and CEO of NVIDIA; spoke at Startup School 2026 on learning your way out of a wrong founding bet."
tags: [nvidia, hardware, founders, ceo]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

Founder and CEO of [NVIDIA](/organizations/nvidia.md), which he co-founded in 1993 and has led for
34 years. Opened Startup School 2026 in conversation with [Garry Tan](/people/garry-tan.md).

# What he contributes to this wiki

- That NVIDIA's founding algorithm was **wrong**, and that neither he nor his engineers knew the
  right approach — so he bought textbooks. See
  [/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md)
  and [/case-studies/sega-dreamcast-contract.md](/case-studies/sega-dreamcast-contract.md).
- The strategic frame of [/concepts/accelerating-algorithm-domains.md](/concepts/accelerating-algorithm-domains.md),
  and the reading of AlexNet as a universal function approximator ~15 years ago.
- [/concepts/fit-the-company-to-the-founder.md](/concepts/fit-the-company-to-the-founder.md) — the
  F1 car built for its driver, and curiosity as a personality rather than management technique.
- [/concepts/controllability-as-the-agent-frontier.md](/concepts/controllability-as-the-agent-frontier.md),
  his candidate for the single biggest missing agent capability.
- [/concepts/tasks-are-automated-jobs-grow.md](/concepts/tasks-are-automated-jobs-grow.md), with
  the employment figures he cites.
- [/concepts/how-hard-can-it-be.md](/concepts/how-hard-can-it-be.md), his stated posture toward
  anything unlearned.
- Strong open-source advocacy, including offering NVIDIA engineers to
  [OpenClaw](/organizations/openclaw.md), and his first post on X in 2026. See
  [/concepts/open-weights-policy.md](/concepts/open-weights-policy.md).

# Biographical details mentioned

Grew up in the era of game consoles, which shaped NVIDIA's founding idea of turning every PC into
one. Says he read Steve Jobs keynotes and had no formal engineering training in the field he then
led. Bought a 500-page book on how to start a company and decided not to read it. Describes himself
as introverted.

# Source

- [/sources/jensen-huang.md](/sources/jensen-huang.md)

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
