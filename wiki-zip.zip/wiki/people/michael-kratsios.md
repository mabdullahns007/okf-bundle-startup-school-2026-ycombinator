---
type: Person
title: "Michael Kratsios"
description: "Director of the White House OSTP; the playlist's account of how US AI and science policy is made."
tags: [policy, government, science-funding, regulation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

Director of the [White House Office of Science and Technology Policy](/organizations/white-house-ostp.md)
and, by his own account, an assistant to the president — one of roughly twenty holding that most
senior advisory rank. Previously US Chief Technology Officer in the first Trump term, where he led
early federal AI initiatives; between government roles he was COO of Scale AI. Before that he spent
almost seven years working for Peter Thiel, from 2010 to 2017.

# What he contributes to this wiki

- [/concepts/how-federated-tech-policy-works.md](/concepts/how-federated-tech-policy-works.md).
- [/concepts/open-weights-policy.md](/concepts/open-weights-policy.md) — the stated administration
  position.
- [/concepts/regulating-a-moving-frontier.md](/concepts/regulating-a-moving-frontier.md) and
  [/concepts/born-free-vs-born-in-captivity.md](/concepts/born-free-vs-born-in-captivity.md).
- [/concepts/preemption-and-little-tech.md](/concepts/preemption-and-little-tech.md).
- [/concepts/shape-the-arena-not-the-discovery.md](/concepts/shape-the-arena-not-the-discovery.md)
  and [/concepts/autonomous-cloud-labs.md](/concepts/autonomous-cloud-labs.md).
- [/concepts/ai-and-intellectual-property.md](/concepts/ai-and-intellectual-property.md).

# What formed his interest in regulation

Working with Thiel's portfolio between 2010 and 2017, he says the question that kept recurring
across every industry was regulation — Lyft at state and local level, SpaceX with launch permits —
and that government policy could *unlock* technologies. His first instinct on joining the
administration was therefore to look across existing rules and ask how to make it easier to build.

# ⚠️ Note

He is a serving government official speaking at a private event. Positions recorded in this wiki are
as he stated them, not as independently verified fact. One apparent factual slip is flagged in
[/concepts/regulating-a-moving-frontier.md](/concepts/regulating-a-moving-frontier.md).

# Source

- [/sources/michael-kratsios.md](/sources/michael-kratsios.md)

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
