---
type: Person
title: "Alexandr Wang"
description: "Founded Scale AI at 19; now leads Meta's frontier AI lab. Spoke on conviction, talent density and diffusion."
tags: [meta, scale-ai, frontier-labs, conviction]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
---

Founded Scale AI at 19 and now leads [Meta's frontier AI lab](/organizations/meta-superintelligence-labs.md)
as Chief AI Officer. Grew up in Los Alamos, New Mexico; competed in maths and computer-science
competitions; took a gap year at Quora before one year at MIT, then went through YC.

# What he contributes to this wiki

- [/concepts/first-principles-market-discovery.md](/concepts/first-principles-market-discovery.md)
  — the three-ingredients observation that produced Scale.
- [/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md) and
  [/concepts/founder-rate-of-improvement.md](/concepts/founder-rate-of-improvement.md).
- [/concepts/diffusion-is-the-bottleneck.md](/concepts/diffusion-is-the-bottleneck.md) — the source
  of his talk's title claim.
- [/concepts/talent-density-compounds.md](/concepts/talent-density-compounds.md) — his stated core
  bet in rebuilding the lab.
- [/concepts/ten-x-waves.md](/concepts/ten-x-waves.md) and
  [/concepts/find-the-steepest-longest-exponential.md](/concepts/find-the-steepest-longest-exponential.md).
- [/concepts/agentic-feedback-loops.md](/concepts/agentic-feedback-loops.md) — where he says the
  alpha currently is.
- [/concepts/vision-and-ambition-as-scarce-inputs.md](/concepts/vision-and-ambition-as-scarce-inputs.md).
- [/concepts/personal-agi.md](/concepts/personal-agi.md), which he links explicitly to Meta's
  personal-superintelligence framing.

# On YC

He describes the first Scale idea as an AI agent for helping people get medical care — an idea he now
thinks will exist but was badly mistimed — and credits YC partner Jared Friedman with telling them
after a month or two that it was not going anywhere, which he says was exactly what they needed.
His characterisation of YC: supportive and genuinely wanting you to succeed, while also telling you
when you are being a dumbass.

# Source

- [/sources/alexandr-wang.md](/sources/alexandr-wang.md)

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
