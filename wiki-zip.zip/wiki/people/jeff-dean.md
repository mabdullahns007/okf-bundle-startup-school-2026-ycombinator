---
type: Person
title: "Jeff Dean"
description: "Chief Scientist at Google DeepMind; spoke on napkin math, energy, context engineering and taste."
tags: [google, systems, hardware, research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
---

Chief Scientist at [Google DeepMind](/organizations/google-deepmind.md). Joined Google in 1999 when
it was about 20 people. Known for MapReduce, BigTable, TensorFlow, the TPU and Gemini, and for the
widely circulated "latency numbers every engineer should know."

# What he contributes to this wiki

- [/concepts/napkin-math.md](/concepts/napkin-math.md) and
  [/case-studies/tpu-napkin-math.md](/case-studies/tpu-napkin-math.md).
- [/concepts/energy-and-data-movement.md](/concepts/energy-and-data-movement.md) — the ~1000x
  ratio, and his AI-era update to the latency numbers.
- [/concepts/context-engineering.md](/concepts/context-engineering.md),
  [/concepts/skills-as-encoded-method.md](/concepts/skills-as-encoded-method.md) and
  [/concepts/why-agents-derail.md](/concepts/why-agents-derail.md).
- [/concepts/the-one-percent-rule.md](/concepts/the-one-percent-rule.md) — the screening heuristic
  the talk is named for.
- [/concepts/specification-as-the-new-source.md](/concepts/specification-as-the-new-source.md) and
  [/concepts/taste-as-the-scarce-skill.md](/concepts/taste-as-the-scarce-skill.md).
- [/concepts/automated-experimentation-loops.md](/concepts/automated-experimentation-loops.md) and
  [/concepts/learned-surrogate-evaluators.md](/concepts/learned-surrogate-evaluators.md).
- [/case-studies/distillation-paper-rejection.md](/case-studies/distillation-paper-rejection.md).

# Frequent collaborator mentioned

Sanjay Ghemawat, in the RAM-index work, the MapReduce origin story, the microbenchmark skill and a
~30-page internal "performance hints" document.

# Open problems he names

More efficient inference hardware; radically more data-efficient learning algorithms (his
observation: frontier models see perhaps a thousand times more data than an 18-year-old, who is
still better at many things); continual learning; multi-agent interaction.

# Source

- [/sources/jeff-dean.md](/sources/jeff-dean.md)

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
