# People

The fifteen Startup School 2026 speakers, plus one frequently referenced absent figure.
Each page indexes what that person contributes to the wiki rather than restating a biography.

* [Alexandr Wang](alexandr-wang.md) - Founded Scale AI at 19; now leads Meta's frontier AI lab. Spoke on conviction, talent density and diffusion.
* [Blake Scholl](blake-scholl.md) - Founder and CEO of Boom Supersonic; broke the sound barrier with a 50-person team.
* [Boris Cherny](boris-cherny.md) - Creator of Claude Code at Anthropic; spoke on harness design, product overhang and multi-day agent runs.
* [Chelsea Finn](chelsea-finn.md) - Co-founder of Physical Intelligence; gave the playlist's state-of-the-art robotics talk.
* [Dmitri Dolgov](dmitri-dolgov.md) - Co-CEO of Waymo; gave the playlist's most structured technical talk on shipping physical AI.
* [Garry Tan](garry-tan.md) - President and CEO of Y Combinator; keynoted Startup School 2026 on personally owned AI infrastructure.
* [Jeff Dean](jeff-dean.md) - Chief Scientist at Google DeepMind; spoke on napkin math, energy, context engineering and taste.
* [Jensen Huang](jensen-huang.md) - Founder and CEO of NVIDIA; spoke at Startup School 2026 on learning your way out of a wrong founding bet.
* [Max Hodak](max-hodak.md) - Co-founder and CEO of Science Corp; previously Neuralink. Spoke on infrastructure as the determinant of speed.
* [Max Junestrand](max-junestrand.md) - Co-founder and CEO of Legora; the playlist's account of going from a YC rejection to $100M ARR.
* [Michael Kratsios](michael-kratsios.md) - Director of the White House OSTP; the playlist's account of how US AI and science policy is made.
* [Patrick Collison](patrick-collison.md) - Co-founder and CEO of Stripe; spoke on the cognitive-cache argument and what Stripe's data shows.
* [Paul Graham](paul-graham.md) - Y Combinator co-founder, referenced across the playlist as teacher, essayist and source of its vocabulary.
* [Peter Steinberger](peter-steinberger.md) - Creator of OpenClaw; spoke candidly on viral open-source success, burnout and fun as velocity.
* [Sam Altman](sam-altman.md) - Co-founder and CEO of OpenAI; YC's first batch in 2005 and later its president.
* [Susan Kare](susan-kare.md) - Iconographer and designer of the original Macintosh's system font and icons.
