---
type: Person
title: "Paul Graham"
description: "Y Combinator co-founder, referenced across the playlist as teacher, essayist and source of its vocabulary."
tags: [yc, essays, investors, yc-lore]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

Co-founder of [Y Combinator](/organizations/y-combinator.md). Does not appear as a speaker in this
playlist but is referenced by four of the fifteen speakers, which makes him the collection's most
cited absent figure.

# How he is invoked

**[Sam Altman](/sources/sam-altman.md)** — the most substantial treatment. Altman was in YC's first
batch in 2005, when PG himself cooked dinner for the eight companies each week; his account is that
everyone walked in dejected and left convinced they were about to take over the world, and he calls
that ability to create optimism and momentum out of nothing a real PG special. He also relays PG's
model of investing as teaching — not the lecturer but the **flight instructor**, sitting next to you
saying do this, not that — and credits PG with willing YC into existence when it, and startups, and
young technical founders with no business people, all seemed like terrible ideas. Altman calls him
probably the most important force in startups of the last few decades. He also attributes to PG the
observation that the world does not know how to intuit exponentials. See
[/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md).

**[Garry Tan](/sources/garry-tan.md)** — invokes two PG rules as still governing everything: *make
something people want* and *do things that don't scale*. His claim is that the advice did not change
but the multiplier on the second one did, because agents are how one founder now does unscalable
things at scale. See [/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md).

**[Patrick Collison](/sources/patrick-collison.md)** — credits YC with teaching him to focus on
concrete, viscerally felt customer problems rather than hallucinated ones, and engages directly with
PG's **schlep blindness** as it applies to Stripe. See
[/concepts/schlep-blindness.md](/concepts/schlep-blindness.md).

**[Max Junestrand](/sources/max-junestrand.md)** — cites a PG essay on ambition compounding among
peers. See [/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md).

# Sources

Referenced in [/sources/sam-altman.md](/sources/sam-altman.md),
[/sources/garry-tan.md](/sources/garry-tan.md),
[/sources/patrick-collison.md](/sources/patrick-collison.md),
[/sources/max-junestrand.md](/sources/max-junestrand.md).

[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
