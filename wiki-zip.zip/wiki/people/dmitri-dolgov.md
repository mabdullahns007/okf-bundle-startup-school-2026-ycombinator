---
type: Person
title: "Dmitri Dolgov"
description: "Co-CEO of Waymo; gave the playlist's most structured technical talk on shipping physical AI."
tags: [waymo, autonomous-vehicles, physical-ai, reliability]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

Co-CEO of [Waymo](/organizations/waymo.md), having worked on the technology and product for close to
two decades — from the project's start in 2009.

# What he contributes to this wiki

Seven lessons, and much of the wiki's physical-AI vocabulary:

- [/concepts/four-gaps-of-physical-ai.md](/concepts/four-gaps-of-physical-ai.md)
- [/concepts/ladder-of-nines.md](/concepts/ladder-of-nines.md) and
  [/case-studies/waymo-demo-to-product-timeline.md](/case-studies/waymo-demo-to-product-timeline.md)
- [/concepts/performance-vs-effort-curves.md](/concepts/performance-vs-effort-curves.md) and
  [/concepts/sensing-redundancy.md](/concepts/sensing-redundancy.md)
- [/concepts/riding-tech-waves-without-fragmentation.md](/concepts/riding-tech-waves-without-fragmentation.md)
- [/concepts/fast-path-slow-path-architecture.md](/concepts/fast-path-slow-path-architecture.md)
- [/concepts/structure-augmented-end-to-end.md](/concepts/structure-augmented-end-to-end.md)
- [/concepts/closed-loop-simulation.md](/concepts/closed-loop-simulation.md) and
  [/concepts/agent-simulator-critic-flywheel.md](/concepts/agent-simulator-critic-flywheel.md)
- [/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md)

# The framing device

He opens with a clip of a ride he took with his children in which two human drivers cut in front of
the vehicle, and the Waymo driver responded safely and smoothly — so smoothly that his children,
preoccupied in the back seat, did not notice anything had happened. His generalisation: the best
physical AI moments will look like nothing happened.

He closes on why it matters rather than on technology: remember who you are building for — your
mission and your customers — otherwise the tech is just a science project.

# Source

- [/sources/dmitri-dolgov.md](/sources/dmitri-dolgov.md)

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
