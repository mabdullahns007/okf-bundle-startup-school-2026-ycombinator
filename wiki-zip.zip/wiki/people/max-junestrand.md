---
type: Person
title: "Max Junestrand"
description: "Co-founder and CEO of Legora; the playlist's account of going from a YC rejection to $100M ARR."
tags: [legal-ai, growth, culture, europe]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

Co-founder and CEO of [Legora](/organizations/legora.md). Born in the Swedish archipelago in a school
class of ten; met two co-founders at a volleyball game; dropped out of a master's degree when
GPT-3.5 arrived, having planned to join McKinsey. His father ran two companies during the dot-com
era that went to zero after raising too much venture capital, then a boat business; Junestrand
speaks with him almost daily and calls him a senior adviser.

# What he contributes to this wiki

- [/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md) — the figures and
  their inconsistencies.
- [/concepts/customer-discovery-by-paying-for-access.md](/concepts/customer-discovery-by-paying-for-access.md)
  and [/concepts/deliberate-sales-freeze.md](/concepts/deliberate-sales-freeze.md).
- [/concepts/product-manifesto.md](/concepts/product-manifesto.md) and
  [/concepts/build-one-step-ahead-of-the-models.md](/concepts/build-one-step-ahead-of-the-models.md).
- [/concepts/eval-driven-model-routing.md](/concepts/eval-driven-model-routing.md).
- [/concepts/hire-for-slope-not-intercept.md](/concepts/hire-for-slope-not-intercept.md) and
  [/concepts/culture-against-local-norms.md](/concepts/culture-against-local-norms.md).
- [/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md) and
  [/concepts/storytelling-as-the-core-ceo-skill.md](/concepts/storytelling-as-the-core-ceo-skill.md).
- [/concepts/mini-games-and-requalifying.md](/concepts/mini-games-and-requalifying.md) and
  [/concepts/love-the-hustle.md](/concepts/love-the-hustle.md).

# The rejection

Legora applied to YC in May 2023 and was asked what type of lawyers they served; they replied by
asking whether there were different types. A partner laughed and they knew they were finished. They
were accepted two months later under a new name. See
[/concepts/rejection-as-signal-vs-noise.md](/concepts/rejection-as-signal-vs-noise.md).

# On the current hard problem

The transition from reactive to proactive agents: instead of prompting the system, context is
connected so that a trigger starts work — a contract arriving at the sales team routing to an agent
that works in parallel and escalates to a lawyer only if needed, or a data room connected so the
agent organises it and produces the diligence report. His stated unlock: one lawyer producing the
output of ten.

# Source

- [/sources/max-junestrand.md](/sources/max-junestrand.md)

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
