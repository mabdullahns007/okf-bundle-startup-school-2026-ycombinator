---
type: Person
title: "Garry Tan"
description: "President and CEO of Y Combinator; keynoted Startup School 2026 on personally owned AI infrastructure."
tags: [yc, personal-agi, investors, open-source]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-altman
    resource: https://www.youtube.com/watch?v=ZIaOBAjvc38
    title: "Sam Altman: Never a Better Time to Do a Startup"
    author: "Sam Altman"
    last_modified: 2026-07-28
---

President and CEO of [Y Combinator](/organizations/y-combinator.md). A YC partner in 2013, when he
built YC's internal social network at night. Delivered the Startup School 2026 keynote and
interviewed [Jensen Huang](/people/jensen-huang.md), [Alexandr Wang](/people/alexandr-wang.md) and
[Sam Altman](/people/sam-altman.md) on stage.

# What he contributes to this wiki

His keynote is the event's ideological centre. See
[/sources/garry-tan.md](/sources/garry-tan.md) for the full synthesis and:

- [/concepts/personal-agi.md](/concepts/personal-agi.md) — the thesis.
- [/concepts/library-and-librarian.md](/concepts/library-and-librarian.md) — the working-memory
  argument.
- [/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md) and
  [/concepts/latent-vs-deterministic-computation.md](/concepts/latent-vs-deterministic-computation.md)
  — the mechanics.
- [/concepts/own-your-skill-files.md](/concepts/own-your-skill-files.md) — the politics.
- [/concepts/knowledge-base-hygiene.md](/concepts/knowledge-base-hygiene.md) — his own caveat.
- [/concepts/revenue-per-employee.md](/concepts/revenue-per-employee.md) — the receipts.
- [/case-studies/spinoza-compendium-skill.md](/case-studies/spinoza-compendium-skill.md).

# Stated open-source work

G brain, a Karpathy-style knowledge wiki of about 220,000 markdown pages covering 25 years of his
life, and G stack, an agent coding framework he puts at about 123,000 GitHub stars. Both open
source; a hosted version at gbrain.io described as free. His stated reason for open-sourcing all of
it: being at YC means he does not have to monetise his own infrastructure — and that tools of the
powerful should be given away, because when such a technology stays private you get a priesthood
and when it is given away you get a renaissance.

# Note on this repository

Tan's talk explicitly names the Karpathy LLM-wiki pattern that this bundle implements. See
[karpathy-llm-wiki.md](../../karpathy-llm-wiki.md).

# Sources

- [/sources/garry-tan.md](/sources/garry-tan.md) (speaker)
- Interviewer in [/sources/jensen-huang.md](/sources/jensen-huang.md),
  [/sources/alexandr-wang.md](/sources/alexandr-wang.md),
  [/sources/sam-altman.md](/sources/sam-altman.md)

[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-altman]: Sam Altman, [Sam Altman: Never a Better Time to Do a Startup](/sources/sam-altman.md), Startup School 2026.
