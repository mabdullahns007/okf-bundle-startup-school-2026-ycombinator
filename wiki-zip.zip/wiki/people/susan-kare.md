---
type: Person
title: "Susan Kare"
description: "Iconographer and designer of the original Macintosh's system font and icons."
tags: [design, apple, iconography, craft]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Susan Kare"
    last_modified: 2026-08-14
---

Iconographer and designer. Joined the [Macintosh group at Apple](/organizations/apple-macintosh-group.md)
as the Macintosh artist, having been an art major with a PhD in art history and no computing
background — recruited by her high-school friend Andy Hertzfeld, then a system software programmer
there. Immediately before Apple she was welding a life-size razorback hog for an Arkansas museum,
which she says was lonely enough to make her hungry to work with a team. She had some typographical
experience from making exhibit labels at Philadelphia's Franklin Institute and was good at rub-down
type.

# What she contributes to this wiki

The one talk with no AI content, and the one whose lessons transfer most directly:

- [/concepts/constraints-enable-creativity.md](/concepts/constraints-enable-creativity.md) —
  16x16, one bit, and an icon editor with no drawing tools and no undo.
- [/concepts/sparse-metaphor-over-literal-detail.md](/concepts/sparse-metaphor-over-literal-detail.md)
  — her central design principle, and her account of her own mistakes.
- [/concepts/show-dont-tell-make-it-visual.md](/concepts/show-dont-tell-make-it-visual.md),
  [/concepts/never-show-one-option.md](/concepts/never-show-one-option.md) and
  [/concepts/how-to-commission-creative-work.md](/concepts/how-to-commission-creative-work.md).

# Her work as discussed

Chicago (the first font she designed, nine-pixel cap height) and the city-named fonts New York,
Geneva and others — named after stations on the Paoli Local near her and Hertzfeld's high school,
until Steve Jobs said they should at least be world-class cities. The Happy Mac, the bomb, and the
Command key glyph. MacPaint icons and patterns, in collaboration with Bill Atkinson. Later: Windows
3.0 icons and Solitaire cards for Microsoft, the General Magic logo, Facebook Gifts for nearly four
years, Pinterest icons, a Ledger wallet badge series, and an Amtrak route map.

Her interview notebook of early graph-paper icons is now in MoMA's permanent collection — hence her
advice to hang on to your stuff.

# Her collected advice

The closing third of the talk is a list of advice from people who influenced her, which she says she
is still adding to: [Paul Rand](/concepts/how-to-commission-creative-work.md), Paul Saffo on
estimation, her father on fundraising realism, Daniel Nord on making it visual, Alan Kay on nesting
interface elements, Andy Hertzfeld on showing work, her mother, and Steve Jobs — including the one
piece of advice from Jobs she calls bad, which was not to buy Apple stock.

# Source

- [/sources/susan-kare.md](/sources/susan-kare.md)

[^ss26-kare]: Susan Kare, [Susan Kare: Designing Icons & Graphics For the Original Mac](/sources/susan-kare.md), Startup School 2026.
