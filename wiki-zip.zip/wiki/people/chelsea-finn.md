---
type: Person
title: "Chelsea Finn"
description: "Co-founder of Physical Intelligence; gave the playlist's state-of-the-art robotics talk."
tags: [robotics, physical-ai, reinforcement-learning, research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

Co-founder of [Physical Intelligence](/organizations/physical-intelligence.md), started about two
years before the talk. Also spoke at the previous year's event, where she showed laundry folding and
robots doing useful tasks in rooms they had never been in before. Has a PhD, which she says she
never planned to do.

# What she contributes to this wiki

- [/concepts/decision-support-vs-direct-action.md](/concepts/decision-support-vs-direct-action.md)
  — her framing of why physical AI needs far higher reliability.
- [/concepts/robot-rl-with-human-interventions.md](/concepts/robot-rl-with-human-interventions.md)
  — the espresso and box-building results, and why language-model RL does not port to hardware.
- [/concepts/multi-timescale-robot-memory.md](/concepts/multi-timescale-robot-memory.md).
- [/concepts/compositional-generalization.md](/concepts/compositional-generalization.md) and
  [/concepts/metadata-prompting-for-heterogeneous-data.md](/concepts/metadata-prompting-for-heterogeneous-data.md).

# Notable intellectual honesty

Several places where she volunteers evidence against her own story, which is worth flagging because
it is what makes the talk usable: the air fryer she assumed was absent from training data turned out
to appear in three episodes; the "imagination" mechanism helped less than expected, to the point
that a planned technical report about it was reframed; and she states plainly that only a few
improvement iterations were run, that the robots still make mistakes, and that they are still slower
than people.

# On the PhD

Her father, an engineer, told her he would not hire someone with a PhD. She now argues its real
value is learning to handle uncertainty and to pick problems — nobody hands you the problem, and you
do not know whether progress is possible in six months, two years or ten — which she finds directly
useful at the AI frontier where nobody knows the best route. She is equally clear that much of what
her company needs is engineering that requires no PhD at all.

# Source

- [/sources/chelsea-finn.md](/sources/chelsea-finn.md)

[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
