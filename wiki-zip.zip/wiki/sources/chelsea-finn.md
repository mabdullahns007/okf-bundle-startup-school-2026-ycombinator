---
type: Video Presentation
title: "Chelsea Finn — This is the State of the Art in Robotics"
description: "A scalable RL recipe for long-horizon robot autonomy, multi-timescale memory, and a single generalist policy that matches fine-tuned specialists while generalising compositionally."
tags: [startup-school-2026, robotics, physical-ai, reinforcement-learning, memory, generalization]
status: draft
resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
speakers: [Chelsea Finn]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Y Combinator"
    last_modified: 2026-08-12
---

# Summary

A technical talk in two halves — long-term autonomy, then a single generalist model — plus a
long audience Q&A. Finn explicitly says the point is not cool robot videos but what it
actually takes for robots to be useful.

# Why physical AI needs far higher reliability

Her opening argument is a reading of AI's production history: recommendations and ad ranking,
then deep learning applied to the same, then ChatGPT as the first genuinely general-purpose
model in wide use, then coding agents. In *all* of those, the customer makes the decision based
on the model's suggestion — so a mistake is recoverable and there is less pressure to be
perfect. Physical AI acts on the world directly, is far more useful when fully autonomous, and
therefore must make far fewer mistakes than any deployed ML system so far. Her cited existence
proof that this is achievable is Waymo passing a quarter of a million weekly autonomous rides.
See [/concepts/decision-support-vs-direct-action.md](/concepts/decision-support-vs-direct-action.md).

# Part 1: a scalable RL recipe

**The target.** Making espresso reliably, at over 90% — a task requiring precise forceful
insertion of the portafilter, smooth handling of full cups, and accurate timing, which she
notes is unusual as a requirement in ML.

**Why the naive loop stops working.** Collect data, train, evaluate rarely works first try. The
better loop — collect more data, improve label quality and detail, target edge cases, rebalance
— improves reliability but *people get tired*, and manual tuning does not reach very high nines.
So the system should iterate on itself, seeking out where it needs more supervision, which is
essentially reinforcement learning.

**Why language-model RL does not transfer directly.** PPO and GRPO have scaled to millions or
tens of millions of attempts because an attempt is just compute. Translated to robotics, even
one million one-minute trajectories is about 700 robot-days — for a task shorter than the
espresso task. The calculus differs because you are consuming real hardware and real time.

**Two efficiency fixes.** First, do not spend robot time on dead-end trajectories: when a robot
grabs two flush cardboard boxes and would keep trying to fold both, a human teleoperator
intervenes to demonstrate recovery, or the episode terminates early. Second, amortise value
estimation across prompts rather than rolling out a single prompt tens of times: train one
general-purpose value function over robot experience that learns, for example, that accidentally
unfolding a shirt is negative progress — and which transfers to unrelated scenarios such as
retrieving an item from a fridge. See
[/concepts/robot-rl-with-human-interventions.md](/concepts/robot-rl-with-human-interventions.md).

**Results.** A latte task where the robot handles espresso and a person steams milk, with joint
positions predicted directly from camera images, including the hardest step — transferring a
full cup to a coaster without spilling. Run continuously for 13 hours to test reliability rather
than one-shot success. The same algorithm was applied to a real Dandelion Chocolate workflow
(build, label and stack cardboard boxes) and to folding clothes never seen before in a home
never seen before. Measured by throughput — coupling success rate and speed — the RL
post-training stage roughly doubled throughput, and espresso success exceeded 90%. Her caveats
are notable: only a few improvement iterations were run, the robot still makes mistakes, and it
is still slower than a person.

# Memory

Most state-of-the-art robot foundation models have no memory: they act on current sensor
readings. That is fine for short motor skills and repetitive tasks, but not for multi-step
tasks where progress must be tracked. The reason is cost: ten seconds of video at 50 Hz across
four cameras at ~256 tokens per image is roughly half a million tokens per step; subsampling to
1 fps still means 10,000 tokens for ten seconds of memory. Physical Intelligence's answer is
memory at multiple timescales — an efficiently computed ~10-second short-term video memory, plus
minutes-to-hours memory stored as *text summaries* of what happened. This enables 10–15 minute
fully autonomous non-repetitive tasks: wiping a counter, drying it, discarding the towel, putting
the mustard in the fridge, putting dishes away, washing what is in the sink. See
[/concepts/multi-timescale-robot-memory.md](/concepts/multi-timescale-robot-memory.md).

# Part 2: one generalist model

**Where robotics sits on the generalist-AI timeline.** Her chronology: 2012, a from-scratch deep
network beats specialist methods on an external benchmark; ~2014, pre-train then fine-tune
becomes the norm; then models that work out of the box without fine-tuning; and 2021, the first
signs of compositional generalisation. Robotics in 2023 was still collecting bespoke datasets and
training from scratch per project — the equivalent of collecting ImageNet from scratch every time
— and until recently sat around the 2014 stage.

**Two goals.** Out-of-the-box performance (BERT → GPT), because every strong robot result to that
point required task-specific fine-tuning; and compositional generalisation in the spirit of the
avocado-chair result, which matters because combining concepts implies conceptual understanding
and because your data then need not cover every combination.

**The recipe.** Use *all* available data — diverse robot demonstrations including deliberately
low-quality ones, policy rollouts, human videos, and web data — and give the model enough
capacity. The key unlock she names is *prompting the model with all the context it needs*: a
high-level instruction, an immediate subtask instruction, metadata indicating data quality and
episode length, and optionally a generated sub-goal image of what the near future should look
like. At deployment a high-level policy predicts the next subtask and a world model generates
the sub-goal images.

**Results (π0.7).** A single model folds a collared shirt, inserts and drills a screw into a
robot arm, and replaces a bin liner. Measured on the coffee and box-building tasks, the single
pre-trained model matches or beats the fine-tuned specialists produced by RL post-training — and
also beats SFT specialists.

**Compositional generalisation tests.** An air fryer, chosen because it was assumed absent from
training data; post-hoc analysis found three episodes containing one, which she reports honestly
while arguing it was likely inconsequential. And cross-embodiment transfer: folding clothes on a
large industrial platform with no folding data on that platform, differing in size, link lengths
and joint configuration — the first success left the team floored.

**Ablations, which she calls the most interesting experiment.** Removing the most diverse data
sharply degrades held-out task performance, while removing a random 20% barely does. And without
metadata prompting, adding the last tranche of low-quality data *hurts*; with it, the same data
*helps* — the model extracts value from low-quality data when told it is low-quality. See
[/concepts/metadata-prompting-for-heterogeneous-data.md](/concepts/metadata-prompting-for-heterogeneous-data.md)
and [/concepts/compositional-generalization.md](/concepts/compositional-generalization.md).

**Deployment.** Two YC companies (Ultra and Weave) post-trained these models for laundry folding
and warehouse packaging; the same family adapts to drones, quadcopters, surgical robots and
tractors.

# From the Q&A

- **A ChatGPT moment for robotics** will not look the same, because distribution requires physical
  hardware — but she thinks ChatGPT-level *capability* is very much on the horizon in the next few
  years.
- **Small teams** should start from an open-source generalist policy and fine-tune immediately;
  π0 and π0.5 are open source. The exception is genuinely constrained environments — she cites
  surgical robots in a basement operating room with no internet and a poor GPU.
- **On the PhD.** She never planned to do one and her father, an engineer, said he would not hire
  someone with one. She now says the PhD's real lesson is handling uncertainty and choosing which
  problems to work on, which she finds directly useful at the AI frontier where nobody knows the
  best route — while noting there is a great deal of engineering (software stack, hardware, ML and
  data infrastructure) in robotics that requires no PhD.
- **The robotics equivalent of internet-scale data.** Since you want training to match test, it is
  robots operating in real-world circumstances: teleoperation initially, and increasingly the
  robot's own autonomous attempts, mirroring how much of language-model data generation is now
  synthetic. Human video and captioned web data help, but there is no substitute — watching Roger
  Federer does not make you able to play like him.
- **Action space.** The shown models output target joint positions tracked by a PD controller, and
  are also trained to predict gripper positions in 3D. Going straight to torques or voltages would
  allow controlling stiffness; she notes it does not currently appear to be the bottleneck, and she
  prefers to work on bottlenecks.
- **Imagination.** The sub-goal image mechanism helped measurably on shirt folding, but the model
  was surprisingly good without it — so much so that a planned technical report focused on that
  capability was reframed.
- **Speed.** She is excited about it; a separate release showed policies faster than human
  teleoperation. The bottleneck is that teleoperation, the easiest way to teach, is slow — so you
  either make the data faster or learn to exceed the data.
- **Her favourite surprise.** Training pinwheel assembly where every demonstration picked up the
  pin with the right hand and the paper with the left, the robot made a mistake that reversed the
  objects, then inserted the pin with its left gripper into paper held in its right — a hand
  equivariance that appeared in neither post-training nor pre-training data.
- **Breaking into robotics from software.** Her example is a colleague who moved from algorithmic
  trading through legal AI, bought a cheap robot, fine-tuned an open-source model in her bedroom,
  shared the result, cold-emailed, and now works at Physical Intelligence.

# See also

- [/people/chelsea-finn.md](/people/chelsea-finn.md), [/organizations/physical-intelligence.md](/organizations/physical-intelligence.md)
- The complementary industrial view is [/sources/dmitri-dolgov.md](/sources/dmitri-dolgov.md);
  the supplier view is [/sources/jensen-huang.md](/sources/jensen-huang.md).

[^ss26-finn]: Startup School 2026 talk; see raw record [ss26-04-chelsea-finn.md](../../raw/ss26-04-chelsea-finn.md).
