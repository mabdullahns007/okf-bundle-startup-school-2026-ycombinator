---
type: Video Presentation
title: "Alexandr Wang — This is a Once-in-a-Civilization Opportunity"
description: "First-principles origin of Scale, conviction against consensus, talent density, each AI wave being ~10x the last, and vision and ambition as the newly scarce inputs."
tags: [startup-school-2026, conviction, frontier-labs, agents, open-weights, personal-agi]
status: draft
resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
speakers: [Alexandr Wang, Garry Tan]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: \"This is a Once-in-a-Civilization Opportunity\""
    author: "Y Combinator"
    last_modified: 2026-07-29
---

# Summary

An interview by [Garry Tan](/people/garry-tan.md) covering Wang's path to founding Scale
at 19 and his current work leading Meta's frontier lab.

# Key claims

**The origin of Scale was a missing third ingredient.** Training a model at MIT required
three things: cloud compute, code, and data. Two were a button click away; there was no
effective way to get training data. Wang describes this as feeling obvious, and notes that
for years afterwards investors were sceptical of data as a business — none of them had ever
trained a model — while some of the same investors later wrote think pieces about data
being one of the biggest opportunities in AI.[^ss26-wang] This is the playlist's clearest
example of [/concepts/first-principles-market-discovery.md](/concepts/first-principles-market-discovery.md).

**Two things mattered before starting: working at a company, and school.** A gap year at
Quora taught him what building, iterating and group decision-making actually look like from
the inside; a year at MIT gave him room to explore, train his first models, and arrive at
the idea.[^ss26-wang]

**Conviction in beliefs nobody shares.** His central claim: the most successful companies
were started long before their core idea was popular and toiled in obscurity until it
became consensus. Following the herd produces confusion, so you must build your own compass
for what the future looks like. See
[/concepts/conviction-against-consensus.md](/concepts/conviction-against-consensus.md).

**Nobody is good at starting a company when they start one.** The whole game is the rate at
which you improve. See [/concepts/founder-rate-of-improvement.md](/concepts/founder-rate-of-improvement.md).

**The bottleneck is diffusion, not capability.** Wang argues that if models stopped
improving today there would still be decades of economic upheaval left in deploying what
already exists — which is why he calls this a once-in-a-civilization opportunity to hold a
vision and impose it. See [/concepts/diffusion-is-the-bottleneck.md](/concepts/diffusion-is-the-bottleneck.md).

**David vs Goliath has become Goliath vs Goliath.** Ten years ago a startup needed an angle
because it was outgunned. Now a startup that properly embraces agents is, in his framing, a
"mecha Goliath" that can outcompete incumbents directly.[^ss26-wang]

**Personal superintelligence.** He describes a memo by Mark Zuckerberg a year earlier and
explicitly links it to Tan's personal-AGI framing: billions of people each with a
superintelligence adapted to them, whose purpose is *agency expansion* — and a rejection of
a totalising single-AI world in favour of an ecosystem of business agents and personal
agents. He cites 200 million businesses on Meta's platforms today and expects billions. See
[/concepts/personal-agi.md](/concepts/personal-agi.md).

**Rebuilding a frontier lab.** Wang says Llama 4 was not on the needed trajectory, so he did
a "zero-based build" of the lab, shipping a new frontier model within nine months and an
update two months later. His stated core bet was talent density, which compounds because
the most talented people want to join the most talented people. He stresses that frontier
AI work is *research* — experimentation and science — requiring a different operating model
from internet product companies, and describes the lab as an organism that must grow along
several simultaneous exponentials: capability, compute, adoption. See
[/concepts/talent-density-compounds.md](/concepts/talent-density-compounds.md).
Model names in this section are unreliable in the auto-transcript; see
[transcription caveats](/sources/index.md#transcription-caveats).

**Each wave is roughly ten times the last.** Self-driving cars → chatbots → coding agents,
each about 10x the previous in his estimate, with more modalities and form factors to come.
He also argues against rationing intelligence by price. See
[/concepts/ten-x-waves.md](/concepts/ten-x-waves.md).

**Agentic feedback loops are where the alpha is.** Companies are large-scale feedback loops
with humans on the edges: get customers, make them happier, they spend more, hire more
people to get more customers. Wang's claim is that agents can operate and optimise those
loops, and that internally at Meta a swarm of agents with the right eval has accomplished
more than a team of a hundred engineers. Asked what this looks like mechanically, he agrees
it is skills, markdown files and cron jobs — "it's always funny how mundane everything is
once you really dig into it." See
[/concepts/agentic-feedback-loops.md](/concepts/agentic-feedback-loops.md).

**Do not go all-in on words over shapes.** Asked whether systematic technical thinking still
matters, he says the abstraction layer keeps moving — code, then organisations of humans,
then orchestration of agents, then organisations of a million agents — but systems thinking
never goes out of style.[^ss26-wang]

**The newly scarce inputs are vision and ambition.** For most of history the bottleneck on
progress was groups of smart people coordinating toward a shared goal; if intelligence and
agency become abundant, what is scarce is a clear view of how you want the world to differ
and the drive to push it there. See
[/concepts/vision-and-ambition-as-scarce-inputs.md](/concepts/vision-and-ambition-as-scarce-inputs.md).
He pairs this with a builder's responsibility to prepare the world — enterprises,
governments, biosecurity, cybersecurity.

**Message to his 18-year-old self:** build your own internal compass and hold conviction in
it, because you will be inundated with noise; and find the exponential with the steepest
curve that will run the longest, accepting that its starting point may look boring — his
own started at cat detectors in YouTube videos. See
[/concepts/find-the-steepest-longest-exponential.md](/concepts/find-the-steepest-longest-exponential.md).

# See also

- [/people/alexandr-wang.md](/people/alexandr-wang.md), [/organizations/meta-superintelligence-labs.md](/organizations/meta-superintelligence-labs.md)
- Same conviction argument as [/sources/sam-altman.md](/sources/sam-altman.md); same
  decentralisation argument as [/sources/patrick-collison.md](/sources/patrick-collison.md).

[^ss26-wang]: Startup School 2026 talk; see raw record [ss26-11-alexandr-wang.md](../../raw/ss26-11-alexandr-wang.md).
