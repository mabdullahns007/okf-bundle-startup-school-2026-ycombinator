---
type: Video Presentation
title: "Michael Kratsios — Inside the White House's AI Strategy"
description: "How federated US tech policy actually gets made, why hard regulatory thresholds fail, preemption and Little Tech, and a science-policy report in the tradition of Vannevar Bush."
tags: [startup-school-2026, policy, regulation, open-weights, science-funding, quantum]
status: draft
resource: https://www.youtube.com/watch?v=zLUZclThLhU
speakers: [Michael Kratsios, Luther Lowe]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Y Combinator"
    last_modified: 2026-08-18
---

# Summary

An interview with the Director of the White House Office of Science and Technology Policy,
conducted by YC's head of public policy. Kratsios previously served as US Chief Technology
Officer and, between government roles, was COO of Scale AI.

Note: policy positions below are reported as Kratsios stated them at a YC event, not as
independently verified fact.

# How technology policy actually gets made

His central "surprising" claim is that decisions are extraordinarily federated. There is no
technology department — there is a health agency and a defence department — so tech issues span
many agencies with different equities, and the White House's job is to convene them. His worked
example is drones: the FAA's rules must be right *and* the people overseeing nuclear weapons
must be satisfied that drones will not fly over nuclear sites.

Structurally he describes four policy councils — national security, domestic, economic, and
science and technology — each running processes on its topics. His own portfolio covers AI,
quantum, civil nuclear energy, biotech and space, typically with one or two people per area (a
space team of about three coordinating NASA and defence satellite equities). A typical day is
stakeholder meetings, the blocking and tackling of pushing agencies toward a decision, and
public communication. Disagreements escalate up levels until, if unresolved, they reach the
president — so part of the job is limiting what has to reach him. See
[/concepts/how-federated-tech-policy-works.md](/concepts/how-federated-tech-policy-works.md).

# Open source and open weights

Asked about a week of speculation that an executive order might restrict open-weight models —
and a letter YC helped organise — Kratsios said the position is unchanged from page one of the
administration's AI Action Plan released the previous July, which he co-authored: a commitment
to open source, on the view that US leadership requires a vibrant closed *and* open ecosystem.
He framed the week positively, arguing that if Washington hears nothing from the startup or
broader industry ecosystem it cannot make good decisions. See
[/concepts/open-weights-policy.md](/concepts/open-weights-policy.md).

# Against hard thresholds

On writing rules for something reinventing itself every six months, his answer is that firm red
lines do not work. His two examples: the EU AI Act, which he notes was finalised before ChatGPT
existed, so post-2022 language models must comply with rules written before they were a thing;
and the previous administration's hard compute-threshold disclosure trigger. His general
principle is that thresholds do not survive contact with a moving frontier, and that once
government sets one it is very hard to reset. See
[/concepts/regulating-a-moving-frontier.md](/concepts/regulating-a-moving-frontier.md).

⚠️ **Factual note.** The auto-transcript has Kratsios dating ChatGPT's release to November 2021;
the actual release was November 2022. Either a misstatement or a transcription artifact — the
argument is unaffected. Logged in [/log.md](/log.md).

# Risks he rates high and low

He names two current risks: cyber capability, noting the inherent trade-off that the model able
to do something nefarious is the model able to harden systems; and biological risk, which he
judges "a bit overblown" given that people were warning about it years earlier without incident
— while insisting on building the infrastructure to run the right tests and evals as models pass
the frontier. Model names in this passage are unreliable in the transcript.

# Little Tech and preemption

Asked how a two-person company competes when the five biggest tech companies dominate policy
conversations, he pointed to consultation mechanisms (requests for information and comment) and,
as his substantive example, federal preemption of state AI law: a patchwork of different rules
in California, Maryland and Texas is survivable for a company that can hire an army of lawyers
and fatal for a startup, so one national standard is the pro-startup position. The interviewer
noted YC helped spin up a "Little Tech Association" trade group and credited continuity in
big-tech antitrust cases across administrations. See
[/concepts/preemption-and-little-tech.md](/concepts/preemption-and-little-tech.md).

# Born free vs born in captivity

The framing he offers founders worried about compliance costs. *Born free* technologies have no
rules on the books — the early internet — and the policy job is to preserve that and be very
cautious about introducing regulation. *Born in captivity* technologies can be built but not
legally commercialised without approval: you can build an excellent drone and the software to
match, but the transaction cannot legally close without an FAA waiver. For those, the job is
relentlessly removing barriers. His favourite example is supersonic flight, which he calls the
most in-your-face example of technological stagnation — the fix being a noise limit rather than
a speed limit — connecting directly to
[/sources/blake-scholl.md](/sources/blake-scholl.md). See
[/concepts/born-free-vs-born-in-captivity.md](/concepts/born-free-vs-born-in-captivity.md).

# The science report

The interview's substantive centrepiece. The history: in 1945 FDR wrote to his science adviser,
Vannevar Bush, asking how to organise science after the war; Bush's reply, *Science, the Endless
Frontier*, argued government must fund early-stage basic research the private sector is not
incentivised to do, and defined how American science worked for seventy years.

What changed: around 1950 the federal government funded almost 70% of R&D and the private sector
30% or less; that has fully inverted, with private sector plus philanthropy now around 70%. For
pure basic research there is now near-parity. New actors exist — startups, and focused research
organisations sitting outside universities. So Kratsios says President Trump wrote him a letter
in the same form as FDR's, and the resulting roughly 150-page report, *Science and the New Golden
Age*, is the year-long answer.

Its core thesis relevant to founders: AI will transform how scientific discovery is done — in
materials science, pharmaceuticals, chemistry — and a government spending nearly $200 billion a
year on R&D must prioritise accordingly. The interviewer summarised the final chapter's concrete
commitments: fast grants decided in under a month, prizes built for 3:1 private leverage, and
every major agency filing an action plan within 90 days, under the principle that government's
job is to shape the arena rather than direct discovery.

Asked what he hopes a couple of 20-year-olds build because government cannot, his answer is the
infrastructure of autonomous experimentation: cloud labs running hypothesis → experiment →
result → new hypothesis on a loop without human intervention. Getting there needs robotics
perfected and the software layer to propose the next hypothesis. See
[/concepts/autonomous-cloud-labs.md](/concepts/autonomous-cloud-labs.md) and
[/concepts/shape-the-arena-not-the-discovery.md](/concepts/shape-the-arena-not-the-discovery.md).

# Quantum as the next AI

His answer for what Washington will care about in five years but barely discusses now. The
analogy is personal: in 2017–18 as CTO he was walking around the West Wing trying to convince
people AI mattered, with a sympathetic article every couple of months, before the first
presidential AI executive order in February 2019 and a doubling of AI R&D in the budget. He is
careful to say that work was not the reason ChatGPT happened, but that it primed the ecosystem.
He reports a new quantum executive order and a presidential goal for the Department of Energy to
build a scientifically relevant quantum computer by 2028.

# Congress, and IP

On why so much AI policy arrives by executive order, he notes the mechanical asymmetry: an EO can
be revoked by the next administration, while a law cannot. He would urge Congress to pass
preemption, and names AI's interaction with intellectual property and name/image/likeness as the
area where Americans most want Congress to act. His own clear line is on model *outputs*: a model
that outputs Mickey Mouse is not acceptable. Beyond that he favours letting licensing and
revenue-sharing markets mature rather than legislating fast — the interviewer cited a Yelp/ChatGPT
review deal as an early instance. See
[/concepts/ai-and-intellectual-property.md](/concepts/ai-and-intellectual-property.md).

# Why public service

His closing pitch, and his answer to the opening question: he believes there is nowhere you can
work on bigger problems, and that the US remains uniquely the best place in the world to start a
company — something he sees his job as protecting. He acknowledges government can be a slog and
bureaucratic, and argues the fulfilment comes when the outcome actually lands.

# See also

- [/people/michael-kratsios.md](/people/michael-kratsios.md), [/organizations/white-house-ostp.md](/organizations/white-house-ostp.md)
- Open-weights advocacy also appears in [/sources/alexandr-wang.md](/sources/alexandr-wang.md),
  [/sources/jensen-huang.md](/sources/jensen-huang.md) and
  [/sources/peter-steinberger.md](/sources/peter-steinberger.md).
- Autonomous experimentation is [/sources/jeff-dean.md](/sources/jeff-dean.md)'s 2027 prediction.

[^ss26-kratsios]: Startup School 2026 talk; see raw record [ss26-02-michael-kratsios.md](../../raw/ss26-02-michael-kratsios.md).
