---
type: Video Presentation
title: "Dmitri Dolgov — The Demo Is Only 1% Of The Work"
description: "Seven lessons from shipping autonomous driving: the ladder of nines, sensing redundancy, riding tech waves without fragmenting, structure-augmented end-to-end, closed-loop simulation, and evals as the moat."
tags: [startup-school-2026, physical-ai, evals, simulation, world-models, reliability, safety]
status: draft
resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
speakers: [Dmitri Dolgov]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Y Combinator"
    last_modified: 2026-08-03
---

# Summary

The most systematically structured talk in the playlist: seven technical lessons about
building AI that acts in the physical world. Its framing device is that the best physical
AI moments look like nothing happened.

# The four gaps between digital and physical AI

Dolgov opens by naming what makes the problem different in kind:

1. **Cost of error.** A chatbot mistake costs a retry; there is no undo in the physical world.
2. **Latency.** A car at freeway speed covers about 100 feet per second, and all inference
   must run on a computer that fits in the trunk.
3. **Data.** Digital AI had the internet as a pre-labelled cache of human thought. There is
   no digitised internet of the physical world.
4. **Validation.** You cannot ship "good enough" and let users find edge cases; you need high
   confidence before the first mile.

See [/concepts/four-gaps-of-physical-ai.md](/concepts/four-gaps-of-physical-ai.md).

# The seven lessons

**1. Count your nines before you count your demo views.** The demo is at best 1% of the
work. Waymo hit its first 90% around 2010 — a dozen engineers, 100,000 autonomous miles and
ten 100-mile routes without intervention, before ConvNets, transformers or VLMs. The demo
took 18 months; the product took about 15 years. Each additional nine costs roughly 10x and
requires *doing something categorically different*, not the same thing for longer. At scale
the long tail is the entire problem statement. He also notes the hype-cycle mechanism: every
breakthrough makes demos ~100x easier while barely moving the tail, so each wave produces
spectacular demos and few products. See
[/concepts/ladder-of-nines.md](/concepts/ladder-of-nines.md) and
[/case-studies/waymo-demo-to-product-timeline.md](/case-studies/waymo-demo-to-product-timeline.md).

**2. Required nines dictate architecture.** Every technology has a performance-versus-effort
curve that starts steep and flattens. The failure mode is choosing the fastest early ramp,
extrapolating the slope, then discovering the plateau sits below what your product needs.
Applied to sensing: humans drive with eyes, so vision alone is reasonable for an assist
product or human-parity target — but for strongly superhuman autonomy the safety curve
flattens too early. Waymo fuses cameras, lidar and radar, each with its own encoder, into a
single view. He shows dust-storm, night and occlusion cases where lidar detects pedestrians
the camera cannot. He also notes redundancy is required anyway (a leaf on a sensor should
not stop a robot), so you may as well get complementary physics for free — and warns against
anchoring on today's component prices, since Waymo is on its sixth hardware generation with
cost dropping each time. See
[/concepts/performance-vs-effort-curves.md](/concepts/performance-vs-effort-curves.md) and
[/concepts/sensing-redundancy.md](/concepts/sensing-redundancy.md).

**3. Ride tech waves repeatedly — and unify while you do.** Waymo rebuilt around ConvNets
(~2013), transformers (~2017, for perception *and* for behaviour prediction and planning —
he argues driving resembles language modelling because it is a social conversation conducted
in the body language of a vehicle), and now VLMs and frontier world models. His two pieces of
advice: before starting a tiger team on new tech, be clear what happens under the *success*
scenario, because a successful project with no path into the product is deflating and
wasteful; and demand of every wave not just capability but simplification and unification.
See [/concepts/riding-tech-waves-without-fragmentation.md](/concepts/riding-tech-waves-without-fragmentation.md).

**4. The Waymo foundation model.** A multimodal world-action-language model: multimodal
because it ingests camera, lidar and radar; a world model because it encodes physics,
dynamics and social semantics; an action model because the agent participates and must
distinguish good actions from bad; language-aligned to inherit general world knowledge from
VLMs for the long tail of rare semantic situations. Architecturally an end-to-end
encoder-decoder with a fast path (fused raw sensor data, millisecond reflexes) and a slow
path (scene-level semantic reasoning). His example: a burning car on the shoulder is a
generic obstacle to the fast path with a geometrically clear route ahead; the slow path
understands what it means and reroutes. Capacity is concentrated in the shared foundation so
the on-vehicle specialisation layer stays light. See
[/concepts/fast-path-slow-path-architecture.md](/concepts/fast-path-slow-path-architecture.md).

**5. Structure that channels scale wins; structure that fights scale loses.** His refinement
of the bitter lesson. Thought experiment: a Go-playing robot could learn pixels-to-actuation
end-to-end, but a 19x19 board is a complete, fully observable intermediate representation, so
using it constrains nothing and helps enormously. No such clean representation exists in the
physical world — which is precisely why learned representations are needed — but physics,
road rules and object behaviour are real structure. Waymo's "structure-augmented end-to-end"
augments learned embeddings with materialised structured representations, buying three things:
a real-time correctness and safety validation layer at inference, the ability to train and
evaluate at different levels rather than always end-to-end, and verifiable feedback signals
for RL. See [/concepts/structure-augmented-end-to-end.md](/concepts/structure-augmented-end-to-end.md).

**6. Closed-loop simulation is not tooling; it is a second AI.** Open-loop asks "what would
you do here"; closed loop takes an action, observes the world's response, and continues.
Counterfactuals are vital for safety-critical agents, so the simulator must be a highly
accurate generative world model — a problem as hard as the agent itself. Waymo built
behavioural world models for years and, in the end-to-end era, added sensor realism. He notes
that building end-to-end models became easy well before evaluating them in closed loop did.
Work leverages Google DeepMind's Genie 3, and enables purely synthetic scenarios never seen
in the real world — a stopped car on a freeway, a plane landing ahead, an elephant in an
intersection, snow on the Golden Gate Bridge. See
[/concepts/closed-loop-simulation.md](/concepts/closed-loop-simulation.md).

**7. Build three AIs and a flywheel; steer it with metrics.** The agent, the simulator and
the critic share reasoning and generative capability, so all three are built on the same
foundation world model. Deployment generates data, data grounds the simulator, the simulator
generates harder edge cases, the critic scores them, the agent improves and redeploys. A
flywheel spins in whatever direction you point it, so metrics do the steering. His strongest
claim: models are table stakes, evals and metrics are the strategic moat — build them before
the technology and before the product, because if you cannot quantitatively define "good
enough" you are still iterating on a demo. For physical AI, evaluation must extend past the
model to every component, on-board and off-board, and the operational processes around them
— Waymo's "safety and readiness framework." He argues trust is the ultimate business
advantage: models leak and algorithms are replicated, but hundreds of millions of audited
autonomous miles are not. See
[/concepts/agent-simulator-critic-flywheel.md](/concepts/agent-simulator-critic-flywheel.md) and
[/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md).

# Scale and safety figures cited

Roughly 500,000 trips per week and over 4 million fully autonomous miles per week across
15 US cities; more than 20 million trips and over 200 million fully autonomous miles to
date; 15 years to the first 100 million miles and about 7 months for the next 100 million;
8 years from first rider-only operation to four cities, then four cities launched in a
single day. The published safety analysis covering over 220 million miles reports roughly
17x fewer serious-injury crashes than human drivers in the areas of operation, which he
translates as preventing a serious injury about every 8 days.[^ss26-dolgov]
(Note: the auto-transcript renders the weekly trip figure as "500 trips per week"; it is
reconciled here against his later "half a million trips per week." See
[transcription caveats](/sources/index.md#transcription-caveats).)

# See also

- [/people/dmitri-dolgov.md](/people/dmitri-dolgov.md), [/organizations/waymo.md](/organizations/waymo.md)
- [Chelsea Finn](/sources/chelsea-finn.md) cites Waymo as the existence proof that a
  learned system can be trusted autonomously in the physical world.
- [Jensen Huang](/sources/jensen-huang.md) covers the same simulation stack from the
  supplier side.

[^ss26-dolgov]: Startup School 2026 talk; see raw record [ss26-08-dmitri-dolgov.md](../../raw/ss26-08-dmitri-dolgov.md).
