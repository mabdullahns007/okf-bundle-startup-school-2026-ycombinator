---
type: Video Presentation
title: "Peter Steinberger — Fun Is Velocity"
description: "Eight months of OpenClaw told as five self-posed questions: viral launch, selling out, security-report pressure, losing the fun, and what is next for open agents."
tags: [startup-school-2026, open-source, agents, burnout, security, personal-brand, dependency-risk]
status: draft
resource: https://www.youtube.com/watch?v=whcfSGN6CAU
speakers: [Peter Steinberger]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: \"Fun Is Velocity\""
    author: "Y Combinator"
    last_modified: 2026-08-10
---

# Summary

The most personally candid talk in the playlist, structured as five questions Steinberger
says he is asked constantly and usually answers blandly. It is the closest thing in the
collection to an honest account of what a viral open-source success costs.

# Q1: How is OpenClaw only eight months old?

His stated source of inspiration is being annoyed. On a rainy November evening, juggling
agents and wanting food, he was annoyed that there was no good way to send a prompt from his
phone to his computer, so he let a model build a WhatsApp relay in an hour. What struck him
was not the capability — everyone had been typing into terminals for months — but how it
*felt*: concise, proactive, occasionally checking on him, with the complexity of models,
context sizes and session boundaries hidden, and weights nudged slightly out of the default
distribution so it felt like a friend.

Nobody cared. Despite a large following, week after week he failed to convey it. So he put it
in group chats and watched: every single person had a strong emotional reaction — amazed,
scared, or angry at being told it was not ready for them. He offers that as his product-market-fit
signal. See [/concepts/emotional-reaction-as-pmf-signal.md](/concepts/emotional-reaction-as-pmf-signal.md).

Someone then sent a pull request adding Discord support to a project literally named for
WhatsApp; he sat on it, then relented, and the rename began. The launch itself: he opened a
Discord server in the first week of January, put his agent in it, and stayed up all night
watching people try to hack it, protected only by an instruction in his agents file to avoid
dangerous tool calls unless the prompt came from him. At 7am he pressed Ctrl-C and went to
bed — but he had built it as a resilient launch daemon, so it restarted five seconds later and
happily answered the world for ten hours. He woke to ~800 messages, pulled the plug, read
everything, and found nothing had actually happened. That was the moment it went viral.

What followed: reporters exploiting the iPhone's repeated-call emergency bypass, Mac Minis
selling out, more podcast invitations in a month than in the previous 39 years, a demand to
change the name, and in eight months over 18,000 distinct people opening an issue or PR
(111,000 total) with nearly 3,000 people holding commits. Also: being called both a messiah
and an antichrist, having his phone number leaked, and — he says plainly — coming close to
deleting the whole thing. His summary lesson is *be careful what you wish for*.

# Q2: Did you sell out?

Context: he spent his twenties and thirties bootstrapping a B2B company to nearly 80 people
around a PDF framework, sold his shares, and burned out badly. Three years of aimless
recovery followed; he assumed the urge that returned would be code, and took a year to
realise it was *building* — code was only a means. When labs came knocking he chose the path
he found most interesting, and frames the decision as trusting his gut. The transferable
lesson he draws: anything you build can be forked or cloned, but your name cannot, so work on
your personal brand before you need it. See
[/concepts/personal-brand-as-the-uncloneable-asset.md](/concepts/personal-brand-as-the-uncloneable-asset.md).

# Q3: Did the competitors win?

His answer: they beat him where it hurt, and it was his own doing. Four causes:

1. **Security-report crush.** OpenClaw became a prototype of what many open-source projects now
   experience. He hardened aggressively — sandboxing, allow lists, a permissioned protocol,
   shelling out to Python for file operations because TypeScript lacked primitives for keeping
   an agent in its workspace, not following symlinks, atomic config writes. Users mostly did
   not care: it broke things they depended on, slowed things down, and made updates harder.
   Press reported ~20% of skills as malicious; his team scanned all 67,000 and published a
   paper putting it near 0.3% — and notes a correction never travels as far as a scare.
2. **Configuration sprawl.** Features are the fun part and a new one is a prompt away; the cost
   arrives afterwards. Because he did not want to break anyone's setup, each feature shipped
   with a config option, peaking around 9,500 options. You cannot test all the permutations. His
   line: it is infinitely harder to evolve software that has users. See
   [/concepts/configuration-sprawl.md](/concepts/configuration-sprawl.md).
3. **Divided attention.** Between press, lawyers for a US non-profit, his own role at a lab, and
   a maintainer community he felt he had no standing to direct since they work for free.
4. **Dependency risk — the sharpest lesson.** He built with one toolchain but the harness was
   long optimised for a different lab's model; when that lab gave roughly 24 hours' notice of
   disabling subscription access for everyone, there was no time to change course. Open-weight
   support existed but was not yet good enough, and early open models "lacked character." His
   formulation: *your dependency's business model is your business model*. See
   [/concepts/dependency-business-model-risk.md](/concepts/dependency-business-model-risk.md).

He notes both extremes are true at once: weekly downloads bottomed near 835,000 in May, then
after the project was declared dead in June peaked at an all-time-high 4.7 million. His
metaphor: hype is weather — you may see it coming, you cannot control it.

# Q4: Is it still fun?

Around February it stopped being fun and became responsibility; the man who did not want to
build another company found he had a job and a calling. The worst symptom was that he stopped
using his own product, having drifted from making something he loved to making something for
everyone. In hindsight he could have asked for more help and moved responsibility off his
plate, but was too deep to think strategically. Things realigned gradually — a visa, a
non-profit, corporate donors, good collaborators, and a hardware vendor that simply asked what
he needed and then sent people to take over much of the security work. By around May the joy
was returning. His thesis: the weeks he enjoyed building, the product visibly got better; the
weeks he did not, they shipped config options. See
[/concepts/fun-is-velocity.md](/concepts/fun-is-velocity.md).

# Q5: What is next?

Mission framed as bringing people closer to AI; he is proudest that OpenClaw moved AI from
nebulous and scary to fun and weird for many people. Ten people on payroll and hiring,
including a CEO. Open problems he names: an agent that is genuinely always-on and always
syncing, and moving past text-only interfaces to voice and multimodality (a working
video-call hack the day before). His positioning: every lab will sell you an agent; open
source runs everywhere, works with any model, and with local models your data never leaves
your device. They are rebuilding OpenClaw with OpenClaw again, this time with a shared team
server where everyone sees each other's sessions and an agent that knows what everyone is
working on and can take over orchestration.

His three closing points: don't stop having fun; listen to your gut and fix what annoys you;
stay focused — another podcast is not what makes you win.

# From the Q&A

- **How he builds now.** Sessions are topics, and clearing one is sometimes a disadvantage
  because of the accumulated information. The bigger shift is making agents work proactively:
  he does not want to read issues, he wants fully reviewed and tested PRs. At work he gets
  annoyed if someone brings a feature *idea* rather than discussing it with an agent, building
  it, screenshotting it and letting him play with it — because most of the time people discover
  themselves why it is not good.
- **Loops vs graphs.** He is dismissive of the terminology: engineers have automated things for
  as long as the profession has existed, and anything with a trigger, an input, an action and a
  decision is a graph. Not magical.
- **Reliability with fast shipping.** He admits he got this wrong for a while, partly because
  models were not good at testing. Now, with orchestration trained into models plus computer and
  browser use, he treats it as a QA environment — one recent run used twelve sub-agents to break
  a project into features, stress-test and code-review each, and tell other sessions where to
  focus. He still insists on some manual click-through to know how it feels.
- **Code review as risk management.** His earliest speed decision, which he still lives with, is
  not reading all the code. Scary systems get read closely; UI gets glanced at. Part of it is
  developing a feel for how long something should take — a small drag-behaviour tweak taking
  three hours means something is wrong. See
  [/concepts/code-review-as-risk-management.md](/concepts/code-review-as-risk-management.md).
- **First ten users.** User number one should be you; two through twenty are friends. In an era
  when building is fast, eyeballs are the expensive currency.
- **What he would change.** Be less stressed by security researchers: many reports were
  agent-generated without testing and aimed at credit rather than helping, and he should have
  stated clearly what is and is not inside the project's security boundary.
- **Keeping a project opinionated.** He says he did not say no enough. He now writes a
  `vision.md` explaining what a project is and where it is going, and notes the real cost of
  merging a popular feature is a pile of code the contributor may not fully understand, he does
  not fully understand, and he now owns.
- **Why perpetually-running agents are not here yet.** Not a tech problem but a token problem,
  plus the difficulty of designing something that does not burn empty tokens — static heartbeats
  are too dumb, and calling a heartbeat an hour into a large session after the KV cache has
  cleared means resending hundreds of thousands of tokens for little useful work.
- **Biggest infrastructure gap:** managing compute. One local test spins up sixteen threads; ten
  sessions doing that means timeouts. Cloud sessions are easy for web work and nearly everything
  fails him for macOS. He also names a good, fast, cheap macOS test box as the product he wants
  someone to build.

# See also

- [/people/peter-steinberger.md](/people/peter-steinberger.md), [/organizations/openclaw.md](/organizations/openclaw.md)
- [Jensen Huang](/sources/jensen-huang.md) describes offering NVIDIA engineers to the project and
  calls it a Linux moment; [Garry Tan](/sources/garry-tan.md) names OpenClaw as one of the
  harnesses he runs.

[^ss26-steinberger]: Startup School 2026 talk; see raw record [ss26-05-peter-steinberger.md](../../raw/ss26-05-peter-steinberger.md).
