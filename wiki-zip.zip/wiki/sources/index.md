# Sources

One hub page per talk in the Y Combinator Startup School 2026 playlist
([playlist record](../../raw/ss26-00-playlist.md)), newest first. Each page is the LLM's own
synthesis of that talk, with links out to the concept, case-study, person and organization pages
it feeds.

Full transcript text is **not** stored anywhere in this repository. The `raw/` records hold
metadata, a link and a short factual abstract only.

## Talks

* [Max Junestrand - You Need The Willingness To Learn Faster Than Anyone Else](max-junestrand.md) - Legora from a YC rejection to $100M ARR: paying lawyers for lunch, a deliberate sales freeze, hiring on trajectory, and ambition as a peer effect. *(2026-08-25)*
* [Michael Kratsios - Inside the White House's AI Strategy](michael-kratsios.md) - How federated US tech policy gets made, why hard regulatory thresholds fail, preemption and Little Tech, and a science-policy report in the tradition of Vannevar Bush. *(2026-08-18)*
* [Susan Kare - Designing Icons & Graphics For the Original Mac](susan-kare.md) - Designing inside 16x16 bitmaps, why sparse metaphors outlive literal depictions, and four decades of collected advice. *(2026-08-14)*
* [Chelsea Finn - This is the State of the Art in Robotics](chelsea-finn.md) - A scalable RL recipe for long-horizon autonomy, multi-timescale memory, and a generalist policy that matches fine-tuned specialists. *(2026-08-12)*
* [Peter Steinberger - Fun Is Velocity](peter-steinberger.md) - Eight months of OpenClaw as five self-posed questions: viral launch, selling out, security pressure, losing the fun. *(2026-08-10)*
* [Max Hodak - Average Is Not Good Enough](max-hodak.md) - Purchasing, cost attribution, hiring funnels and continuous eigenvector-weighted reviews as the things that actually set iteration speed. *(2026-08-07)*
* [Garry Tan - Own Your Intelligence](garry-tan.md) - Personal AGI as owned infrastructure: a rented model plus your context library plus a harness, and the politics of extracted cognition. *(2026-08-06)*
* [Dmitri Dolgov - The Demo Is Only 1% Of The Work](dmitri-dolgov.md) - Seven lessons from shipping autonomous driving: the ladder of nines, structure-augmented end-to-end, closed-loop simulation, evals as moat. *(2026-08-03)*
* [Patrick Collison - Is AI Breaking the Lean Startup Playbook?](patrick-collison.md) - The cognitive-cache argument, Stripe's two-year private beta, and aggregate data on business formation roughly doubling. *(2026-07-31)*
* [Jeff Dean - The 1% Rule for Building in AI](jeff-dean.md) - Napkin math, energy as the governing unit, context engineering, where small teams beat general models, and how to build taste. *(2026-07-30)*
* [Alexandr Wang - This is a Once-in-a-Civilization Opportunity](alexandr-wang.md) - First-principles origin of Scale, conviction against consensus, talent density, and vision as the newly scarce input. *(2026-07-29)*
* [Blake Scholl - How 50 People Built a Supersonic Jet](blake-scholl.md) - Treating aircraft engineering as software, demonstrating Mach cutoff, and funding airframe R&D by selling the engine as a ground turbine. *(2026-07-28)*
* [Sam Altman - Never a Better Time to Do a Startup](sam-altman.md) - Being misunderstood for years as a gift, a recent loss-of-control incident, and why concentration of power is the thing to avoid. *(2026-07-28)*
* [Boris Cherny - We Cut 80% of Claude Code's Prompt](boris-cherny.md) - Deleting the harness each model generation, un-hobbling product overhang, and multi-day agent runs. *(2026-07-27)*
* [Jensen Huang - The Mindset That Built NVIDIA](jensen-huang.md) - A wrong founding bet, learning graphics from textbooks, accelerating algorithm domains, and controllability as the agent frontier. *(2026-07-26)*

## Transcription caveats

Every talk in this bundle was captured from YouTube's **auto-generated English captions**, retrieved
programmatically on 2026-09-05. Automatic speech recognition is reliable for prose and unreliable for
proper nouns, so the following normalisations and known uncertainties apply throughout the wiki.

**Normalised with high confidence** (consistent context makes the intent unambiguous):

| Rendered in captions | Used in this wiki |
|---|---|
| Lagora, Lora, Leia, Agora | Legora |
| Manheimr Swartling | Mannheimer Swartling |
| Whimo, WeRide driver | Waymo, the Waymo driver |
| OpenCL (in the Huang talk, discussing a "Linux moment" and contacting "Peter") | OpenClaw |
| PIO7, PIO5, PIO6 | π0.7, π0.5, π0.6 |
| Alpaca My, Alpaca Myo | Alpamayo |
| Bladeunner | Bladerunner |
| Chhat GBT, ChachiBT | ChatGPT |
| imageet | ImageNet |
| IGEN reviews | eigen reviews |
| Yantan, law of yante | Jantelagen, the law of Jante |

**Left uncertain and flagged where used:**

- **Model names.** The Kratsios and Wang talks reference frontier model names that the captions render
  inconsistently ("Mythos", "Fable", "Muse Spark" / "new Spark" / "Meta Spark"). This wiki describes
  the models by role and does not assert specific product names.
- **Company names.** "Judelica" (Legora's predecessor company) and "Retail" (a Winter 24 YC company
  cited by Tan for $60M annualised at ~40 people) are recorded as rendered, with the uncertainty noted.
- **Person names.** YC partners are named where confidence is reasonable (Gustaf Alströmer, Harj
  Taggar, Jared Friedman, Luther Lowe); the partner Junestrand says laughed in his rejected interview
  is left uncertain. Investor first names (e.g. the Benchmark partner) are omitted rather than guessed.

**Numeric corrections made, with the original preserved:**

- **Waymo weekly trips** render as "500 trips per week"; reconciled to ~500,000 against Dolgov's own
  later "half a million trips per week." See
  [/case-studies/waymo-demo-to-product-timeline.md](/case-studies/waymo-demo-to-product-timeline.md).

**Apparent speaker misstatements, flagged rather than silently fixed:**

- Kratsios dates ChatGPT's release to **November 2021**; the actual release was November 2022. Noted in
  [/concepts/regulating-a-moving-frontier.md](/concepts/regulating-a-moving-frontier.md).
- Legora's headcount is given inconsistently (750+ in the talk, 1,300 in a Q&A comparison). Noted in
  [/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md).
- Huang gives the Sega contract as ~$12M and the amount that saved NVIDIA as $5M without explaining the
  difference. Noted in [/case-studies/sega-dreamcast-contract.md](/case-studies/sega-dreamcast-contract.md).

Timestamps are available in the working transcripts but are not reproduced here; per-claim attribution
is at talk granularity via footnotes.
