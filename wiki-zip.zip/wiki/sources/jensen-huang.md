---
type: Video Presentation
title: "Jensen Huang — The Mindset That Built NVIDIA"
description: "NVIDIA's founding algorithm was wrong; the company learned graphics from textbooks and survived on a contract it could not fulfil. On accelerating algorithm domains, fitting the company to the founder, and controllability as the missing agent capability."
tags: [startup-school-2026, hardware, physical-ai, founder-psychology, open-source, agents]
status: draft
resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
speakers: [Jensen Huang, Garry Tan]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Y Combinator"
    last_modified: 2026-07-26
---

# Summary

The opening session of Startup School 2026: an on-stage interview with NVIDIA's
founder and CEO, conducted by [Garry Tan](/people/garry-tan.md). The through-line is
that being wrong about the technology is survivable and being unable to learn is not.

# Key claims

**The founding technology was simply wrong.** NVIDIA started in 1993 intending to turn
every PC into a game console by inventing a new 3D graphics algorithm. By 1995 the team
concluded the algorithm was wrong — and that none of them knew the right way either, by
which point 35 to 40 competitors were building PC 3D graphics. Huang bought three
textbooks on OpenGL and pipeline design and handed them to the engineers.[^ss26-huang]
He draws the general lesson that the specific technology matters far less than the
ability to confront reality and learn — see
[/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md).

**The company's real bet was algorithm domains, not chips.** The durable idea was that
a CPU could be augmented with accelerators to solve otherwise-intractable problems, and
that what you accelerate is an *algorithm domain* — molecular dynamics, fluid dynamics,
image processing, inverse physics, and eventually deep learning — rather than a market
or a product. See
[/concepts/accelerating-algorithm-domains.md](/concepts/accelerating-algorithm-domains.md).

**AlexNet was read as a universal function approximator.** Huang says his lens was always
"what algorithm is this," so the significant thing about AlexNet was not image
classification but that deep learning could learn essentially any function, most
interesting functions being imprecise ones. That reframing set off work on computer
vision, robotics and self-driving roughly fifteen years ago.[^ss26-huang]

**Fit the company to the founder, like an F1 car to its driver.** Asked what happens to
his unconventional management structure when he leaves, Huang's answer is that the next
CEO can reshape the company for themselves; the racer builds the car they can drive. See
[/concepts/fit-the-company-to-the-founder.md](/concepts/fit-the-company-to-the-founder.md).

**Controllability is the biggest missing agent capability.** Huang argues coarse-grained
recursive self-improvement already exists — agents update their markdown files and
long-term memory each run. What is missing is fine-grained control: changing one word in
a plan file, or one via in a layout, and having everything else regenerate around it. He
explicitly does not need agents to be 100% accurate; 80% plus steering is enough if the
steering is precise.[^ss26-huang] See
[/concepts/controllability-as-the-agent-frontier.md](/concepts/controllability-as-the-agent-frontier.md).

**Physical AI has already had its ChatGPT moment.** He dates it to a couple of years
before the talk, on the same logic that early ChatGPT was not useful but opened
imaginations. Generating video of a hand picking up a glass suggested generating robot
articulation; the remaining work is real-to-sim, physics-grounded and generative
simulators, and sim-to-real. NVIDIA's robotics and AV business is described as "probably
almost $10 billion" and expected to become its next $100 billion business in under ten
years.[^ss26-huang]

**AI automates tasks; jobs grow.** Huang argues the job-destruction narrative is
backwards, citing (as his own figures) software-engineering jobs up about 10% year over
year, radiology jobs up about 20%, and paralegal headcount growing — because the backlog
of ideas, patients and cases is enormous, and productivity growth drives employment. See
[/concepts/tasks-are-automated-jobs-grow.md](/concepts/tasks-are-automated-jobs-grow.md).

**Open source as precondition.** He argues modern AI would not exist without Linux,
Kubernetes, Torch, Theano, Caffe and PyTorch, and that everyone should be able to build
their own AI. He describes offering NVIDIA's engineers to the OpenClaw project and doing
similar work with the Hermes team, and says his first-ever post on X in 2026 was
motivated by open-source advocacy.[^ss26-huang]

**Systems thinking is the durable skill.** Because low-level work will be done
agentically, what survives is the ability to reason about a system: constraints, inputs
and outputs, information rates, where the bottleneck actually is. He tells students to
stay in school and go deep on hard sciences and their intersections.[^ss26-huang]

**Resilience and "how hard can it be?"** His closing advice: you will not know the
answers, you never will, and the useful posture is to assume a thing is learnable and
let the difficulty arrive a day at a time rather than as anticipatory anxiety. See
[/concepts/how-hard-can-it-be.md](/concepts/how-hard-can-it-be.md).

# Case studies drawn from this talk

- [/case-studies/sega-dreamcast-contract.md](/case-studies/sega-dreamcast-contract.md) —
  the contract NVIDIA could not fulfil, and asked to be paid for anyway.

# See also

- [/people/jensen-huang.md](/people/jensen-huang.md), [/organizations/nvidia.md](/organizations/nvidia.md)
- Physical AI overlaps heavily with [/sources/dmitri-dolgov.md](/sources/dmitri-dolgov.md)
  and [/sources/chelsea-finn.md](/sources/chelsea-finn.md).
- The "own your own AI" thread is the same argument as
  [/sources/garry-tan.md](/sources/garry-tan.md).

[^ss26-huang]: Startup School 2026 talk; see raw record [ss26-15-jensen-huang.md](../../raw/ss26-15-jensen-huang.md).
