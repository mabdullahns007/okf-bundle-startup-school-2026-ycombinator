---
type: Video Presentation
title: "Jeff Dean — The 1% Rule for Building in AI"
description: "Napkin math as a design tool, energy as the governing unit, context engineering and skills, where small teams beat general models, and how to build taste."
tags: [startup-school-2026, systems, hardware, agents, context-engineering, taste, research-method]
status: draft
resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
speakers: [Jeff Dean]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Y Combinator"
    last_modified: 2026-07-30
---

# Summary

An interview with Google's chief scientist, ranging over hardware economics, agent
design, problem selection and research taste. The most technically dense session in
the playlist alongside [Dmitri Dolgov](/sources/dmitri-dolgov.md).

# Key claims

**Last year's prediction landed; this year's is automated experimentation.** Dean had
said models were at the level of a junior engineer; he judges that roughly right, and
says he underestimated how fast the complexity of tasks would grow. His 2027 prediction
is automation of ML research itself: decomposing problems into sub-problems, running
tight automated experimentation loops, and reassembling improved systems — extending to
any field with a measurable objective.[^ss26-dean] See
[/concepts/automated-experimentation-loops.md](/concepts/automated-experimentation-loops.md).

**Napkin math as a design method.** Two worked examples appear in
[/case-studies/tpu-napkin-math.md](/case-studies/tpu-napkin-math.md). His advice is to
identify bottlenecks and ask whether a first-principles approach gets one or two orders of
magnitude, rather than anchoring on how the problem is solved today. See
[/concepts/napkin-math.md](/concepts/napkin-math.md).

**The AI-era update to the latency numbers list.** Dean says the numbers now worth
internalising are bandwidth from accelerator main memory to on-chip memory to the
multiplier unit, the energy of a single multiply, interconnect bandwidth between chips
and how many chips that bandwidth spans, and how network bandwidth falls off at ten
thousand chips versus five hundred.[^ss26-dean]

**Energy is the unit, and data movement dominates.** A single arithmetic operation costs
on the order of a picojoule; bringing the operand in from high-bandwidth memory costs
roughly a thousand times that. He points out that this single ratio is why batching exists
— you amortise the movement across a batch — and therefore why very low-latency serving is
hard. His framing: founders often call these model problems when they are energy or I/O
problems. See [/concepts/energy-and-data-movement.md](/concepts/energy-and-data-movement.md).

**Inference is where he is now spending thought.** Minimising data movement, very low
precision, and possibly supporting only the precisions you actually need. He notes
specialisation gives large wins precisely because it forecloses generality.[^ss26-dean]

**Context is clearer to a model than training data.** Training data is stirred into a soup
of parameters; the context window is unambiguous. So the system around the model —
retrieval, tools, memory, decomposition into tool calls, trying multiple approaches and
evaluating them — is most of what determines capability. Crucially, this is the layer
anyone with an API key can work on. See
[/concepts/context-engineering.md](/concepts/context-engineering.md).

**Skills are how you encode your own method.** Dean's example: he and Sanjay Ghemawat
wrote a skill teaching a model the loop they use for low-level performance work — measure
a microbenchmark, modify, re-measure, widen the benchmark set, measure cache footprint,
iterate — which then ran self-improvingly. He also mentions a roughly 30-page internal
"performance hints" document that people have summarised into model context to improve
performance reasoning. See [/concepts/skills-as-encoded-method.md](/concepts/skills-as-encoded-method.md).

**Why agents derail.** Partly because they leave the distribution of what they have
practised; the further out, the faster performance degrades. Remedies: skills and hints
that keep the model on well-lit paths, and multi-agent search where several approaches are
tried and another model judges which are promising — inference-time compute spent searching
the solution space. See [/concepts/why-agents-derail.md](/concepts/why-agents-derail.md).

**Where a two-person team still wins — the 1% rule.** General models get better at
everything, so test the current general model on your domain: if it fails essentially 0–1%
of the time it succeeds, that is a good sign; if it half-works at 20%, the capability is
already emerging and will improve. Two structural advantages he names are access to data
the general model cannot see (organising *your* personal information rather than the
world's), and narrow models that are cheap to train but highly accurate, on the AlphaFold
pattern. See [/concepts/the-one-percent-rule.md](/concepts/the-one-percent-rule.md).

**Specification became more important, not less.** Managing many agents is writing crisp
design docs. His illustration of a perfect specification is translating software between
languages: the existing implementation plus its tests *is* the spec, which is why models
are so good at it. See [/concepts/specification-as-the-new-source.md](/concepts/specification-as-the-new-source.md).

**Taste is the scarce skill, and it is trainable.** Three methods he offers: accumulate
experience across many problems; write down what you think will matter in the next twelve
months, then grade yourself later against what the world actually built; and run deliberate
thought experiments that question long-standing assumptions. His example of the third: what
if you built systems from transistors with twenty errors per day instead of one per million
years — the way we already build reliable distributed storage from unreliable disks? He is
explicit that most such experiments fail for good reasons, and that revisiting is still
worth it. See [/concepts/taste-as-the-scarce-skill.md](/concepts/taste-as-the-scarce-skill.md).

**Fast evaluators change what science is possible.** Colleagues trained a neural surrogate
on the inputs and outputs of an expensive density-functional-theory simulator, getting
something roughly 300,000 times faster and nearly as accurate — turning a six-month
screening endeavour into a lunch break. See
[/concepts/learned-surrogate-evaluators.md](/concepts/learned-surrogate-evaluators.md).

**Rejection is normal.** The distillation paper was rejected with a reviewer comment that
it was unlikely to have significant impact; they posted it, people used it, and it now
underlies the smaller fast models in production. See
[/case-studies/distillation-paper-rejection.md](/case-studies/distillation-paper-rejection.md).

**Open problems he names:** more efficient inference hardware, radically more data-efficient
learning algorithms (frontier models see perhaps a thousand times more data than an
18-year-old, who is still better at many things), continual learning, and multi-agent
interaction.

# See also

- [/people/jeff-dean.md](/people/jeff-dean.md), [/organizations/google-deepmind.md](/organizations/google-deepmind.md)
- On skills and specification, converges with [/sources/boris-cherny.md](/sources/boris-cherny.md)
  and [/sources/garry-tan.md](/sources/garry-tan.md).

[^ss26-dean]: Startup School 2026 talk; see raw record [ss26-10-jeff-dean.md](../../raw/ss26-10-jeff-dean.md).
