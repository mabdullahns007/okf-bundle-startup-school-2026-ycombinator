---
type: Video Presentation
title: "Max Hodak — Average Is Not Good Enough"
description: "Internal infrastructure — purchasing, cost attribution, hiring funnels, continuous eigenvector-weighted reviews — as the thing that actually sets iteration speed in deep tech."
tags: [startup-school-2026, infrastructure, iteration-velocity, hiring, performance-review, biotech, judgment]
status: draft
resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
speakers: [Max Hodak]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Y Combinator"
    last_modified: 2026-08-07
---

# Summary

A deliberately unglamorous talk. Hodak opens with Picasso's line that art critics discuss
form and meaning while artists discuss where to buy cheap turpentine, and its military
restatement — amateurs talk strategy, professionals talk logistics — then argues that in
deep tech the logistics *are* the strategy.

His premise is that there are very few genuinely general lessons in startups: mostly you
face a stream of facts and make the best local decision, and inconsistency across weeks is
usually correct. The exceptions are the universal experiences, which is what the talk covers.

# Buying things

The naive view is that software founders never buy anything. Everything else buys thousands
of things continuously. Hodak walks the escalation: the founder uses a credit card; hand
cards to everyone and you start approving purchases one at a time; then someone asks for a
$3,000 power supply and you wonder whether an auction in three days would halve it. His
resolution is that with a $100,000-a-week burn, waiting a week to save $1,500 has already
destroyed the saving — and that a frontier lab's engineer would simply have the power supply.
The real conclusion is that purchase approval is the wrong place to exercise spending review:
review belongs earlier, in budgeting, so people understand the resources they have and make
trade-offs inside them. He then walks the next failure — a procurement system that has highly
paid engineers clicking through B2B portals while vendor accounts, insurance and certification
paperwork stretch delivery to two weeks — and concludes that people whose job is purchasing
genuinely exist for a reason, and that active management to metrics is what makes it fast.
His summary of Science's reputation for speed: it is mostly not that they are smarter, it is
infrastructure like this. See
[/concepts/procurement-and-budgeting-as-infrastructure.md](/concepts/procurement-and-budgeting-as-infrastructure.md).

# Cost attribution

The subtler problem is that bulk purchasing destroys attribution. Gases, resins and media get
parted out across many experiments, so nobody knows what an experiment costs — and therefore
experiments feel free, because they cost media, and media comes from the fridge. Science built
internal software (Helix) in which every step performed in the lab is a database record, so
costs correlate through: one wafer iteration on a given protocol came to $40,000. He then does
the arithmetic that makes this matter: a $20M Series A meant to last four years, with roughly
half of burn being headcount (~20 people, ~$3M/year) and 20,000 square feet at about $4 per
square foot per month adding another $750K–1M a year, leaves roughly a $3M annual research
budget — which goes far faster than founders expect, especially when a team that just watched
you raise more money than they have ever seen assumes $3,000 power supplies are free. See
[/concepts/cost-attribution-in-physical-r-and-d.md](/concepts/cost-attribution-in-physical-r-and-d.md).

# Hiring

Hodak argues the best companies emerge from *scenes* — a moment that enables a company, with
an extended community around the founding team that should be the target of initial recruiting
marketing. There are never enough of those people, so you must hire from the general public,
and there is no single right process but a definite wrong answer: not having one you follow
religiously.

Science's four stages, with their actual conversion rates:

1. **Company-wide voting.** Applicants apply through internal software; the system picks seven
   or eight current employees whose backgrounds resemble the applicant's and asks each to vote
   (known good / strong yes / yes / no / strong no). This distributes an overwhelming top of
   funnel and averages over judgment; commercial applicant-tracking systems could not do it,
   which is why they left Greenhouse. Turnaround is usually 24–48 hours.
2. **Phone screen** — 17% of applications reach it, drawn from a company-wide pool against a
   company-wide bar, testing three things: judgment (thrown into a vague complex situation, do
   you make good decisions or create diplomatic incidents), horsepower, and agency (are you
   effective at making the world look like you wish it were).
3. **Homework** — about half of phone screens. He wants AI-resistant homework: tasks that do
   not saturate, have a very high ceiling, and score to two or three numbers you can plot, so
   beating the frontier is visually obvious and it does not matter which models you used. His
   cited example of the genre is GPU-kernel optimisation with a model's performance as the bar.
4. **Full interview**, which must convert to an offer at 25% or better or you are wasting the
   team's time.

He describes this as the minimum information needed for a decision, not an optimum. See
[/concepts/distributed-hiring-funnel.md](/concepts/distributed-hiring-funnel.md) and
[/concepts/hiring-for-evidence-of-exceptional-ability.md](/concepts/hiring-for-evidence-of-exceptional-ability.md).

# Eigen reviews

His critique of annual 360 reviews: disruptive, and they mostly re-surface issues you already
knew about but had not acted on because firing is hard. What you want instead is a continuous,
largely unbiased signal. See
[/case-studies/eigen-reviews-at-science.md](/case-studies/eigen-reviews-at-science.md) for
the mechanism, including the PageRank-style weighting and the dropout trick for detecting
voting cliques.

# The theme

**Rate of iteration separates success from failure**, and the effect is severe enough that a
competitor learning one thing a week beats one learning one a month regardless of other
merits — so between two approaches, strongly prefer the shorter loop even when the alternative
has real redeeming qualities. And **speed is determined by infrastructure**: purchasing,
recruiting, spending, quality, budgeting and safety are the operating system of the company.
His observation is that deep-tech companies founded by excellent scientists usually die not
because the technology failed but because a few hundred people and hundreds of thousands of
square feet became unmanageable and strategy could no longer connect to execution. See
[/concepts/iteration-velocity-as-the-master-variable.md](/concepts/iteration-velocity-as-the-master-variable.md).

# Two harder lessons

**You cannot delegate your judgment.** In school, copying your neighbour drags your grade
toward the class average; in startups the average is not good enough, because successful
companies are the exceptions. So your judgment must be differentiatedly good — and you may not
know yet whether it is. He describes the eerie specific moment: four or five years in, hundreds
of millions on the line, one decision only you can make, you look for advice and there is
nobody to ask. See [/concepts/judgment-cannot-be-delegated.md](/concepts/judgment-cannot-be-delegated.md).

**Action produces information.** He means this physically: a thrown ball follows a ballistic,
information-minimising trajectory unless action is exerted on it, so injecting action into the
world creates information. His counterintuitive corollary is that when a company is stuck in a
local minimum, removing someone individually strong but wrong for the moment can unblock it.
See [/concepts/action-produces-information.md](/concepts/action-produces-information.md).

# From the Q&A

- **PhD vs industry.** When a field starts to really work, industry marshals vastly more
  resources — the best rocket engineers moved from NASA and universities to SpaceX and Blue
  Origin. If your field exists only in basic research, a PhD makes sense. Otherwise he leans
  toward a high-performing company adjacent to where you want to be, partly because startup
  culture is an oral tradition passed down rather than rediscovered from first principles.
- **What counts as evidence of exceptional ability.** Ideally winning at legible competitive
  games — chess, Formula SAE, design-build-fly — because it is hard to know you are exceptional
  without competitive feedback. They increasingly evaluate thinking (can you decompose a
  domain clearly) rather than programming.
- **What he took from Neuralink.** Working alongside someone with empirically excellent
  judgment, where you could bring a real two-option decision with stakes attached and get
  feedback — which he calls an underrated part of an entrepreneur's education.
- **Why build rather than buy.** Nobody loves their ERP. He cites YC's own internal software,
  Facebook's internal tools, and SpaceX/Tesla's Warp Speed as cases where a company grew up
  around software fitted to it. His key point: this was economically unreasonable before
  agents, and has changed — though he concedes that telling your board you will vibe-code a
  purchasing system after a Series A would normally draw questions, and that he only got away
  with it because he controls the company. See
  [/concepts/internal-software-as-competitive-advantage.md](/concepts/internal-software-as-competitive-advantage.md).
- **Runway sizing.** Founders often pitch what they think is reasonable to ask for rather than
  what the experiment costs. Some ideas are worth $50M or $0 but not $5M, because $5M buys an
  ambiguous outcome. Price out the next value inflection point, then raise twice that; 20–30%
  waste is fine. He also argues for pushing toward profitability sooner than founders think —
  Science is "relentlessly focused on revenue" despite a long roadmap — so you are valued on
  your roadmap rather than your probability of dying.
- **AI's impact at Science.** Coding (he has barely looked at source in six months),
  regulatory and quality systems (finding applicable standards and generating compliance
  evidence tables, work that historically took months), and making all company context
  available to agents — a multiplier, not a replacement. His view on regulation is notably
  non-standard: much of it is written in blood and largely sensible, and the real problem is
  that humans are bad at reading and interpreting it. See
  [/concepts/ai-native-company-context.md](/concepts/ai-native-company-context.md).
- **Two cultures in one company.** He estimates SpaceX circa 2018 was ~20% committed Martian
  colonists and ~80% serious engineers who think those people are lunatics and want to build
  the world's best engines — and that you need both. Science is ~30% overtly transhumanist,
  ~70% clinicians and researchers who think the first group is crazy. See
  [/concepts/two-cultures-in-a-mission-company.md](/concepts/two-cultures-in-a-mission-company.md).
- **On BCIs.** He argues neural engineering is broader than motor decoding and is really a
  longevity and healthcare story: direct interfaces to the brain produce effect sizes medicine
  rarely sees — a deep brain stimulator turning on, a cochlear implant switched on for a
  newborn — without first solving biology problems beyond current capability. Open engineering
  problems he names: implant power and thermal limits, and *packaging* (keeping the device in
  and the body out), where the classic laser-welded titanium can does not fit in an eye.

# Product context

Science's lead product is a subretinal photovoltaic implant restoring vision after loss of rods
and cones: hex-grid solar cells under the retina, glasses with a camera and an infrared laser
projector, absorbed light creating local fields that excite the retina directly. It has been
through three clinical trials; one patient finished a 300-page novel and mailed the team the
book. The underlying technology was invented by a Stanford professor about fifteen years
earlier and licensed to a European company that Science eventually acquired.

# See also

- [/people/max-hodak.md](/people/max-hodak.md), [/organizations/science-corp.md](/organizations/science-corp.md)
- Same core claim as [/sources/blake-scholl.md](/sources/blake-scholl.md): speed comes from
  owning your own tooling.

[^ss26-hodak]: Startup School 2026 talk; see raw record [ss26-06-max-hodak.md](../../raw/ss26-06-max-hodak.md).
