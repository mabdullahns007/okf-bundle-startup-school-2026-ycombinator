---
type: Video Presentation
title: "Max Junestrand — You Need The Willingness To Learn Faster Than Anyone Else"
description: "Legora from a YC rejection to $100M ARR: paying lawyers for lunch, a deliberate sales freeze, a product manifesto, hiring on trajectory, and ambition as a peer effect."
tags: [startup-school-2026, go-to-market, culture, hiring, evals, storytelling, europe]
status: draft
resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
speakers: [Max Junestrand, Gustaf Alströmer]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Y Combinator"
    last_modified: 2026-08-25
---

# Summary

A founder's narrative talk plus a long Q&A with a YC partner. Legora is described in the YC
two-sentence form as an agentic operating system for lawyers handling complex legal work
end to end.

The headline numbers are in
[/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md).

# The founding

The company did not start with him. In 2020, before GPT and before AI was fashionable, a
lawyer, a physicist, an engineer and a psychologist started a company (rendered "Judelica" in
the auto-transcript) after observing that law students spent internships summarising court
cases, and began exploring what was possible with early Google BERT models. Junestrand met two
of his eventual co-founders at a volleyball game in the Swedish archipelago and was shown a
GPT-3.5-era demo that could explain what a stock option agreement meant. He offered to help,
helped rather more than that, and dropped out of his master's because the opportunity cost of
not building had become too large — he calls GPT-3.5 his generation's internet moment.

# Customer discovery by paying for lunch

Knowing nothing about law, they cold-emailed lawyers found on firm websites and messaged them on
LinkedIn asking for lunch to learn about their practice areas — *offering to pay their hourly
rate*. Many accepted; many waived the fee; some paid for lunch. Then they approached one of the
largest Nordic firms, whose managing partner had said on television two years earlier that AI
was more artificial than intelligent. They eventually moved into that firm's offices, working
from a windowless conference room where the air conditioning switched off at 5pm — an engineer
would fan the door for oxygen — before moving to a real office three years later. His two
takeaways: do not take no for an answer, and the sheer power of asking for help, because it is
valuable to be a person and a company that others want to see succeed. See
[/concepts/customer-discovery-by-paying-for-access.md](/concepts/customer-discovery-by-paying-for-access.md).

**Why law is unforgiving.** His formulation: in law you are not paid when things go right, you
are punished when things go wrong. Earlier AI tools in the space demanded enormous training
input for very little output, which is what GPT-3.5 changed.

# The YC rejection

They applied in May 2023 promising to let users query all legal documents with language models.
Asked in the interview what type of lawyers they served, they answered by asking whether there
were different types of lawyers. A partner laughed and they knew they were finished. They were
rejected, got back to building the day after next, did the work, and were accepted two months
later under a new name with a different platform. Once inside, he says, they realised they knew
more than they thought. See [/concepts/rejection-as-signal-vs-noise.md](/concepts/rejection-as-signal-vs-noise.md).

# The sales freeze

Three weeks after a $9.51M Benchmark round, a Redpoint pre-emptive Series A followed. With about
$35M in the bank and ten people, there was a month in which interest income exceeded customer
revenue — which he flags as a bad sign, because you have become a bank. At their first board
meeting they froze the sales motion for six months, on the reasoning that with lawyers you get
one chance: if the product fails, latency is high, or the system falls over under load, you are
finished. The $1M → $100M curve began after that freeze. See
[/concepts/deliberate-sales-freeze.md](/concepts/deliberate-sales-freeze.md).

# The product manifesto

Early on, product decisions were made by democratic vote across the whole team — which he notes
produces the too-many-cooks outcome, and left them spread across too many features while needing
to rebuild everything for the post-freeze launch. In October 2024 they wrote a product manifesto:
everything learned condensed into one simple document shared with the then-25-person team. At the
time they were at about $1.3M ARR while competitors were at ten times that with products having
only one of their features. He explicitly links the ability to move to the US and compete for the
largest logos to that product refocus, and adds that a Swedish home market is too small to house
a unicorn. See [/concepts/product-manifesto.md](/concepts/product-manifesto.md).

The platform had to be built to be adaptable to constantly shifting foundations — both the
underlying models and the agent frameworks.

# People and culture

His strongest claim is that engineers over-index on product and tech: building a product is one
thing, building a company is another.

**The hiring pattern they had to unlearn** was optimising for prestigious resume logos — what they
call *y-intercept*. Someone's skill curve may start high, but without an upward trajectory they
struggle in a company scaling exponentially. So they looked for people like themselves: willing
to work extremely hard, with high growth potential, and doubled down repeatedly on that profile.
Their top salesperson at the time of the talk was 23, had no sales background, and had sold over
$10M. See [/concepts/hire-for-slope-not-intercept.md](/concepts/hire-for-slope-not-intercept.md).

**Founder-led interviewing.** He personally interviewed every non-engineering candidate up to
about 500 people, and every director and above thereafter, and describes the culture as now
self-selecting.

**Values:** lean in, fight for excellence, grow together — deliberately arranged as LFG. He notes
the profanity itself signals to people from more established backgrounds what they are joining.

**Fighting Jantelagen.** The law of Jante — you should not think you are somebody, or that your
ideas are better than anyone else's — is, he argues, partly good: it supports a culture where the
best ideas win and junior people speak up. But it is very hard to build one of the fastest-growing
enterprise companies in the world while believing you are nobody. So they built a cocktail of US,
European and Asian culture. See
[/concepts/culture-against-local-norms.md](/concepts/culture-against-local-norms.md).

**Winner-take-most posture.** A press article summarised their stance as: there is only winning,
everything else is losing, and there is no place for number two. He says Legora had no reason to
exist — one of many legal AI companies — and that the mentality of never feeling safe despite
extraordinary numbers is what carried it. His image is professional swimmers looking down their
own lane while the competition looks sideways. He also recounts a Swedish idiom about waking with
the taste of blood from excitement, which an English-language article rendered literally, prompting
jokes about vampires and flossing and becoming internal shorthand.

**Stockholm as a superpower.** Everyone globally onboards in Stockholm, which he credits for the
same feel in every office worldwide. His illustrating anecdote: a large US firm had a document-drafting
problem a competitor had promised and failed to solve; a US-based legal engineer flew to Stockholm,
spent a week with engineers, solved it there, and delivered it back.

# The closing argument

He deliberately declines the big lessons, noting he shares the stage with people who have built at
far greater scale. His point instead: almost nothing that mattered happened at the signing of a big
client or a financing round. It happened in a windowless room, on a call to the airport, in a Slack
channel at 2am fixing a bug before a Monday presentation. Nobody puts that in a pitch deck, and you
should not wait for the big moments — you have to love the hustle. See
[/concepts/love-the-hustle.md](/concepts/love-the-hustle.md).

# From the Q&A

- **Does domain expertise matter?** A Swedish VC passed on the pre-seed because there were no
  lawyers on the team and, he says, later described the company as their lesson. His answer: you
  need a *willingness to learn* about the market — which they bought by spending as much time with
  lawyers as possible — not domain expertise, though he allows quantum computing or fusion would
  differ. See [/concepts/willingness-to-learn-over-domain-expertise.md](/concepts/willingness-to-learn-over-domain-expertise.md).
- **Building on a model that is not good enough yet.** Tribal knowledge in 2022–23 said fine-tune,
  and he cites a large financial-data company spending heavily on its own legal model. Legora bet
  the models would keep improving — partly from conviction, partly from having no money — and
  focused on delivering the value models generate to their market. His first sale was essentially
  "we are ChatGPT but compliant in Europe," which he concedes was a weak pitch that the labs would
  later obviate, but was good enough then. His formulation: build for the world today and maybe one
  step ahead, and treat it as a ladder where good customer relationships let you ride capability
  improvements. He estimates they have built 1% of the software they will ever build. See
  [/concepts/build-one-step-ahead-of-the-models.md](/concepts/build-one-step-ahead-of-the-models.md).
- **Models and evals.** He argues the core muscle to build is the ability to *evaluate use cases*,
  because that is what lets you route effectively. Legora hired lawyers whose job was partly
  customer-facing and partly building use cases to run evals against. Their user base splits: some
  want the most intelligence possible on long-running complex problems, because token spend is tiny
  relative to human expertise on complex litigation; others want cheaper open models. He notes they
  released their internal benchmark publicly, having kept it private for three years because when
  only two labs' models were worth offering there was nothing interesting to publish; with a wider
  field they found one model surprisingly strong on cost-adjusted performance but could not yet
  offer it for lack of a data-processing agreement. Banks and large firms often refuse Chinese
  models. He also flags compute contracts with labs and providers as a real dependency when a
  meaningful share of the world's lawyers rely on your uptime. See
  [/concepts/eval-driven-model-routing.md](/concepts/eval-driven-model-routing.md).
- **When to start.** His father had two companies that went to zero after raising too much venture
  capital during the dot-com era, then a boat business; he speaks to him near-daily and calls him a
  senior adviser who once made the deck for a major customer pitch. He was set on McKinsey — which
  he still rates for learning how to work — until GPT arrived. He notes that pre-GPT most startup
  ideas he could think of were boring, and that small companies suddenly gained a large advantage
  over big ones; he recalls being terrified when Microsoft shipped Copilots into Word and Outlook,
  and that it did not work.
- **How you learn.** His formulation: the amount you learn is a function of the discomfort you are
  willing to endure. He was introverted, wanted only to code, and found customer conversations and
  first firings genuinely hard.
- **Space vs problem.** He says they picked a *space* rather than a problem: it was obvious legal
  and AI would be a thing, and entirely unclear how, so they marched in a general direction. The
  alternative is finding a specific problem, solving it, generating ROI and expanding.
- **How to become more ambitious.** His answer is a peer group. He was lazy in his final school
  years and first two college years, playing a lot of Dota, and did not know how big the world was;
  a new friend group of ambitious people made it click and he went from zero internships to eight
  jobs in a year. He names this as one of the best parts of YC and says Legora now works that way
  internally — the CFO challenging marketing to be more ambitious — with the compounding coming from
  assembling that group across the whole company rather than at the top. See
  [/concepts/ambition-as-a-peer-effect.md](/concepts/ambition-as-a-peer-effect.md).
- **The most valuable skill: storytelling.** He says he badly underappreciated it. You must sell the
  company to yourself, because working this hard without believing your own story is very hard; then
  to employees, competing with the labs for talent; then to investors and customers. He admits he
  does not know how to teach it and suspects he learned it through exposure and liking stories. He
  also volunteers that he used to be a bad teammate — yelling at volleyball teammates who missed
  serves — and had to change, because that invites neither followership nor good vibes. See
  [/concepts/storytelling-as-the-core-ceo-skill.md](/concepts/storytelling-as-the-core-ceo-skill.md).
- **On technical skills.** Velocity and the ability to iterate on customer feedback remain the most
  important. He still drops customer problems from calls into the product channel and asks how fast
  they can turn it around — which he grants is strange at a thousand-person scale — while warning
  against zigzagging away from the vision. And: producing a lot of code with AI is not an excuse for
  not being a very good software engineer.
- **Hardest current problem:** the transition from reactive to proactive agents. Instead of
  prompting Legora, context is connected so that a trigger starts work — a contract arriving at the
  sales team routes to an agent that works on it in parallel and escalates to a lawyer only if
  needed, or a whole data room is connected and the agent organises it and produces the due
  diligence report. The stated unlock is one lawyer producing the output of ten. He also mentions
  spending very large sums on OCR and document parsing as a genuine engineering problem at scale.
- **Re-qualifying for the job.** He tells his executive team he must re-qualify as CEO every
  quarter, because running a sales team at $1M ARR differs entirely from $150M. The difficulty he
  names is that very few people have done it this fast: executives arrive from a SaaS world where
  40% annual growth is on track, and Legora is compressing four years into one. His remedies:
  put the company ahead of your ego, be brutal at saying no, and know where your own edge is. See
  [/concepts/mini-games-and-requalifying.md](/concepts/mini-games-and-requalifying.md).
- **The Jude Law campaign.** An agency pitched remaking famous legal movie scenes on the premise
  that with Legora the movie would be over in a minute; someone then connected "AI-powered law" to
  the actor's name. He reports the actor initially thought it unserious, that Hollywood is currently
  fairly anti-AI, and that persistence won — he calls nagging an underappreciated form of
  negotiation, learned from his father. The condition was that the actor choose his own
  screenwriter and cinematographer, who turned out to be an SNL script director and the
  cinematographer of *Oppenheimer*; nobody from Legora was allowed on set. Its value, he says, was
  making the company known outside law.

# See also

- [/people/max-junestrand.md](/people/max-junestrand.md), [/organizations/legora.md](/organizations/legora.md)
- The eval argument matches [/sources/dmitri-dolgov.md](/sources/dmitri-dolgov.md); the
  ambition-as-peer-effect argument matches [/sources/sam-altman.md](/sources/sam-altman.md).

[^ss26-junestrand]: Startup School 2026 talk; see raw record [ss26-01-max-junestrand.md](../../raw/ss26-01-max-junestrand.md).
