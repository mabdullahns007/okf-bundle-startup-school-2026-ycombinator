---
type: Video Presentation
title: "Boris Cherny — We Cut 80% of Claude Code's Prompt"
description: "Deleting the harness each model generation, un-hobbling product overhang, giving models tasks slightly too hard plus a way to verify themselves, and multi-day agent runs."
tags: [startup-school-2026, agents, harness-design, evals, prompt-injection, coding]
status: draft
resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
speakers: [Boris Cherny]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Y Combinator"
    last_modified: 2026-07-27
---

# Summary

An interview with the creator of Claude Code, recorded the day after an Opus 5 release.
It is the most operationally specific talk in the playlist about how to build on top of
frontier models, and its advice is consistently the opposite of conventional software
engineering discipline.

# Key claims

**Prompt injection is addressed in layers, not by one fix.** Cherny describes three:
a model aligned against following injected instructions (the product of roughly three
years of alignment research), a prompt-injection classifier run over all traffic that is
based on mechanistic-interpretability work and watches neurons that activate when
injection occurs, and an auto-mode classifier. His claim is that with all three they can
no longer demonstrate prompt injection.[^ss26-cherny]

**Delete the system prompt every model generation.** The Claude Code harness is
continually rewritten; each new model prompts deletion of much of the system prompt and
changes to the tool set and tool prompts. For Opus 5 they removed over 80% of the system
prompt because the model already did what the prompt had been correcting for. He notes
the product is *more* intelligent with no prompts at all, but that some prompts exist to
make the product behave the way a person would want. See
[/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md).
He extends the advice to users: every six months, delete your `CLAUDE.md`, your skills
and your hooks, and see what happens.[^ss26-cherny]

**Evals outlive harnesses, but not by much.** Evals survive maybe one to three model
generations before being saturated and thrown away. See
[/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md).

**Product overhang and un-hobbling.** The central framing of the talk: at any model
generation the model can already do things no product lets it express (overhang), and
products routinely get in the way (hobbling). The original Claude Code was exactly this
move — contemporary coding products did single- or multi-line autocomplete and read-only
chat, while Sonnet 3.5 could already write whole files, so the product was stripped to
the simplest possible harness. Cherny's claim is that today's overhang is far larger and
that startups are not capturing it. See
[/concepts/product-overhang-and-unhobbling.md](/concepts/product-overhang-and-unhobbling.md).

**Give the model a task slightly too hard, plus a way to verify itself.** He names
over-specification as the most common failure, especially among experienced engineers:
describe the task, the guardrails and the exit criteria, then let it run. Verification is
"the single most important thing that people do not get right."[^ss26-cherny] See
[/concepts/verification-loops-over-specification.md](/concepts/verification-loops-over-specification.md).

**Runs now last days to weeks.** Two worked examples appear in
[/case-studies/bun-zig-to-rust-rewrite.md](/case-studies/bun-zig-to-rust-rewrite.md) and
[/case-studies/electron-to-swift-two-week-run.md](/case-studies/electron-to-swift-two-week-run.md).

**Dynamic workflows are a new axis of test-time compute.** Beyond parameters, data,
training FLOPs and generated tokens, Cherny describes orchestration itself as a scaling
axis: an "algebra for agents" with sequential and parallel composition running inside a
sandboxed runtime, fanning out, verifying, summarising and fanning out again. See
[/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md).

**Codebases can maintain themselves.** Anthropic runs roughly 20–30 recurring routines a
day across its CLI, iOS, Android and desktop codebases — deleting dead code, shipping
fully-rolled-out experiments, adding and removing tests, and an "abstraction police"
routine that unifies near-duplicate abstractions. Each is about one sentence of prompt.
See [/concepts/self-maintaining-codebases.md](/concepts/self-maintaining-codebases.md).

**"Coding is solved" — with caveats.** Cherny qualifies it as solved for the kind of
coding he does, and names deep systems code, distributed systems and pixel-exact UI
verification as still hard.[^ss26-cherny]

**What to still learn by hand.** He learned to program on a TI-83 calculator to do
better on maths tests, then had to learn assembly when the maths got harder. His advice
is to learn computer science *applied* — design sense, business sense, data science,
talking to users — because that is where it becomes valuable.[^ss26-cherny]

# See also

- [/people/boris-cherny.md](/people/boris-cherny.md), [/organizations/anthropic.md](/organizations/anthropic.md)
- Sharply consistent with [/sources/jeff-dean.md](/sources/jeff-dean.md) on skills and
  specification, and with [/sources/peter-steinberger.md](/sources/peter-steinberger.md)
  on treating agent work as risk management rather than line-by-line review.
- Contrast: [/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md)
  sits in tension with [/concepts/personal-context-as-a-compounding-asset.md](/concepts/personal-context-as-a-compounding-asset.md).

[^ss26-cherny]: Startup School 2026 talk; see raw record [ss26-14-boris-cherny.md](../../raw/ss26-14-boris-cherny.md).
