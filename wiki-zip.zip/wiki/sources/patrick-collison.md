---
type: Video Presentation
title: "Patrick Collison — Is AI Breaking the Lean Startup Playbook?"
description: "The cognitive-cache argument for still learning things, Stripe's two-year private beta, and aggregate Stripe data on business formation roughly doubling year over year."
tags: [startup-school-2026, lean-startup, launch-strategy, data, decentralization, learning]
status: draft
resource: https://www.youtube.com/watch?v=5d6y3poKwK4
speakers: [Patrick Collison, Harj Taggar]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Y Combinator"
    last_modified: 2026-07-31
---

# Summary

An interview by Harj Taggar, who co-founded a company with Collison twenty years earlier.
The most data-grounded session in the playlist, because Stripe sees new business formation
directly.

# Key claims

**Knowledge is cache, and neurons are L1.** Asked what students should still learn rather
than outsource, Collison reaches for the memory hierarchy: yes, you can ask an agent, but
that is far slower than knowing it, and you can do vastly more round trips inside your own
head than through a keyboard. He adds a revealed-preference argument — companies including
the labs still pay an enormous premium for cognitive ability — and concludes that renouncing
that before there is evidence of saturation would be premature. See
[/concepts/knowledge-as-cognitive-cache.md](/concepts/knowledge-as-cognitive-cache.md).

**He still writes himself.** Both philosophically and substantively: the models can prove
hard theorems, and he still has not read an LLM essay he found compelling. His hypothesis is
that the utility function for good writing is hard to define, and that writing is bound up
with reasoning sensibly about a multi-dimensional reality.[^ss26-collison]

**Dropping out is not a trapdoor.** He dropped out twice and returned in between, felt an
urgency he now judges unnecessary, and reports that in practice nobody has ever cared. He
also names the specific false belief behind the urgency — that Silicon Valley opportunities
are ephemeral — against decades of evidence that opportunities are in surplus. On the
current "permanent underclass" meme, he takes the under on this being the last couple of
years to start a company. See [/concepts/college-and-urgency.md](/concepts/college-and-urgency.md).

**Stripe was both an obvious and a ridiculous idea.** Obvious because the existing ways of
moving money on the internet were universally disliked and antiquated; ridiculous because
fintech did not exist as a word and two young founders pitching banks felt like squirrels in
a trench coat. What saved it, he says, was being grounded in a concrete, viscerally felt
customer problem rather than a hallucinated one — a lesson he attributes to YC.[^ss26-collison]

**Two years to public launch, but production users from month two.** First code in autumn
2009; first live production user in January 2010; public launch September 2011. The customer
asked in sequence for a dashboard, then refunds, then to actually receive his money — Collison
calls it just-in-time development. Private beta customers increased every month throughout.
His conclusion: a long pre-launch period is defensible *if* you have a continuous stream of
real grounding, and the domain (security, partners, money movement, reliability) demanded
preconditions before self-serve could work. See
[/concepts/private-beta-with-real-users.md](/concepts/private-beta-with-real-users.md).

**Lean startup may be getting competed away.** The classic doctrine — buy ads, find a
crevice, expand aggressively — assumed capital constraints and no cheap organisational
capability. He observes that many of the most successful companies of the last decade were
strongly anti-lean, and suggests the niches are now more aggressively tilled, so you may
need to decorrelate harder and start from a more divergent, ambitious point. See
[/concepts/lean-startup-in-the-ai-era.md](/concepts/lean-startup-in-the-ai-era.md).

**Ask what happens if you succeed.** Founders worry about failure; he argues you should ask
whether you will actually want to work on this for ten, seventeen or thirty years, ideally
before raising serious money. In Stripe's case the answer is yes because every business is
an applied theory about how some part of the world works. See
[/concepts/what-if-you-succeed.md](/concepts/what-if-you-succeed.md) and
[/concepts/schlep-blindness.md](/concepts/schlep-blindness.md).

**"What if Google does it" has a checkered track record.** Human organisations are
complicated, and prosecuting a hundred priorities at once is very hard; Google did some
things extremely well and did not do all the things it materially could have. He separates
this from the narrower question of whether model capabilities will obviate specific
verticals, which he grants will happen in some cases. See
[/concepts/will-the-labs-eat-my-startup.md](/concepts/will-the-labs-eat-my-startup.md).

**The Stripe data.** New businesses starting on Stripe were running at roughly 2x year over
year at the time of the talk — the largest relative jump he has seen, larger than the ~50%
COVID-era jump from 2019 to 2020. The median business is doing better than a year earlier;
the probability of crossing revenue thresholds ($1M, $5M, $10M) is improving; and time to
revenue for newly incorporated Atlas companies is declining. He also notes about 25% of all
Delaware corporations are started through Atlas. See
[/concepts/business-formation-data-2026.md](/concepts/business-formation-data-2026.md).

**Why buyers are moving faster.** Businesses are spring-loaded to try new things because the
risk of the status quo now reads as high — so the usual objections to buying from a startup
are outweighed. Taggar corroborates from YC batches that enterprises now sign contracts with
companies in their first ninety days.[^ss26-collison]

**Against the centralisation thesis.** Based on what Stripe sees, Collison does not worry
about AI concentrating the economy into a few companies; he expects many thousands of
winners and a more decentralised world with more broad-based prosperity — while explicitly
declining to make definitive prognostications. See
[/concepts/concentration-of-power.md](/concepts/concentration-of-power.md).

# See also

- [/people/patrick-collison.md](/people/patrick-collison.md), [/organizations/stripe.md](/organizations/stripe.md)
- Directly contradicted-in-emphasis by [/sources/blake-scholl.md](/sources/blake-scholl.md)
  on analytical vs iterative product discovery.

[^ss26-collison]: Startup School 2026 talk; see raw record [ss26-09-patrick-collison.md](../../raw/ss26-09-patrick-collison.md).
