---
type: Video Presentation
title: "Garry Tan — Own Your Intelligence"
description: "Personal AGI as owned infrastructure: a rented model plus your context library plus a harness, skill files as markdown employees, and the politics of who owns extracted cognition."
tags: [startup-school-2026, personal-agi, skills, context-engineering, revenue-per-employee, ownership]
status: draft
resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
speakers: [Garry Tan]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Y Combinator"
    last_modified: 2026-08-06
---

# Summary

The keynote of the event, and the most explicitly ideological talk in the playlist. Its
argument: general intelligence is not arriving as an event but diffusely, as infrastructure
an individual can own — and the political question is who owns it.

# The frame

Tan builds the talk around Baruch Spinoza, excommunicated at 23 in Amsterdam in 1656 under a
ban that was never lifted, after refusing an annuity of a thousand guilders to keep quiet. He
ground optical lenses by day and wrote by night; the *Ethics* left the house in a desk after
his death. In 1673 Heidelberg offered him a professorship with freedom to philosophise
"provided he not disturb the established religion," and he declined. Tan's transposition:
everyone is watching the sky for AGI while the thing is already in the room, looking like a
terminal window, a folder of markdown files and a job that finishes while you sleep.

He also takes Spinoza's definition of joy — the feeling of your power of acting increasing —
as the technical term for what happens the first time an agent does a week of your work
overnight, and its inverse, sadness, as the feeling of that power decreasing.

# The architecture

**The equation.** A frontier model (rented, commoditising, cheaper every quarter) plus *your*
context (owned, unique) plus a harness that wires them together. Model quality is rented;
your brain is owned. See [/concepts/personal-agi.md](/concepts/personal-agi.md).

**The working-memory argument.** A person holds about seven things at once; every institution
humanity has built — checklists, org charts, filing cabinets, stand-ups — is a prosthetic for
that limit. An agent holds a million tokens, roughly a thousand pages. But a life is a
library, not three books, so the question that decides whether your agent is a genius or a
goldfish is *what decides which three books are open*. That is the librarian, and it is the
actual product. See [/concepts/library-and-librarian.md](/concepts/library-and-librarian.md).

**Skill files are markdown employees.** A skill is a page of English: when this trigger fires,
do these steps, cross-check against the library, file here, flag contradictions rather than
overwriting. His test — if a smart intern could follow it, an agent can run it. A resolver is
the org chart deciding which skill handles an incoming task. Tan's blunt corollary is that
markdown is code and the compiler is a language model, which is why YC's media, events and
finance staff who never open a terminal are writing skills and scheduled jobs. See
[/concepts/skill-files-as-employees.md](/concepts/skill-files-as-employees.md).

**Latent versus deterministic space.** The failure mode behind every agent failure he has
seen is confusing the two. Taste, judgment and reading what a vague request really wants
belong in the model, steered by markdown. Arithmetic, SQL and combinatorial scheduling belong
in code. Seating five people is latent; generating personalised schedules for 6,000 attendees
in an arena requires the model to write code and keep state in a database — which, he notes,
is how the conference the audience was sitting in was actually run. See
[/concepts/latent-vs-deterministic-computation.md](/concepts/latent-vs-deterministic-computation.md).

**Hygiene is a first-class requirement.** His own caveat: a brain nobody curates is a garbage
dump with great search. Retrieval will surface a stale fact with total confidence and a bad
skill file encodes a bad process forever, so the primitive is memory *plus* provenance on
every fact, contradiction checks when new information collides with old, and a librarian
whose job is pruning. See [/concepts/knowledge-base-hygiene.md](/concepts/knowledge-base-hygiene.md).

# The five steps

1. Tonight: pick a harness and run an agent on your own machine.
2. This weekend: start the library — one folder of markdown, a page per project and per
   person, containing what only you know.
3. Write your first skill file for the weekly task you hate most; let it get things wrong and
   correct it.
4. Wire it to a recurring job, so work finishes while you sleep.
5. Never do one-off work: at the end of every task, ask the agent to "skillify" what it did.

His stated 90-day curve: week one it is a toy, week four the flywheel catches, week twelve you
have a library that answers before you finish asking and one or two tools other people keep
asking to borrow. Most people quit in week two.

# Claims and receipts

- His own output: about 14 useful lines of code a day in 2013, which he puts at roughly 400x
  now — and then deflates his own number, arguing it is at least 8x under the most punitive
  assumptions. He is careful to say the multiplier is for all knowledge work, not just code.
- A quarter of the W25 YC batch had codebases that were 95% AI-generated, and that batch is on
  track to be among the fastest-growing and most profitable in YC history — with an explicit
  disclaimer that he cannot prove causation.
- Revenue per person: Emergent (S24) went from public launch to nine figures of revenue in
  eight months and was 15 people at $15M annualised; another company he names reached $60M
  annualised at about 40 people. See
  [/concepts/revenue-per-employee.md](/concepts/revenue-per-employee.md).
- G brain: a Karpathy-style knowledge wiki of about 220,000 markdown pages covering 25 years,
  compiled and curated by agents; G stack, his agent coding framework, at about 123,000 GitHub
  stars. Both open source.
- The talk's own spine was produced by a "compendium skill": three Spinoza biographies, about
  1,500 pages, read overnight into a dated chronology, a list of where the biographers
  disagree, verbatim quotes with chapter citations, and the ten most tellable moments ranked
  with delivery notes. See [/case-studies/spinoza-compendium-skill.md](/case-studies/spinoza-compendium-skill.md).

# The political argument

A skill file is a piece of your cognition extracted, written down and made executable. Tan's
parable: a support engineer teaches her agents 40 skills over two years. If the files live in
her repo, she carries two years of compounded judgment to her next job — ownership. If they
live in the company's repo, she leaves with nothing and the company keeps running her judgment
without her — extraction. Same files, one variable. His analogy is craftsmen owning their
tools until the loom belonged to the mill; knowledge workers assumed safety because their
tools lived in their heads, and skill files end that. Hence: keep your brain and your skills
in a repo you control from day one. See
[/concepts/own-your-skill-files.md](/concepts/own-your-skill-files.md).

# Three objections he answers

1. *Models improve so fast the harness will be obsolete.* His reply: every release moves the
   differentiator further toward context — when everyone's engine has a thousand horsepower,
   the race is won on the driver and the map, and a smarter reader extracts more from the
   same books.
2. *Isn't this just RAG?* "Postgres is just B-trees." Retrieval is the primitive; being worth
   retrieving from is the product.
3. *What happens when it leaks?* His answer is that consolidation did not create the risk —
   your life is already scattered across ten clouds — it took custody of it, and custody is
   the security model.

# See also

- [/people/garry-tan.md](/people/garry-tan.md), [/organizations/y-combinator.md](/organizations/y-combinator.md)
- Endorsed almost verbatim by [/sources/alexandr-wang.md](/sources/alexandr-wang.md) and
  [/sources/jensen-huang.md](/sources/jensen-huang.md); in tension with
  [/sources/boris-cherny.md](/sources/boris-cherny.md) on how much scaffolding to keep.

[^ss26-tan]: Startup School 2026 talk; see raw record [ss26-07-garry-tan.md](../../raw/ss26-07-garry-tan.md).
