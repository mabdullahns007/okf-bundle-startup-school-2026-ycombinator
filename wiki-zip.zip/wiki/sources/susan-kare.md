---
type: Video Presentation
title: "Susan Kare — Designing Icons & Graphics For the Original Mac"
description: "Designing the original Mac's font and icons inside 16x16 and 32x32 bitmaps, why sparse metaphors outlive literal depictions, and four decades of collected advice."
tags: [startup-school-2026, design, constraints, metaphor, iteration, craft]
status: draft
resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
speakers: [Susan Kare]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Y Combinator"
    last_modified: 2026-08-14
---

# Summary

The one talk in the playlist with no AI content, opened with "now for something completely
different" — and the one whose lessons transfer most directly to interface work under new
constraints. Kare notes that rereading the Macintosh group's north star reminded her of AI and
much of what is being developed now.

# How she got the job

An art major with a PhD in art history and no computing background, welding a life-size
razorback hog for an Arkansas museum and finding garage work lonely, she was contacted by her
high-school friend Andy Hertzfeld, then a system software programmer at Apple, who needed images
for a new computer. She prepared by borrowing typography books from the Palo Alto library and
carrying them into the interview under her arm so she would look like she knew what she was
talking about, plus bitmap sketches drawn on graph paper. Nobody asked her a single question
about font design. Some of those apparently random graph-paper sketches influenced what shipped,
and the notebook is now in MoMA's permanent collection — hence her advice to hang on to your
stuff.

# The brief and the constraints

She was shown a screen and told her job was to improve it. The stated goal, which she says was
sincere, was a computer anyone could use: as understandable as possible without a manual, and
*friendly*. One early change was renaming a "do it" button to "okay," because people were
reading it as "don't."

Her position on constraints: you can be creative within any constraints — she notes you can make
fun art out of beach trash — but it helps to understand what they are and get excited about them
rather than resenting the absence of a thousand colours. Here they were 16x16 and 32x32,
one-bit. See [/concepts/constraints-enable-creativity.md](/concepts/constraints-enable-creativity.md).

# Type

Chicago, the first font she designed, has a nine-pixel cap height. Her observation was simply
that everything on screen looked jagged and could be made tidier using horizontals, verticals
and 45-degree angles. She still winces at the lowercase x. Proportional spacing was the
advancement she says she did not appreciate at the time, having previously seen displays where
the M was squished and the I was wide. Chicago went into the title bar and, she notes with
evident pleasure, into the calculator — which means that in designing the calculator they were
also designing the first iPod.

The city names came from stations on the Paoli Local near the high school she and Hertzfeld
attended. Steve Jobs came through at the end of a day and said city names were fine but they
should at least be world-class cities — hence New York and Geneva instead of Paoli and Wynnewood.

# Icons, and the case for sparse metaphor

Her design bias is a salient detail or two and no more, and she grounds it in two illustrations
from Scott McCloud's *Understanding Comics*: a face with much detail looks like a specific
someone else, while a simple one lets everyone project themselves onto it, and less detail
means more universality. Hence a plain pencil can stand for writing better than a chrome pen
with a reflection, which is a very particular pen not everyone writes with. Her comparison is
street signs: there is no technical reason the school-crossing children could not have plaid
lunchboxes, but it would cost instant recognition. See
[/concepts/sparse-metaphor-over-literal-detail.md](/concepts/sparse-metaphor-over-literal-detail.md).

The corollary she draws from her own mistakes is not to depict a particular product design: her
print icon showed ImageWriter paper with sprocket holes, and would have had a much longer
lifespan if she had stopped and simplified — as with the 3.5-inch floppy for save.

**Specific icons discussed.** The Happy Mac existed because a 128K Mac took visible time to boot
and everyone wanted something on screen showing things were fine; she thinks the smile came from
a badge she had at about fourteen. Its counterparts were commissioned on the explicit premise
that nobody would ever see them: a sick Mac, and a Bugs Bunny-style bomb for total system
failure. People did see the bomb — a caller once rang Apple worried her computer was going to
explode.

**The Command key.** The menus originally used apple glyphs for shortcuts until Jobs objected to
an "Apple farm," saying the logo was precious. Told the key was a "command" or "feature" key, she
found commanding a mean idea and the Ten Commandments a bad pun, went back to the library, and
found a symbol labelled a feature — four-leaf-clover-ish, cloverleaf-highway-ish, and
conveniently easy to draw in 16x16. She felt slightly bad that it was abstract rather than a
reinforcing metaphor. Landing in Gothenburg years later she saw it on Swedish signage marking
places of interest, and was told it derives from Borgholm Castle, a ruin whose four turrets read
as that shape from above. She enjoyed discovering that it did look like something after all.

She also notes there is little new under the sun: hieroglyphics, carved symbols, and very good
bitmap letterforms of seven to ten pixels' cap height that predate the Mac by centuries.

# Tools and iteration

Hertzfeld wrote an icon editor so she no longer had to design on graph paper. It had no drawing
tools — you toggled bits — no shape tools and no undo stack, but showed a magnified view
alongside the 72-DPI result and generated the hex code automatically. She says it is hard to
overstate how good this was: you could iterate without an eraser. Her stated moral for the whole
icon section is *lots of iteration*.

Her system used a verb-and-noun scheme — an active-looking application icon paired with a
resembling document — which she notes held up well for half a dozen applications, since nobody
had the mindset that there would be thousands.

# After Apple

Windows 3.0 for Microsoft, where sixteen colours (some not very good) still made a real
difference for alerts and at-a-glance differentiation, dithered so the result was subtle rather
than a garish chessboard — plus the Solitaire cards. The General Magic logo and a more literal
desktop metaphor of hallways and doors, whose worst element she says was jars of text, "because
why?" — a system built so you could remember where things were, that could send postcards but
did not quite anticipate email. Facebook Gifts, where for nearly four years a new drawable gift
launched at midnight Eastern and you could tell from the first fifteen minutes whether it would
be a bestseller; her lesson is that *cute trumped everything* — teddy bears, hearts, and the kiss
mark as all-time bestseller — while expensive-looking diamond earrings and Rolexes did not work.
If her life depended on selling a drawing for a dollar she would draw a penguin, because every
limited-edition penguin sold out. Then Pinterest icons with slight motion so they would not
irritate over time, a Ledger wallet badge series, an Amtrak route map, and various logos.

# The collected advice

The closing third is a collection of advice from people who influenced her, offered as a list she
is still adding to:

- **Paul Rand** (UPS and IBM logos), her hero and later colleague: focus on making things
  meaningful and memorable — have a good idea and the form will follow. He was brusque about
  fonts: you do not need many, you need to know how to use them well. He advocated doing something
  *to the name* of the product, as he did putting NeXT in a cube, and showed a since-replaced AT&T
  mark as what not to do, on the grounds that spending a fortune to associate a meaningless symbol
  is a luxury most people cannot afford. His UPS logo had a shield and a package; asked what it
  was, his six-year-old daughter reportedly said "it's a present, Daddy," which he took as
  sufficient justification. Kare notes she still uses colours from his books.
- **The NeXT logo procurement**, which she tells as a lesson about how to buy creative work: Jobs
  wanted a contest paying five people or firms $15,000 each. Rand's counter-offer was $100,000 for
  one logo that they would like. That is what happened, they did like it, and she calls it a great
  learning experience for everyone. See
  [/concepts/how-to-commission-creative-work.md](/concepts/how-to-commission-creative-work.md).
- **Paul Saffo**, on estimation: her gloss is that she always thinks she can do something in an
  hour, when nothing takes an hour.
- **Her father**, director of a chemical senses research centre who had to raise a great deal of
  money, whose advice she describes as not cheerful but realistic — she keeps it in mind because
  she gets depressed hearing no.
- **Daniel Nord**, an architect who described endless meetings around tables: make it visual, do
  the drawing — show, don't tell. See
  [/concepts/show-dont-tell-make-it-visual.md](/concepts/show-dont-tell-make-it-visual.md).
- **Alan Kay**, via Bud Tribble, on nesting interface elements rather than putting everything at
  one level so that ease of use seems possible — and, to her great pleasure, telling her that
  proportionally spaced fonts turned out to look pretty good.
- **Andy Hertzfeld**, on showing work to Jobs: never show one thing, because he will reject it;
  show a few, so he can be involved, call something terrible, and still pick something. See
  [/concepts/never-show-one-option.md](/concepts/never-show-one-option.md).
- **On scale**: at around fifteen people you can still have consensus hiring and everyone in one
  room on the same page; past that there is an upside and a downside.
- **On placeholders**: she likes to show what a client asked for or what a programmer used as a
  placeholder, because she has gotten many good ideas that way.
- **The pirate flag**: after an early offsite goal, she and programmer Steve Capps made a flag —
  he sewed it black, she painted the skull and crossbones with a striped Apple as the eye patch —
  and they climbed onto the roof at night to fly it, security being laxer then.
- **The one piece of bad advice from Jobs**: not to buy Apple stock — she reasoned that if he was
  not buying, he would know. He also told her she could twiddle bits and never earn much, or be a
  creative director. She was a creative director at NeXT and got to work with Rand, which she
  loved, but says she was a bit-twiddler at heart and went back to it.

# See also

- [/people/susan-kare.md](/people/susan-kare.md), [/organizations/apple-macintosh-group.md](/organizations/apple-macintosh-group.md)
- Her constraint argument rhymes with [/sources/chelsea-finn.md](/sources/chelsea-finn.md) on
  token budgets and with [/sources/boris-cherny.md](/sources/boris-cherny.md) on stripping a
  harness to the minimum.

[^ss26-kare]: Startup School 2026 talk; see raw record [ss26-03-susan-kare.md](../../raw/ss26-03-susan-kare.md).
