---
type: Video Presentation
title: "Blake Scholl — How 50 People Built a Supersonic Jet"
description: "Treating aircraft engineering as software, demonstrating Mach cutoff to re-legalise supersonic flight, and funding airframe R&D by selling the engine as a ground turbine."
tags: [startup-school-2026, hardware, iteration-velocity, regulation, hiring, manufacturing]
status: draft
resource: https://www.youtube.com/watch?v=byAj35QlGbs
speakers: [Blake Scholl]
event: Startup School 2026
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Y Combinator"
    last_modified: 2026-07-28
---

# Summary

A talk on stagnation in air travel and the engineering method Boom used to break the
sound barrier with a 50-person team, followed by an unusually long and direct Q&A.

# Key claims

**The premise: we got slower.** Scholl opens on 1969 — the Moon landing and Concorde in
the same year — against a present in which we can do neither, and notes that Boeing's
787, launched more than twenty years before the talk, is visually and performatively
indistinguishable from the 707. He cites a report that Lockheed now takes more than two
years to build a Patriot interceptor. His counterfactual is historical: the first jetliners
doubled travel speed, and the consequences were on the ground — Hawaii became a mainstream
destination, Nike began by importing Japanese running shoes after a chance trip, and the
Beatles' first world tour was impractical a decade earlier.[^ss26-scholl]

**Optimise for the worst day and the best day.** Boom came within seven days of cash and
the board told him to shut it down. He refused, and later got to watch XB-1 go supersonic.
His conclusion is that you must build something that matters to the world, not only to
you, because that is what carries you across the trough. See
[/concepts/optimize-for-the-worst-day-and-the-best-day.md](/concepts/optimize-for-the-worst-day-and-the-best-day.md).

**Mach cutoff removed the political problem.** See
[/case-studies/xb1-mach-cutoff.md](/case-studies/xb1-mach-cutoff.md) for the numbers.
His generalisation: people say building in a regulated industry is a bad idea, but you can
change the regulations — by building the thing and explaining why it is fine. See
[/concepts/regulatory-strategy-for-startups.md](/concepts/regulatory-strategy-for-startups.md).

**Make hardware development look like software development.** Great software is modular;
great aircraft are the opposite, deeply integrated, so that adding a row of seats changes
the fuselage, the engines and the wings. Historically that meant specialists handing
spreadsheets to each other, and eventually declaring a design good enough. Boom instead
built *Makeboom*, which defines an aircraft in a configuration file and runs a whole-vehicle
simulation in minutes, and *Bladerunner*, which lets a couple of engineers change a turbine
blade design and see structural and aerodynamic consequences in real time. Scholl's
sharpest line on the old way: spreadsheet engineering is real code being treated as a
second-class citizen, with no automated integration or testing.[^ss26-scholl] See
[/concepts/engineering-tools-as-product.md](/concepts/engineering-tools-as-product.md).

**Product-market fit had to be found analytically.** You cannot build a supersonic jet and
see if anyone likes it, so the simulation tooling was used to search the space of
conceivably buildable aircraft for the one worth building.[^ss26-scholl] This is the
strongest counter-case in the playlist to iterative launch — compare
[/concepts/lean-startup-in-the-ai-era.md](/concepts/lean-startup-in-the-ai-era.md).

**Iterate in atoms too.** Boom built its own machine shop (design to prototype part in
about 24 hours), and its own engine test stand about half an hour from engineering — he
notes that his R&D shop is a room that does not exist at GE, Rolls-Royce or Boeing. He is
blunt that iterating through outside aerospace suppliers was the binding constraint. See
[/concepts/vertical-integration-for-iteration-speed.md](/concepts/vertical-integration-for-iteration-speed.md).

**The engine funds the airplane.** Because propulsion was vertically integrated, the same
turbine could be sold on the ground as a natural-gas power generator ("Superpower"),
producing test data, reliability learning and capital without the airframe. First unit was
described as shipping to a customer in under twelve months.[^ss26-scholl]

**"Why now?" is a trap.** Scholl names as a false belief the idea that every technology is
created at the earliest moment it could be, and that therefore an idea nobody is working
on must be flawed. His claim is that the technology for supersonic flight existed long
before Boom and nobody had started; the law of large numbers does not apply to startups
because the world is smaller than it looks. The answer to "why now" can be "because I
started now." See [/concepts/why-now-is-because-i-started.md](/concepts/why-now-is-because-i-started.md).

**Beating China means inventing the next manufacturing wave, not repatriating the last
one.** He describes the tool-and-die industry's migration as a mechanism by which US
manufacturing hollowed out, and Boom's response as eliminating tooling entirely — an
all-digital path from design to turbine blade in 24 hours.[^ss26-scholl]

**Hiring.** Aerospace has had no startups since Douglas Aircraft in 1921, so the
experienced talent pool comes from cultures he considers bad. His answer is early-career
people who are hands-on, ambitious and "not yet destroyed" by legacy aerospace, promoting
from within at senior levels, and one hard rule: a young engineer may do something nobody
has ever done, but if someone in the world *has* done it, they must find that person, call
them, and hear the advice — they need not take it. See
[/concepts/hiring-for-evidence-of-exceptional-ability.md](/concepts/hiring-for-evidence-of-exceptional-ability.md).

**The worst advice he received was to work on what he knew.** His mother asked whether he
shouldn't work on something he knew something about. His first company was mobile
e-commerce precisely because his resume said so, and he had no product vision and did not
care. Knowledge is changeable; what you love is not. See
[/concepts/work-on-what-you-love-not-what-you-know.md](/concepts/work-on-what-you-love-not-what-you-know.md).

**Teaching yourself hard things: keep a confusion list.** He went back through remedial
physics and calculus and problem sets, keeping a list of things he could answer on a test
but did not actually understand, aiming to remove one a week. The list grew without bound;
the value was developing the internal signal that distinguishes real understanding from
hand-waving.[^ss26-scholl]

**On the fundraising path, he explicitly does not recommend imitation.** Boom nearly died
several times and took far longer and more money than expected. With hindsight he would
have planned a simpler first prototype giving multiple shots on goal, because iterating at
the product level surfaces wrong *requirements*, not just wrong engineering.[^ss26-scholl]

**Also noted:** Jeff Bezos passed on Boom's 2015 seed round and then wrote in that year's
Amazon shareholder letter that some things only large companies can do, citing airliners.

# See also

- [/people/blake-scholl.md](/people/blake-scholl.md), [/organizations/boom-supersonic.md](/organizations/boom-supersonic.md)
- [Michael Kratsios](/sources/michael-kratsios.md) independently cites supersonic flight as
  his favourite example of technological stagnation and of a "born in captivity" technology.
- Same infrastructure-determines-speed argument as [/sources/max-hodak.md](/sources/max-hodak.md).

[^ss26-scholl]: Startup School 2026 talk; see raw record [ss26-12-blake-scholl.md](../../raw/ss26-12-blake-scholl.md).
