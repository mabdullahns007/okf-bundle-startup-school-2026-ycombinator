---
type: Organization
title: "OpenClaw"
description: "Open-source personal agent project; eight months old at the time of the talk, with a foundation behind it."
tags: [open-source, agents, personal-agi, nonprofit]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

Open-source personal agent project created by [Peter Steinberger](/people/peter-steinberger.md),
about eight months old at the time of his talk — which he says is more like four years in AI time.

# Origin and naming

Began as a WhatsApp relay built in an hour one November evening so he could prompt an agent from his
phone. When someone sent a pull request adding Discord support, the name no longer fit; the project
went through several names — he mentions a lobster being dropped and the project molting a few times —
before settling on OpenClaw.

It went viral in the first week of January after he put his agent in a public Discord server and
stayed up all night watching people try to hack it. Having built it as a resilient launch daemon, it
restarted five seconds after he pressed Ctrl-C and answered the world for ten hours while he slept.

# Scale, as stated

In eight months: over **18,000 distinct people** opened an issue or pull request (111,000 total),
with nearly **3,000 people holding commits**. Weekly downloads bottomed near **835,000** in May and
peaked at an all-time-high **4.7 million** in June. Roughly **33,000** repositories carry "claw" in
the name. Steinberger says Jensen Huang called it the most successful open-source project in the
history of humanity.

# Security posture

Sandboxing, allow lists, a permissioned protocol, shelling out to Python for file operations because
TypeScript lacked primitives for keeping an agent in its workspace, symlink refusal, and atomic
config writes. Against press reports that ~20% of skills were malicious, the team scanned all 67,000
and published a paper putting it nearer **0.3%**.

The costs are recorded in [/concepts/configuration-sprawl.md](/concepts/configuration-sprawl.md) and
[/concepts/dependency-business-model-risk.md](/concepts/dependency-business-model-risk.md).

# Governance and direction

Now a US 501(c)(3) nonprofit with corporate donors, ten people on payroll and hiring — including a
CEO. Stated mission: bringing people closer to AI. NVIDIA is named as an early and unusually
practical donor. See [/organizations/nvidia.md](/organizations/nvidia.md).

Current work: rebuilding OpenClaw with OpenClaw, with a shared team server where everyone sees each
other's sessions and an agent that knows what everyone is working on and can take over orchestration;
plus voice and multimodality, including a working video-call hack the day before the talk.

# Its role in the wider playlist

[Garry Tan](/sources/garry-tan.md) names it as one of the harnesses he runs.[^ss26-tan]
[Jensen Huang](/sources/jensen-huang.md) calls seeing it a Linux moment — the operating system that
will hold a large language model — and describes offering NVIDIA's engineers to the
project.[^ss26-huang] Steinberger's own positioning: every lab will sell you an agent, and OpenClaw
is the alternative — your agent, your machine, your life.

[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
