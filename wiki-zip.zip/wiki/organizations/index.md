# Organizations

Companies and institutions discussed in the talks. Facts are recorded as stated by speakers at a
public event, with figures attributed rather than asserted.

* [Anthropic](anthropic.md) - AI company; the playlist's source for harness design, product overhang and multi-day agent runs.
* [Apple's Macintosh group](apple-macintosh-group.md) - The team Susan Kare joined as Macintosh artist; the setting for the playlist's design talk.
* [Boom Supersonic](boom-supersonic.md) - Aerospace startup that broke the sound barrier with a 50-person team and helped re-legalise US supersonic flight.
* [Google DeepMind](google-deepmind.md) - Google's AI organisation; source of the playlist's systems-level material and of Genie 3.
* [Legora](legora.md) - Legal AI company from Stockholm; described as going from $1M to $100M ARR in about 18 months.
* [Meta's frontier AI lab](meta-superintelligence-labs.md) - Meta's AI organisation, rebuilt from a zero base under Alexandr Wang.
* [NVIDIA](nvidia.md) - Accelerated computing company founded 1993; its founding algorithm was wrong and it learned graphics from textbooks.
* [OpenAI](openai.md) - AI research and product company; founded when, by Altman's account, roughly fifty people believed AGI was possible.
* [OpenClaw](openclaw.md) - Open-source personal agent project; eight months old at the time of the talk, with a foundation behind it.
* [Physical Intelligence](physical-intelligence.md) - Robot foundation model company; goal is to let any robot do any task in the real world.
* [Science Corp](science-corp.md) - Neural engineering company; its lead product is a subretinal photovoltaic implant restoring vision.
* [Stripe](stripe.md) - Payments company; source of the playlist's aggregate data on new business formation.
* [Waymo](waymo.md) - Autonomous driving company; the playlist's reference case for AI deployed in the physical world at scale.
* [White House Office of Science and Technology Policy](white-house-ostp.md) - The office coordinating US science and technology policy across federal agencies.
* [Y Combinator](y-combinator.md) - Startup accelerator; host of Startup School 2026 and the connective tissue of the whole playlist.
