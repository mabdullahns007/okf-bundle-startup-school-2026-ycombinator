---
type: Organization
title: "Meta's frontier AI lab"
description: "Meta's AI organisation, rebuilt from a zero base under Alexandr Wang."
tags: [frontier-labs, meta, open-weights, research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-wang
    resource: https://www.youtube.com/watch?v=sJ4VJWycX9M
    title: "Alexandr Wang: This is a Once-in-a-Civilization Opportunity"
    author: "Alexandr Wang"
    last_modified: 2026-07-29
  - id: ss26-tan
    resource: https://www.youtube.com/watch?v=eRrc1pUY5oU
    title: "Garry Tan: Own Your Intelligence"
    author: "Garry Tan"
    last_modified: 2026-08-06
---

Meta's frontier AI organisation, led by [Alexandr Wang](/people/alexandr-wang.md) as Chief AI
Officer for about a year at the time of the talk.

# What Wang says happened

Llama 4 was, publicly and by his account, not on the trajectory Meta needed. So he did a
"zero-based build" of how you construct an entire frontier lab — using a lot of what was already
there, but moving as fast as possible. Stated results: a new frontier model shipped within nine
months of that moment, an image model and a point release two months later, with larger models
described as on the way and expected to be much more competitive with the very best available.

His stated core bet was **talent density**. See
[/concepts/talent-density-compounds.md](/concepts/talent-density-compounds.md).

# Positioning

- **Personal superintelligence**, from a memo by Mark Zuckerberg a year earlier: billions of people
  each with a superintelligence adapted to them, whose purpose is *agency expansion*. Wang links it
  explicitly to [Garry Tan](/people/garry-tan.md)'s personal-AGI framing. See
  [/concepts/personal-agi.md](/concepts/personal-agi.md).
- **An ecosystem rather than a monolith**: 200 million businesses on Meta's platforms today, which
  he expects to reach billions, with business agents and personal agents forming a
  fully-AI-supercharged ecosystem. Explicitly against a totalising single-AI world.
- **Price**: he rejects a world where models are so expensive they are rationed to the wealthiest
  developers. Tan reports the model performing comparably to a frontier competitor on agentic
  workflows at roughly 8x lower cost.
- **Open source**: open-weight models described as in progress, on the view that a decentralised
  world of AI capability empowers the broader ecosystem. See
  [/concepts/open-weights-policy.md](/concepts/open-weights-policy.md).
- **A harness** described as in development, prioritising speed, reliability and extensibility to
  complex multi-agent setups; at the time of the talk the recommended entry point was an
  open-source harness.
- **Attendee offer:** $1,000 of API credits for everyone at the event.

# Internal practice

Wang reports cases where the right agentic loop plus the right eval let a swarm of agents accomplish
more than a team of a hundred engineers. See
[/concepts/agentic-feedback-loops.md](/concepts/agentic-feedback-loops.md).

⚠️ Model and product names in this source are rendered inconsistently by the auto-transcript and are
deliberately not asserted here; see
[transcription caveats](/sources/index.md#transcription-caveats).

[^ss26-wang]: Alexandr Wang, [Alexandr Wang: This is a Once-in-a-Civilization Opportunity](/sources/alexandr-wang.md), Startup School 2026.
[^ss26-tan]: Garry Tan, [Garry Tan: Own Your Intelligence](/sources/garry-tan.md), Startup School 2026.
