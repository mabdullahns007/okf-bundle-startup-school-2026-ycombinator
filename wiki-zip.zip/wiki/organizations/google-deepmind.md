---
type: Organization
title: "Google DeepMind"
description: "Google's AI organisation; source of the playlist's systems-level material and of Genie 3."
tags: [frontier-labs, research, hardware, world-models]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dean
    resource: https://www.youtube.com/watch?v=CxXgV54KzpQ
    title: "Jeff Dean: The 1% Rule for Building in AI"
    author: "Jeff Dean"
    last_modified: 2026-07-30
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
---

Google's AI research organisation, represented by [Jeff Dean](/people/jeff-dean.md) as chief
scientist. Dean joined Google in 1999 when it was about 20 people.

# Facts and systems stated in this playlist

- **The RAM-resident search index**, around 2001: Dean and Sanjay Ghemawat calculated that the whole
  index would fit in the aggregate RAM of Google's machines, and shipped it in days — which is what
  made search fast.
- **MapReduce**, whose origin Dean describes as recognising that hand-parallelised crawling and
  indexing code was obscuring a simple underlying operation, and that a functional-programming
  abstraction could separate the operation from the checkpointing and reliability machinery beneath.
- **The TPU**: [/case-studies/tpu-napkin-math.md](/case-studies/tpu-napkin-math.md). Specialised for
  low-precision dense linear algebra; 30–80x more energy-efficient and 20–30x lower latency than
  contemporary CPUs and GPUs.
- **Distillation**, rejected at NeurIPS, now underlying the fast Gemini models:
  [/case-studies/distillation-paper-rejection.md](/case-studies/distillation-paper-rejection.md).
- **AlphaFold**, cited as the pattern for a narrow but highly accurate model. See
  [/concepts/the-one-percent-rule.md](/concepts/the-one-percent-rule.md).
- **AlphaChip** for layout and **AlphaEvolve** for propose-evaluate-keep loops, as existing instances
  of automated experimentation. See
  [/concepts/automated-experimentation-loops.md](/concepts/automated-experimentation-loops.md).
- **A learned DFT surrogate** roughly 300,000x faster than the simulator and nearly as accurate. See
  [/concepts/learned-surrogate-evaluators.md](/concepts/learned-surrogate-evaluators.md).
- **Genie 3**, which [Dmitri Dolgov](/sources/dmitri-dolgov.md) says Waymo's generative simulation
  work leverages.[^ss26-dolgov]
- Internal agent practice: harnesses plus skills teaching agents to use Google's proprietary tooling
  for coding, code review, performance measurement and log fetching. See
  [/concepts/skills-as-encoded-method.md](/concepts/skills-as-encoded-method.md).
- A ~30-page internal "performance hints" document by Dean and Ghemawat, described as published.

[^ss26-dean]: Jeff Dean, [Jeff Dean: The 1% Rule for Building in AI](/sources/jeff-dean.md), Startup School 2026.
[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
