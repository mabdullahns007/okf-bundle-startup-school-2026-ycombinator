---
type: Organization
title: "Boom Supersonic"
description: "Aerospace startup that broke the sound barrier with a 50-person team and helped re-legalise US supersonic flight."
tags: [aerospace, hardware, manufacturing, regulation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-scholl
    resource: https://www.youtube.com/watch?v=byAj35QlGbs
    title: "Blake Scholl: How 50 People Built a Supersonic Jet"
    author: "Blake Scholl"
    last_modified: 2026-07-28
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

Aerospace company founded 2014 by [Blake Scholl](/people/blake-scholl.md), based in Denver.
Scholl notes the last entrepreneur-founded company to go on to build a commercial airliner was
Douglas Aircraft in 1921.

# What it has done

- **XB-1** (originally "Baby Boom"): the first independently developed jet to break the sound
  barrier, more than a decade after founding, with a **50-person** team. Demonstrated Mach cutoff so
  no boom reached the ground, which led to an executive order 115 days later re-legalising US
  supersonic flight. See [/case-studies/xb1-mach-cutoff.md](/case-studies/xb1-mach-cutoff.md).
- **Overture** — the passenger airliner under development.
- **Superpower** — the supersonic engine adapted as a natural-gas ground power turbine, sold
  separately to generate test data, reliability learning and development capital. First unit
  described as going to a customer in under twelve months.
- A **superfactory** for engines and ultimately airframes: an empty leased building in January, with
  first machines installed six months later and first production engine parts weeks away.

# Its engineering method

- **Makeboom** — define an aircraft in a config file and simulate the whole vehicle in minutes.
- **Bladerunner** — real-time structural and aerodynamic feedback on turbine blade design.
- An in-house machine shop (digital design to prototype part in ~24 hours) and its own engine test
  stand about half an hour from engineering.
- An all-digital, tooling-free path to turbine blades, as the manufacturing bet against China.

See [/concepts/engineering-tools-as-product.md](/concepts/engineering-tools-as-product.md) and
[/concepts/vertical-integration-for-iteration-speed.md](/concepts/vertical-integration-for-iteration-speed.md).

# Notes

Jeff Bezos passed on the 2015 seed round and wrote in that year's Amazon shareholder letter that
some things only large companies can do, citing airliners. Boom came within seven days of cash with
the board recommending shutdown. Scholl explicitly does not recommend imitating its fundraising
path, and says with hindsight the first prototype was too ambitious — a simpler one would have given
multiple shots on goal.

[Michael Kratsios](/sources/michael-kratsios.md), speaking three weeks later, cites supersonic
flight as his favourite example of technological stagnation and identifies the exact regulatory fix
that had just been made.[^ss26-kratsios]

[^ss26-scholl]: Blake Scholl, [Blake Scholl: How 50 People Built a Supersonic Jet](/sources/blake-scholl.md), Startup School 2026.
[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
