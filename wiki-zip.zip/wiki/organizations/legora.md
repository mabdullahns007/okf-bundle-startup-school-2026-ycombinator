---
type: Organization
title: "Legora"
description: "Legal AI company from Stockholm; described as going from $1M to $100M ARR in about 18 months."
tags: [legal-ai, saas, europe, growth]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-junestrand
    resource: https://www.youtube.com/watch?v=o0ORPbSEgd8
    title: "Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else"
    author: "Max Junestrand"
    last_modified: 2026-08-25
---

Legal AI company headquartered in Stockholm, led by [Max Junestrand](/people/max-junestrand.md). Its
YC two-sentence description: an agentic operating system for lawyers, handling complex legal work
from start to finish.

# Figures and timeline

See [/case-studies/legora-zero-to-100m.md](/case-studies/legora-zero-to-100m.md) for the full table
and the recorded inconsistencies. Headline items: general availability October 2024; $1M → $100M
ARR in about 18 months; claimed usage by over 3% of the world's lawyers; ~50 countries; from three
engineers in Sweden to 750+ people.

# How it was built

- Predecessor company started 2020 by a lawyer, a physicist, an engineer and a psychologist, working
  with early Google BERT models.
- Customer discovery by paying lawyers their hourly rate for lunch. See
  [/concepts/customer-discovery-by-paying-for-access.md](/concepts/customer-discovery-by-paying-for-access.md).
- Early residency inside Mannheimer Swartling, the largest Nordic law firm, in a windowless
  conference room where the air conditioning shut off at 5pm.
- Rejected by YC in May 2023, accepted two months later under a new name.
- A six-month sales freeze, then a written product manifesto. See
  [/concepts/deliberate-sales-freeze.md](/concepts/deliberate-sales-freeze.md) and
  [/concepts/product-manifesto.md](/concepts/product-manifesto.md).
- Investors named: Benchmark ($9.51M) and Redpoint (pre-emptive Series A three weeks later).

# Technical and product notes

Model-agnostic by design, with an internal benchmark ("Legora bench") kept private for three years
and released publicly the week before the talk. Very large spend on OCR and document parsing. The
current hard problem is the shift from reactive to proactive agents. See
[/concepts/eval-driven-model-routing.md](/concepts/eval-driven-model-routing.md) and
[/concepts/build-one-step-ahead-of-the-models.md](/concepts/build-one-step-ahead-of-the-models.md).

# Culture

Three values arranged as LFG — lean in, fight for excellence, grow together. Global onboarding in
Stockholm. A deliberate posture against Jantelagen. A Jude Law advertising campaign, secured through
persistence, with the actor choosing his own screenwriter and cinematographer. See
[/concepts/culture-against-local-norms.md](/concepts/culture-against-local-norms.md) and
[/concepts/hire-for-slope-not-intercept.md](/concepts/hire-for-slope-not-intercept.md).

⚠️ Company and person names in this section come from auto-generated captions and are normalised;
see [transcription caveats](/sources/index.md#transcription-caveats).

[^ss26-junestrand]: Max Junestrand, [Max Junestrand: You Need The Willingness To Learn Faster Than Anyone Else](/sources/max-junestrand.md), Startup School 2026.
