---
type: Organization
title: "Physical Intelligence"
description: "Robot foundation model company; goal is to let any robot do any task in the real world."
tags: [robotics, physical-ai, foundation-models, research]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
---

Robot foundation model company co-founded by [Chelsea Finn](/people/chelsea-finn.md) about two years
before the talk. Stated goal: developing models that allow any robot to do any task in the real
world.

# What it has shown

Tasks demonstrated across two years of Startup School talks: unloading and folding laundry; robots
doing useful tasks in rooms they had never seen; washing a greasy pan; peeling a carrot; making a
grilled cheese sandwich; slicing a zucchini; making espresso and lattes; building, labelling and
stacking cardboard boxes for a real Dandelion Chocolate workflow; folding a collared shirt;
inserting and drilling a screw into a robot arm; replacing a bin liner; and a 10–15 minute
autonomous kitchen clean-up.

# The models

- **π0 and π0.5** — described as open source, and recommended as the starting point for small teams.
- **π0.6** — the fine-tuned specialists produced with RL post-training.
- **π0.7** — a single generalist model that matches or exceeds those specialists out of the box, and
  shows compositional generalisation across appliances and robot embodiments.
- A separate release described as showing policies faster than human teleoperation.

See [/concepts/robot-rl-with-human-interventions.md](/concepts/robot-rl-with-human-interventions.md),
[/concepts/multi-timescale-robot-memory.md](/concepts/multi-timescale-robot-memory.md),
[/concepts/compositional-generalization.md](/concepts/compositional-generalization.md) and
[/concepts/metadata-prompting-for-heterogeneous-data.md](/concepts/metadata-prompting-for-heterogeneous-data.md).

# Deployment

Two YC companies — **Ultra** and **Weave** — have post-trained these models for laundry folding and
warehouse packaging. The model family is described as adapted to standard bimanual platforms, large
industrial arms, drones and quadcopters, surgical robots, and tractors, with a tractor company named
as a partner.

Finn notes the company was hiring at the time of the talk.

⚠️ Model names are rendered inconsistently in the auto-transcript (e.g. "PIO7" for π0.7); see
[transcription caveats](/sources/index.md#transcription-caveats).

[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
