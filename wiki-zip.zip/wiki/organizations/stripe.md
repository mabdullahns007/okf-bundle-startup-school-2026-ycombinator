---
type: Organization
title: "Stripe"
description: "Payments company; source of the playlist's aggregate data on new business formation."
tags: [fintech, payments, data, saas]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-collison
    resource: https://www.youtube.com/watch?v=5d6y3poKwK4
    title: "Patrick Collison: Is AI Breaking the Lean Startup Playbook?"
    author: "Patrick Collison"
    last_modified: 2026-07-31
---

Payments company co-founded by [Patrick Collison](/people/patrick-collison.md) and his brother John.

# Origin, as told

The brothers attended Startup School in Berkeley in 2009, got sushi in Potrero afterwards, and
decided walking back to start Stripe — reasoning that they might as well, because it probably would
not be that hard. That was almost seventeen years before this talk.

What they were solving was concrete and viscerally felt: moving money on the internet was annoying,
the existing options were extremely unpopular and antiquated, and you had to fill out paperwork and
go to a bank in person. What made it seem ridiculous was that fintech did not exist as a word, and
Collison describes pitching banks and partners as feeling like squirrels in a trench coat — with the
partners looking for the button to call security.

# Timeline

First lines of code autumn 2009; first live production user (Ross Boucher, at a company Collison
names as Twilio North) January 2010; public launch September 2011. See
[/concepts/private-beta-with-real-users.md](/concepts/private-beta-with-real-users.md).

# The data

Its unusual value in this collection is that Stripe observes business formation directly. See
[/concepts/business-formation-data-2026.md](/concepts/business-formation-data-2026.md) for the
figures — new businesses roughly 2x year over year, improving median outcomes, falling time to
revenue, and about 25% of all Delaware corporations started through Stripe Atlas.

Collison's assessment of what makes the company interesting to run: they work with the world's most
innovative companies through the entirety of their journey, up to being Shopify or OpenAI, and every
business is an applied theory about how some part of the world works. See
[/concepts/schlep-blindness.md](/concepts/schlep-blindness.md).

**Attendee offer:** free Atlas incorporation for everyone at Startup School.

Collison closes by noting Stripe would not exist without [YC](/organizations/y-combinator.md).

[^ss26-collison]: Patrick Collison, [Patrick Collison: Is AI Breaking the Lean Startup Playbook?](/sources/patrick-collison.md), Startup School 2026.
