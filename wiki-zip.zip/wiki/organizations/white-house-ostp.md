---
type: Organization
title: "White House Office of Science and Technology Policy"
description: "The office coordinating US science and technology policy across federal agencies."
tags: [policy, government, science-funding, regulation]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kratsios
    resource: https://www.youtube.com/watch?v=zLUZclThLhU
    title: "Michael Kratsios: Inside the White House's AI Strategy"
    author: "Michael Kratsios"
    last_modified: 2026-08-18
---

The White House office that coordinates science and technology policy across the federal government,
directed by [Michael Kratsios](/people/michael-kratsios.md). Its history is invoked directly in his
talk: [Vannevar Bush](/concepts/shape-the-arena-not-the-discovery.md) held the equivalent role under
FDR.

# How it works

One of four White House policy councils — national security, domestic, economic, and science and
technology. Kratsios's portfolio covers AI, quantum, civil nuclear energy, biotech and space, with
one or two staff per area. Its function is convening: there is no technology department, so tech
policy is spread across agencies with different equities, and only the White House can bring them
together and resolve disagreements, escalating to the president only what must reach him. See
[/concepts/how-federated-tech-policy-works.md](/concepts/how-federated-tech-policy-works.md).

# Outputs discussed

- **The AI Action Plan**, released the previous July, co-authored by Kratsios with David Sacks and
  Secretary Rubio. Chapter one opens with a commitment to open source. See
  [/concepts/open-weights-policy.md](/concepts/open-weights-policy.md).
- ***Science and the New Golden Age***, a roughly 150-page report released the week of the talk,
  written over a year in response to a presidential letter modelled on FDR's to Bush. Its thesis:
  AI will transform scientific discovery, and a government spending nearly $200 billion a year on
  R&D must prioritise accordingly. Concrete commitments cited: fast grants decided in under a month,
  prizes built for 3:1 private leverage, and agency action plans within 90 days. See
  [/concepts/shape-the-arena-not-the-discovery.md](/concepts/shape-the-arena-not-the-discovery.md)
  and [/concepts/autonomous-cloud-labs.md](/concepts/autonomous-cloud-labs.md).
- **A quantum executive order**, with a presidential goal for the Department of Energy to build a
  scientifically relevant quantum computer by 2028. Kratsios frames quantum as where AI was in
  2017–18.
- **Legislative proposals to Congress**, with federal preemption of state AI law as the priority. See
  [/concepts/preemption-and-little-tech.md](/concepts/preemption-and-little-tech.md).

Historical note from the same talk: the first US executive order prioritising AI was signed in
February 2019, during Kratsios's tenure as CTO, and roughly doubled federal AI R&D in the budgets of
that period.

⚠️ Positions are recorded as stated by a serving official at a private event, not as independently
verified fact.

[^ss26-kratsios]: Michael Kratsios, [Michael Kratsios: Inside the White House's AI Strategy](/sources/michael-kratsios.md), Startup School 2026.
