---
type: Organization
title: "Apple's Macintosh group"
description: "The team Susan Kare joined as Macintosh artist; the setting for the playlist's design talk."
tags: [apple, design, computing-history, macintosh]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-kare
    resource: https://www.youtube.com/watch?v=YEvLKzsEwMw
    title: "Susan Kare: Designing Icons & Graphics For the Original Mac"
    author: "Susan Kare"
    last_modified: 2026-08-14
---

The Macintosh software group at Apple, which [Susan Kare](/people/susan-kare.md) joined as the
Macintosh artist. Although part of Apple, she frames it as a tech startup she worked for, and says
much of the experience resonated with the startup themes at the event.

# The stated brief

Building a computer *anyone* could use — as understandable as possible without needing a manual, and
friendly, because the group was full of people passionate about computers who wanted to be
evangelical about them. Kare says she was told this sincerely and felt good about being in that
group.

The constraints: 16x16 and 32x32 one-bit bitmaps, and 128K of memory. See
[/concepts/constraints-enable-creativity.md](/concepts/constraints-enable-creativity.md).

# People mentioned

- **Andy Hertzfeld** — system software programmer, Kare's high-school friend, who recruited her,
  wrote the icon editor, co-named the fonts, and gave her the advice never to show Jobs one option.
- **Bill Atkinson** — wrote MacPaint, Kare's favourite program, collaborated on icons and patterns,
  and developed an early scanner (the source of a geisha image from a woodcut Jobs owned).
- **Steve Jobs** — walked through the software group at the end of the day; insisted on world-class
  city names for fonts, and objected to an "Apple farm" in the menus, which is how the Command key
  glyph came about. Later at NeXT, where Kare was creative director.
- **Bud Tribble** and **Alan Kay**, on interface nesting and on proportional fonts.
- **Steve Capps** — sewed the black flag that Kare painted with a skull and crossbones and a striped
  Apple eye patch, which they flew from the roof at night as a rejoinder to an offsite goal.

Kare notes that everybody she worked with in the software group had a sleeping bag in their cube,
and that it was not work–life balance at the time.

# What shipped that is discussed

Chicago and the city-named fonts; the Happy Mac, the sick Mac and the bomb; the Command key glyph;
MacPaint's verb-and-noun icon scheme; the animated control panel deliberately built without text so
it would work internationally; a watch cursor instead of an hourglass; the calculator, which used
Chicago and which Kare notes was — in retrospect — also the first iPod.

# See also

- [/concepts/sparse-metaphor-over-literal-detail.md](/concepts/sparse-metaphor-over-literal-detail.md)

[^ss26-kare]: Susan Kare, [Susan Kare: Designing Icons & Graphics For the Original Mac](/sources/susan-kare.md), Startup School 2026.
