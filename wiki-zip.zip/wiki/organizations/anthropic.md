---
type: Organization
title: "Anthropic"
description: "AI company; the playlist's source for harness design, product overhang and multi-day agent runs."
tags: [frontier-labs, agents, alignment, coding]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-cherny
    resource: https://www.youtube.com/watch?v=qyPCVqFUyDo
    title: "Boris Cherny: We Cut 80% of Claude Code's Prompt"
    author: "Boris Cherny"
    last_modified: 2026-07-27
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

AI company. Represented at Startup School 2026 by [Boris Cherny](/people/boris-cherny.md), creator
of Claude Code, speaking the day after an Opus 5 release.

# Facts and claims stated in this playlist

- **Opus 5 capabilities named:** ARC-AGI-3 at 30%, against previous best scores described as low
  single digits to low teens; runs continuing for days or weeks without scaffolding; and, in
  Cherny's account, no longer being demonstrably prompt-injectable.
- **Prompt-injection defence in three layers:** an aligned model (about three years of alignment
  research), a prompt-injection classifier run over all traffic and grounded in
  mechanistic-interpretability work that watches neurons activating during injection, and an
  auto-mode classifier.[^ss26-cherny]
- **Harness practice:** the system prompt and tool set are rewritten every model generation, with
  over 80% of the Claude Code system prompt removed for Opus 5. Almost all remaining harness code is
  described as safety, permissions, static analysis and UI. See
  [/concepts/ablation-driven-harness-design.md](/concepts/ablation-driven-harness-design.md).
- **Dynamic workflows** as a new axis of test-time compute, designed as an algebra for agents inside
  a sandboxed Bun runtime. See
  [/concepts/agent-orchestration-as-test-time-compute.md](/concepts/agent-orchestration-as-test-time-compute.md).
- **Loops and routines** used to self-maintain Anthropic's own CLI, iOS, Android and desktop
  codebases — roughly 20–30 routines a day. See
  [/concepts/self-maintaining-codebases.md](/concepts/self-maintaining-codebases.md).
- **Products mentioned:** Claude Code, a desktop app built in Electron, and Claude running in Slack.
- Two long runs are recorded as case studies:
  [/case-studies/bun-zig-to-rust-rewrite.md](/case-studies/bun-zig-to-rust-rewrite.md) and
  [/case-studies/electron-to-swift-two-week-run.md](/case-studies/electron-to-swift-two-week-run.md).
- **Attendee offer:** Max 20x for everyone at the event.

# Its role elsewhere in the playlist

[Peter Steinberger](/sources/peter-steinberger.md) describes Anthropic as the source of both the
name-change demand for OpenClaw — which he found stressful but understandable, and says they handled
nicely — and the subscription-access change that became his sharpest lesson. See
[/concepts/dependency-business-model-risk.md](/concepts/dependency-business-model-risk.md).
[Max Junestrand](/sources/max-junestrand.md) names Anthropic as a competitor for talent.

[^ss26-cherny]: Boris Cherny, [Boris Cherny: We Cut 80% of Claude Code's Prompt](/sources/boris-cherny.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
