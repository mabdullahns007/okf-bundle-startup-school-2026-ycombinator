---
type: Organization
title: "Waymo"
description: "Autonomous driving company; the playlist's reference case for AI deployed in the physical world at scale."
tags: [autonomous-vehicles, physical-ai, safety, reliability]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-dolgov
    resource: https://www.youtube.com/watch?v=Gp4zrV3-6N8
    title: "Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work"
    author: "Dmitri Dolgov"
    last_modified: 2026-08-03
  - id: ss26-finn
    resource: https://www.youtube.com/watch?v=cRZNwgvcWUg
    title: "Chelsea Finn: This is the State of the Art in Robotics"
    author: "Chelsea Finn"
    last_modified: 2026-08-12
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
---

Autonomous driving company, co-led by [Dmitri Dolgov](/people/dmitri-dolgov.md). The project began
in 2009.

# Scale and safety, as stated

Roughly 500,000 trips per week and over 4 million fully autonomous miles per week across 15 US
cities; more than 20 million fully autonomous trips and over 200 million miles to date. Published
safety analysis covering over 220 million miles reports about 17x fewer serious-injury crashes than
human drivers in the areas of operation, which Dolgov translates as preventing a serious injury
roughly every 8 days.[^ss26-dolgov]

Full timeline, including the demo/product gap and the exponential re-acceleration:
[/case-studies/waymo-demo-to-product-timeline.md](/case-studies/waymo-demo-to-product-timeline.md).

# Technical stack, as described

- **Sensing:** cameras, lidar and radar, each with its own encoder, fused into one representation.
  Sixth generation of the hardware suite, with cost falling each generation. See
  [/concepts/sensing-redundancy.md](/concepts/sensing-redundancy.md).
- **The Waymo foundation model:** a multimodal world-action-language model with fast and slow paths.
  See [/concepts/fast-path-slow-path-architecture.md](/concepts/fast-path-slow-path-architecture.md).
- **Structure-augmented end-to-end** learning. See
  [/concepts/structure-augmented-end-to-end.md](/concepts/structure-augmented-end-to-end.md).
- **Simulation:** behavioural world models built for years, plus sensor world models, leveraging
  Google DeepMind's Genie 3. See [/concepts/closed-loop-simulation.md](/concepts/closed-loop-simulation.md).
- **Vehicle platforms mentioned:** fifth and sixth generation drivers on the JLR I-Pace, Zeekr and
  Hyundai Ioniq, with trucking and personally owned vehicles as future products. NVIDIA chips are in
  the vehicles.[^ss26-huang]
- **The safety and readiness framework**, which Dolgov calls one of the company's most important
  assets. See [/concepts/evals-as-the-durable-asset.md](/concepts/evals-as-the-durable-asset.md).

# Why it matters to the other speakers

[Chelsea Finn](/sources/chelsea-finn.md) cites Waymo's quarter-million weekly autonomous rides as
the existence proof that a machine-learning system can be trusted to operate autonomously in the
physical world — grounds for optimism about the rest of physical AI.[^ss26-finn]

[^ss26-dolgov]: Dmitri Dolgov, [Waymo Co-CEO Dmitri Dolgov: The Demo Is Only 1% Of The Work](/sources/dmitri-dolgov.md), Startup School 2026.
[^ss26-finn]: Chelsea Finn, [Chelsea Finn: This is the State of the Art in Robotics](/sources/chelsea-finn.md), Startup School 2026.
[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
