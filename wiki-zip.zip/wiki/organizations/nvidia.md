---
type: Organization
title: "NVIDIA"
description: "Accelerated computing company founded 1993; its founding algorithm was wrong and it learned graphics from textbooks."
tags: [hardware, gpu, accelerated-computing, physical-ai]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-huang
    resource: https://www.youtube.com/watch?v=I4B37S1dyQQ
    title: "Jensen Huang: The Mindset That Built NVIDIA"
    author: "Jensen Huang"
    last_modified: 2026-07-26
  - id: ss26-steinberger
    resource: https://www.youtube.com/watch?v=whcfSGN6CAU
    title: "Peter Steinberger: Fun Is Velocity"
    author: "Peter Steinberger"
    last_modified: 2026-08-10
---

Founded 1993 by [Jensen Huang](/people/jensen-huang.md) and two co-founders, with the idea of
turning every personal computer into a game console.

# Facts stated in this playlist

- The **founding technology was wrong.** By 1995 the team concluded the 3D graphics algorithm was
  wrong — and that none of them knew the right way — with 35 to 40 competitors already in the market.
  Huang bought three OpenGL and pipeline-design textbooks from Fry's and handed them to the
  engineers.[^ss26-huang]
- The durable bet was accelerating **algorithm domains**, not building chips. See
  [/concepts/accelerating-algorithm-domains.md](/concepts/accelerating-algorithm-domains.md).
- The [Sega contract](/case-studies/sega-dreamcast-contract.md): a ~$12M contract for the console
  that became Dreamcast, which NVIDIA could not fulfil; the $5M that kept it alive; Sega selling its
  stake at IPO for about $15M.
- **IPO 1999 at a $300 million valuation.** Market capitalisation referenced in the talk as more
  than a trillion dollars; the interviewer frames the arc as zero to five trillion over 34 years.
- Read AlexNet as the discovery of a universal function approximator, and started computer vision,
  robotics and self-driving work roughly fifteen years before the talk.
- **Physical AI:** world foundation models; Isaac Sim and Cosmos for simulation; real-to-sim,
  physics-grounded and generative simulation, and sim-to-real. Chips in Waymo vehicles; presence at
  Tesla and Mercedes in car and datacentre. Alpamayo, described as the world's first *thinking*
  self-driving car, trained on a couple of million miles by reasoning from prior knowledge —
  open-sourced because autonomous navigation is needed for agriculture, mail delivery and warehouse
  robots, none of which alone is a large enough market.
- Robotics and AV business described as **almost $10 billion**, expected to become the next
  $100 billion business in under ten years.
- **Open source:** Huang argues modern AI would not exist without Linux, Kubernetes, Torch, Theano,
  Caffe and PyTorch. NVIDIA engineers were offered to [OpenClaw](/organizations/openclaw.md) — which
  [Peter Steinberger](/sources/peter-steinberger.md) confirms from the other side, saying NVIDIA was
  very early, simply asked what he needed, and sent people to take over much of the security
  work.[^ss26-steinberger] Similar work with the Hermes team.
- Internally: Claude Code running autonomously in sandboxes across the company, with teams free to
  pick their own tools — his phrase is letting a thousand flowers bloom — so they learn from all of it.

# See also

- [/concepts/fit-the-company-to-the-founder.md](/concepts/fit-the-company-to-the-founder.md)
- [/concepts/controllability-as-the-agent-frontier.md](/concepts/controllability-as-the-agent-frontier.md)

[^ss26-huang]: Jensen Huang, [Jensen Huang: The Mindset That Built NVIDIA](/sources/jensen-huang.md), Startup School 2026.
[^ss26-steinberger]: Peter Steinberger, [Peter Steinberger: Fun Is Velocity](/sources/peter-steinberger.md), Startup School 2026.
