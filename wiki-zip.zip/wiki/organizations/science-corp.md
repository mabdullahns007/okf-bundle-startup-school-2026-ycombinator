---
type: Organization
title: "Science Corp"
description: "Neural engineering company; its lead product is a subretinal photovoltaic implant restoring vision."
tags: [bci, neurotech, medical-devices, deep-tech]
status: draft
generated: { by: claude-code/opus-5, at: 2026-09-05T12:00:00Z }
sources:
  - id: ss26-hodak
    resource: https://www.youtube.com/watch?v=Xc4klGbq8v8
    title: "Max Hodak: Average Is Not Good Enough"
    author: "Max Hodak"
    last_modified: 2026-08-07
---

Neural engineering company led by [Max Hodak](/people/max-hodak.md), started in early 2021. Four of
its five co-founders came from Neuralink.

# The founding question

Hodak describes looking around the world in early 2021 and asking what the most valuable thing was
that they could do, that would be likely to work in the near future, would have a big impact on
patients, and could be the foundation for a scalable medical device company. Their answer was
restoring vision by stimulating the retina.

They explored all four quadrants of the design space — two candidate cell types (bipolar cells or
the optic nerve) and two stimulation modes (electrical or optical) — developing a state-of-the-art
gene therapy internally for the optical route, and identifying a French company as the state of the
art in electrical stimulation. They eventually acquired it and hold the licence.

# The product

A subretinal photovoltaic implant: a chip implanted under the retina, patterned with hex-grid solar
cells. The patient wears glasses containing a camera and an infrared laser projector; light absorbed
on the implant creates local electric fields that excite the retina directly, bypassing dead rods
and cones. The underlying technology was invented by a Stanford professor roughly fifteen years
earlier.

Stated status: through three clinical trials, having completed major trials the previous year; an
approved medical device in Europe; clinical trials in six countries; results in the New England
Journal of Medicine; a patient on the cover of Time; and one patient who finished a 300-page novel
with the device and mailed the team the book.

# What the talk is actually about

Not the product but the internal infrastructure that sets iteration speed — **Helix**, the internal
platform in which nearly everything in the company is a button and every lab step is a database
record. See [/concepts/internal-software-as-competitive-advantage.md](/concepts/internal-software-as-competitive-advantage.md),
[/concepts/cost-attribution-in-physical-r-and-d.md](/concepts/cost-attribution-in-physical-r-and-d.md),
[/concepts/distributed-hiring-funnel.md](/concepts/distributed-hiring-funnel.md) and
[/case-studies/eigen-reviews-at-science.md](/case-studies/eigen-reviews-at-science.md).

Hodak describes the company as roughly 30% overtly transhumanist and 70% clinicians and researchers,
and says holding both cultures is what makes it work. See
[/concepts/two-cultures-in-a-mission-company.md](/concepts/two-cultures-in-a-mission-company.md).
He also says it is relentlessly focused on revenue and sustainability despite the long roadmap.

# Open engineering problems he names

Implant power and thermal limits, which pressure you to implant as little as possible; and
**packaging** — keeping the device in and the body out — where the classic laser-welded titanium can
cannot go in an eye. He notes an earlier retinal prosthesis attached a titanium box to the eyeball in
a four-and-a-half-hour surgery and did not work well enough. He names conformal coating materials as
an open materials-science problem.

[^ss26-hodak]: Max Hodak, [Max Hodak: Average Is Not Good Enough](/sources/max-hodak.md), Startup School 2026.
